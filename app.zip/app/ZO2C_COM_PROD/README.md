# Git Repoes

### Конфигуратор
| Git       | Remote repo                                                 |
| :-------- | :---------------------------------------------------------- |
| SAP       | https://github.wdf.sap.corp/I337799/SeverstalUI5Project.git |
| Github    | https://github.com/GerardHuppe/svrstlbffspc.git             |
| Severstal | https://git.severstal.severstalgroup.com/zo2c/conf.git      |

>*Можно просто слонить проект*

```bash
$ git clone https://github.com/GerardHuppe/svrstlbffspc.git
```


>*А можно  добавить новый Remote к тому, в котором вы уже работаете*

```bash
# upstream - то как вы хотите назвать свой ремоут 
$ git remote add upstream https://github.com/GerardHuppe/svrstlbffspc.git

# проверим есть появился ли у нас этот ремоут 
$ git remote -v

> origin	https://github.wdf.sap.corp/I337799/SeverstalUI5Project.git (fetch)
> origin	https://github.wdf.sap.corp/I337799/SeverstalUI5Project.git (push)
> upstream	https://github.com/GerardHuppe/svrstlbffspc.git (fetch)
> upstream	https://github.com/GerardHuppe/svrstlbffspc.git (push)

# get data from your remote projects, you can run:
$ git fetch upstream 
# get data from your remote projects, you can run:
$ git fetch upstream 
git config credential.${remote}.username yourusername
git config credential.helper store
git clone https://dd.khappi:exR2YR73LLkteAx@git.severstal.severstalgroup.com/zo2c/manage_vp.git

# get data from your remote projects, you can run:
$ git remote show origin

# get data from your remote projects, you can run:
$ git remote rename upstream severstal 

# get data from your remote projects, you can run:
$ git remote remove severstal 


```

>*Gitlab **Severstal***

```bash
git clone https://git.severstal.severstalgroup.com/zo2c/conf.git
```

---

### Ведение ВП
| Git    | Remote repo                                                  |
| :----- | :----------------------------------------------------------- |
| SAP    | git clone https://github.wdf.sap.corp/I337799/SeverstalUI5Project_EditVP.git |
| Github | git clone https://github.com/GerardHuppe/manage_vp.git       |

*Github*
```bash
git clone https://github.com/GerardHuppe/manage_vp.git
```

*Github **SAP***

```bash
git clone https://github.wdf.sap.corp/I337799/SeverstalUI5Project_EditVP.git
```


>*Gitlab **Severstal***

```bash
git clone https://git.severstal.severstalgroup.com/zo2c/manage_vp.git
```


---
### Ведение заявок
| Git       | Remote repo                                                  |
| :-------- | :----------------------------------------------------------- |
| Github    | git clone https://github.com/GerardHuppe/appl.git            |
| Severstal | git clone https://git.severstal.severstalgroup.com/zo2c/appl.git |
*Github*
```bash
git clone https://github.com/GerardHuppe/appl.git
```

*Gitlab **Severstal***
```bash
git clone https://git.severstal.severstalgroup.com/zo2c/appl.git
```


<!-- toc -->



<!-- tocstop -->
