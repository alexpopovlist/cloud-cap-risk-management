sap.ui.define(['sap/uxap/BlockBase'], function (BlockBase) {
	"use strict";

	var tabBlock = BlockBase.extend("ZO2C_COM_PROD.ZO2C_COM_PROD.view.blocks.RAL", {
		metadata: {
			views: {
				Collapsed: {
					viewName: "ZO2C_COM_PROD.ZO2C_COM_PROD.view.tabs.RAL",
					type: "XML"
				},
				Expanded: {
					viewName: "ZO2C_COM_PROD.ZO2C_COM_PROD.view.tabs.RAL",
					type: "XML"
				}
			}
		}
	});
	return tabBlock;
}, true);
