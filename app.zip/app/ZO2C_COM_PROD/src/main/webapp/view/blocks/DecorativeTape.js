sap.ui.define(['sap/uxap/BlockBase'], function (BlockBase) {
	"use strict";

	var tabBlock = BlockBase.extend("ZO2C_COM_PROD.ZO2C_COM_PROD.view.blocks.DecorativeTape", {
		metadata: {
			views: {
				Collapsed: {
					viewName: "ZO2C_COM_PROD.ZO2C_COM_PROD.view.tabs.DecorativeTape",
					type: "XML"
				},
				Expanded: {
					viewName: "ZO2C_COM_PROD.ZO2C_COM_PROD.view.tabs.DecorativeTape",
					type: "XML"
				}
			}
		}
	});
	return tabBlock;
}, true);
