sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"ZO2C_COM_PROD/ZO2C_COM_PROD/custom/model/stateModel",
	"ZO2C_COM_PROD/ZO2C_COM_PROD/controller/ErrorHandler",
	"ZO2C_COM_PROD/ZO2C_COM_PROD/custom/class/ERouter",
	"ZO2C_COM_PROD/ZO2C_COM_PROD/custom/class/EODataModel",
	"sap/ui/core/mvc/XMLView"

], function (UIComponent, Device, stateModel, ErrorHandler, EODataModel, XMLView) {
	"use strict";

	//check for BSP environment and set reuse library path
	var i = window.location.pathname.indexOf("/ui5_ui5/");
	var j = window.location.pathname.indexOf("/ui2/");
	var s4 = window.location.origin.indexOf("/wd-s4");
	if (i !== -1){
	 	var p = window.location.pathname.slice(0, i + 8);
		if (s4 !== -1) {
			p += "/sap/zo2ci600_lib/ZO2C/COMMON/LIB";
		} else {
			p += "/sap/zo2c_common_lib/ZO2C/COMMON/LIB";
		}
	   	$.sap.registerModulePath("ZO2C.COMMON.LIB", p);
	} else if (j !== -1){
		var p = "/sap/bc/ui5_ui5";
		if (s4 !== -1) {
			p += "/sap/zo2ci600_lib/ZO2C/COMMON/LIB";
		} else {
			p += "/sap/zo2c_common_lib/ZO2C/COMMON/LIB";
		}
	   	$.sap.registerModulePath("ZO2C.COMMON.LIB", p);
	}

	return UIComponent.extend("ZO2C_COM_PROD.ZO2C_COM_PROD.Component", {

		_oErrorHandler: null,
		_sContentDensityClass: null,
		_oMessageManager: null,
		_oMessageProcessor: null,

		metadata: {
			manifest: "json"
		},

		constructor: function () {
			UIComponent.prototype.constructor.apply(this, arguments);
		},

		initModel: function () {
				var 
					s4 = ~window.location.origin.indexOf("/wd-s4"),
					sAnnoPath = "/sap/bc/ui5_ui5/sap/" + (!s4 ? "zo2c_com_prod" : "zo2ci605_cm_prd") + "/annotation.xml";

				if (window.location.origin.indexOf("localhost") > 0) {
					sAnnoPath = "annotation.xml";
				} 
				var oMainModel = new ZO2C_COM_PROD.ZO2C_COM_PROD.custom.class.EODataModel(
					"/sap/opu/odata/ASUT/O2C_COMMERCIAL_PRODUCT_SRV/", {
						annotationURI: sAnnoPath,
						defaultOperationMode: "Server",
						defaultBindingMode: "TwoWay",
						defaultCountMode: "InlineRepeat",
						delayBeforeSave: 3000,
						refreshAfterChange: false
					}
				);
				this.setModel(oMainModel);
		},

		init: function () {
			UIComponent.prototype.init.apply(this, arguments);
			this.initModel(this.getURLObject());
			this._oMessageManager = sap.ui.getCore().getMessageManager();
			this._oMessageProcessor = new sap.ui.core.message.ControlMessageProcessor();
			this._oMessageManager.registerObject(this, true);
			this._oMessageManager.registerMessageProcessor(this._oMessageProcessor);
			this._oErrorHandler = new ErrorHandler(this);
			this._oMessageManager.getMessageModel().setSizeLimit(1000);
			sap.ui.core.BusyIndicator.show(0);
			this.getModel().getMetaModel().loaded().then(function () {
				this.getRouter().initialize();
				this.getRouter().attachBeforeRouteMatched(this.onBeforeRouteMatched.bind(this));
			}.bind(this));
		},

		getURLAction: function () {
			const sHash = window.location.hash;
			const nPos = sHash.indexOf("?");
			return sHash.substring(sHash.indexOf("-") + 1, nPos);
		},

		getURLObject: function () {
			const sHash = window.location.hash;
			var sSemanticObject = "";

			if (sHash.indexOf("&") > 0)
				sSemanticObject = sHash.substring(sHash.indexOf("-") + 1, sHash.indexOf("&"));
			else
				sSemanticObject = sHash.substring(sHash.indexOf("-") + 1, sHash.length);

			return sSemanticObject;
		},

		getDefaultRouteForCrossAppNavigation: function (sAction) {
			switch (sAction) {
				case "CR":
					return "changeRequest";
				case "chain":
					return "createObjectShort";
				default:
					return "editSupplyProc";
			}
		},


		onBeforeRouteMatched:function(oEvent) {
			var oArgs = oEvent.getParameter("arguments");
			var sNewAppMode = oArgs.AppMode;
			var sOldAppMode = this.getModel("state").getProperty("/_GET").AppMode;

			if(sNewAppMode !== sOldAppMode){
				this._oMessageManager.removeAllMessages();
			}
		},


		getContentDensityClass: function () {
			this._sContentDensityClass = "sapUiSizeCompact";
			return this._sContentDensityClass;
		},

		destroy: function () {
			UIComponent.prototype.destroy.apply(this, arguments);
		}
	});
});
