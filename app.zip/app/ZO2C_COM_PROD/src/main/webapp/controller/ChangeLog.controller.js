sap.ui.define([
	"ZO2C_COM_PROD/ZO2C_COM_PROD/controller/BaseController",
	"sap/ui/model/Filter"

], function(BaseController, Filter) {
	"use strict";

	const thisController = BaseController.extend("ZO2C_COM_PROD.ZO2C_COM_PROD.controller.ChangeLog", {

		_oCustomFilters: [],

		onInit: function() {
			this.getRouter().getRoute("changeLog").attachPatternMatched(this._onChangeLogMatched, this);
			console.clear();
		},

		_onChangeLogMatched: function(oControlEvent) {
			const oPageController = this.getPageController();
			const oSmartFilterbar = this.getById("listReportFilter");
			const oChDateFromControl = oSmartFilterbar.getControlByKey("ChDateFrom");
			const oChDateToControl = oSmartFilterbar.getControlByKey("ChDateTo");


			this.setStateProperty("/app/currentView", this.getView().getId());
			this.setStateProperty("/app/busy", false);
			sap.ui.core.BusyIndicator.hide();

			this.setStateProperty("/_GET", {});
			$.each(oControlEvent.getParameter("arguments"), function(sIndex, vParam) {
				const sNewIndex = (sIndex.indexOf("?") === 0) ? sIndex.slice(1) : sIndex;
				const vNewValue = (!vParam) ? {} : vParam;
				this.getStateProperty("/_GET")[sNewIndex] = vNewValue;
			}.bind(this));
			this.setStateProperty("/app/currentView", this.getView().getId());
			this.setStateProperty("/app/mainServiceName", "MainCPSet");

			this.getView().bindElement({
				path: this.createCurrentKey("/"),
				events: {
					dataReceived: function(oResponse) {
						var oResponse = oResponse.getParameter("data");
						this.getModel().detachEvent("requestFailed", this.onRequestFailed);
						this.hideBusy();
						if (oResponse) {
							if (oResponse.CodeCp === "0000000000") {
								this.getRouter().navTo("notFound", {}, true);
							} else if (this.getStateProperty("/app/showErrorPopover")) {
								oPageController.setStateProperty("/app/showErrorPopover", false);
								this.getPageController().getById("ObjectMessagesIndicator").firePress();
							}
						} else {
							this.getRouter().navTo("notFound", {}, true);
						}
					}.bind(this)
				}
			});

			this.setStateProperty("/changeLog/FieldKey", "");
			this.setStateProperty("/changeLog/UserId", "");
			this.setStateProperty("/changeLog/selectViewId", "");
			oChDateFromControl.setValue(null);
			oChDateToControl.setValue(null);

			this.setTab();

			this.executeRefreshSmartTable("listReportFilter", "toChangeDocLog");
			this.executeRefreshSmartTable("idSmartChangeLogTable", "toChangeDocLog");
		},

		eInputBeforeRebindTableCustomFilters: function(oContolEvent) {
			var oBindingParams = oContolEvent.getParameter("bindingParams");
			var aCustomData = oContolEvent.getSource().getCustomData();
			var oEInput = aCustomData[4].getValue();
			var sKey = oEInput.getController().getView().byId("editCpViewNameFilter").getSelectedKey();

			oBindingParams.parameters.select = (oBindingParams.parameters.select) ? oBindingParams.parameters.select + ",CpView" : "CpView";
			if (sKey !== "A") {
				oBindingParams.filters.push(new Filter("CpView", "EQ", sKey));
			}
		},

		setTab: function() {
			switch (this.getStateProperty("/_GET").Tab) {
				case "General":
					this.setStateProperty("/changeLog/selectViewId", "G");
					break;
				case "Chemical":
					this.setStateProperty("/changeLog/selectViewId", "C");
					break;
				case "Mechanical":
					this.setStateProperty("/changeLog/selectViewId", "M");
					break;
				case "Technical":
					this.setStateProperty("/changeLog/selectViewId", "T");
					break;
				case "Classif":
					this.setStateProperty("/changeLog/selectViewId", "K");
					break;
				case "ProfileSize":
					this.setStateProperty("/changeLog/selectViewId", "P");
					break;
				case "RAL":
					this.setStateProperty("/changeLog/selectViewId", "R");
					break;
				case "DecorativeTape":
					this.setStateProperty("/changeLog/selectViewId", "D");
					break;
				case "OtherCharact":
					this.setStateProperty("/changeLog/selectViewId", "V");
					break;
				default:
					this.setStateProperty("/changeLog/selectViewId", "A");
			}

		},

		onBeforeVariantSave: function(oControlEvent) {
			const oSmartFilterbar = this.getById("listReportFilter");
			oSmartFilterbar.setFilterData({
				_CUSTOM: this._oCustomFilters
			});
		},

		onAfterVariantLoad: function(oControlEvent) {
			const oSmartFilterbar = this.getById("listReportFilter");
			const oData = oSmartFilterbar.getFilterData();
			const oChDateFromControl = oSmartFilterbar.getControlByKey("ChDateFrom");
			const oChDateToControl = oSmartFilterbar.getControlByKey("ChDateTo");

			oChDateFromControl.setValue(null);
			oChDateToControl.setValue(null);
			this.setStateProperty("/changeLog/FieldKey", "");
			this.setStateProperty("/changeLog/UserId", "");
			this.setStateProperty("/changeLog/selectViewId", "A");

			if (oData._CUSTOM !== undefined) {
				const oCustomFieldData = oData["_CUSTOM"];
				if (oCustomFieldData[0]) {
					if (oCustomFieldData[0].CpView !== undefined) {
						this.setStateProperty("/changeLog/selectViewId", oCustomFieldData[0].CpView);
					}
					if (oCustomFieldData[0].ChDateFrom !== undefined) {
						oChDateFromControl.setDateValue(new Date(oCustomFieldData[0].ChDateFrom));
					}
					if (oCustomFieldData[0].ChDateTo !== undefined) {
						oChDateToControl.setDateValue(new Date(oCustomFieldData[0].ChDateTo));
					}
					if (oCustomFieldData[0].FieldKey !== undefined) {
						this.setStateProperty("/changeLog/FieldKey", oCustomFieldData[0].FieldKey);
					}
					if (oCustomFieldData[0].UserId !== undefined) {
						this.setStateProperty("/changeLog/UserId", oCustomFieldData[0].UserId);
					}
				}
			} else {
				this.setStateProperty("/changeLog/selectViewId", "A");
			}
		},

		onBeforeRebindTable: function(oControlEvent) {
			const oSmartTable = oControlEvent.getSource();
			const oSmartFilterBar = this.getById(oSmartTable.getSmartFilterId());
			const oBindingParams = oControlEvent.getParameter("bindingParams");
			const oCpViewNameControl = oSmartFilterBar.getControlByKey("CpViewName");
			const oChDateFromControl = oSmartFilterBar.getControlByKey("ChDateFrom");
			const oChDateToControl = oSmartFilterBar.getControlByKey("ChDateTo");
			const oChangeDocAttrNameControl = oSmartFilterBar.getControlByKey("ChangeDocAttrName");
			const oUserNameControl = oSmartFilterBar.getControlByKey("UserName");

			oBindingParams.parameters = oBindingParams.parameters || {};
			var aReqFilter = [];

			if (oChangeDocAttrNameControl.getValue() === "") {
				this.setStateProperty("/changeLog/FieldKey", "");
			}

			if (oUserNameControl.getValue() === "") {
				this.setStateProperty("/changeLog/UserId", "");
			}

			const sCpViewNameControl = oCpViewNameControl.getSelectedKey();
			const sChDateFromControl = oChDateFromControl.getDateValue();
			const sChDateToControl = oChDateToControl.getDateValue();
			const sUserNameControl = this.getStateProperty("/changeLog/UserId");
			const sChangeDocAttrNameControl = this.getStateProperty("/changeLog/FieldKey");
			var oCustomFilters = {};

			if (sCpViewNameControl !== "A") {
				var oCpViewNameFilter = new Filter("CpView", "EQ", sCpViewNameControl);
				aReqFilter.push(oCpViewNameFilter);

				oCustomFilters.CpView = sCpViewNameControl;
				this._oCustomFilters[0] = oCustomFilters;
			}

			if (sChDateFromControl !== null) {
				var oChDateFromFilter = new Filter("ChDateFrom", "EQ", new Date(sChDateFromControl));
				aReqFilter.push(oChDateFromFilter);

				oCustomFilters.ChDateFrom = new Date(sChDateFromControl);
				this._oCustomFilters[0] = oCustomFilters;
			}

			if (sChDateToControl !== null) {
				var oChDateToFilter = new Filter("ChDateTo", "EQ", new Date(sChDateToControl));
				aReqFilter.push(oChDateToFilter);

				oCustomFilters.ChDateTo = new Date(sChDateToControl);
				this._oCustomFilters[0] = oCustomFilters;
			}

			if (sChangeDocAttrNameControl !== "") {
				var oChangeDocAttrNameFilter = new Filter("FieldKey", "EQ", sChangeDocAttrNameControl);
				aReqFilter.push(oChangeDocAttrNameFilter);

				oCustomFilters.FieldKey = sChangeDocAttrNameControl;
				this._oCustomFilters[0] = oCustomFilters;
			}

			if (sUserNameControl !== "") {
				var oUserNameFilter = new Filter("UserId", "EQ", sUserNameControl);
				aReqFilter.push(oUserNameFilter);

				oCustomFilters.UserId = sUserNameControl;
				this._oCustomFilters[0] = oCustomFilters;
			}

			if (aReqFilter.length > 0) {
				if (oBindingParams.filters.length) {
					oBindingParams.filters[0] = new Filter([oBindingParams.filters[0], new Filter(aReqFilter, true)], true);
				} else {
					oBindingParams.filters.push(new Filter(aReqFilter, true));
				}
			}
		},

	});

	$.extend(true, thisController.prototype);
	return thisController;
});
