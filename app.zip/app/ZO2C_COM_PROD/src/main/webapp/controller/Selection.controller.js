sap.ui.define([
	"ZO2C_COM_PROD/ZO2C_COM_PROD/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"

], function(BaseController, JSONModel, History, Filter, FilterOperator) {
	"use strict";

	const thisController = BaseController.extend("ZO2C_COM_PROD.ZO2C_COM_PROD.controller.Selection", {

		_ObjectPage: null,
		_oWizard: null,

		onInit: function() {
			this.getRouter().getRoute("selection").attachPatternMatched(this._onObjectMatched, this);
			console.clear();

			this._oWizard = this.getById("CreateSelectionWizard");
		},

		_onObjectMatched: function(oControlEvent) {
			this.setStateProperty("/app/currentView", this.getView().getId());
			this.setStateProperty("/app/busy", true);
			sap.ui.core.BusyIndicator.hide();
			this._oWizard.discardProgress(this.getById("WizardStStep"));
		},

		wizardStStepValidation : function () {
			this._oWizard.validateStep(this.getView().byId("WizardStStep"));
		},

		wizardActionStepValidation: function() {
			this._oWizard.validateStep(this.getView().byId("WizardActionStep"));
		},

		wizardNewValStepValidation: function () {
			this._oWizard.validateStep(this.getView().byId("WizardNewValStep"));
		},

		wizardCheckStepValidation: function () {
			this._oWizard.setShowNextButton(false);
		},

		onWizardActionStepTableNonActualPressHandler: function () {
			this._oWizard.setCurrentStep(this.getById("WizardCheckStep"));
		},

		onCreateNewSelection: function() {
			var sId = this._createNewSelection();
			this.navToObject(sId);
		},

		navToObject: function(sId) {
			this.getRouter().navTo("objectPage", {
				Tab: "General",
				Id: sId
			}, false);
		}

	});

	$.extend(true, thisController.prototype);
	return thisController;
});
