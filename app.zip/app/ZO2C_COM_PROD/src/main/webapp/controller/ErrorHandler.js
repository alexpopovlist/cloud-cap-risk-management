sap.ui.define([
	"sap/ui/base/Object",
	"sap/m/MessageBox",
	"sap/ui/core/MessageType"
], function(UI5Object, MessageBox, MessageType) {
	"use strict";

	return UI5Object.extend("zgagarin.zsupplyproc.controller.ErrorHandler", {

		/**
		 * Handles application errors by automatically attaching to the model events and displaying errors when needed.
		 * @class
		 * @param {sap.ui.core.UIComponent} oComponent reference to the app's component
		 * @alias com.sap.sapx08.controller.ErrorHandler
		 */
		constructor: function(oComponent) {
			this._oResourceBundle = oComponent.getModel("i18n").getResourceBundle();
			this._oComponent = oComponent;
			this._oModel = oComponent.getModel();
			this._bMessageOpen = false;
			this._sErrorText = this._oResourceBundle.getText("errorText");

			this._oModel.attachMetadataFailed(function(oControlEvent) {
				const oParams = oControlEvent.getParameters();
				sap.ui.core.BusyIndicator.hide();
				this._showMetadataError(oParams.response);
			}, this);

			this._oModel.attachRequestFailed(function(oControlEvent) {
				sap.ui.core.BusyIndicator.hide();
			}, this);
		},

		getFullErrorMessage: function(oError) {
			var oResponse = $.sap.parseJS(oError.responseText);
			var sResultResponse = oResponse.error.message.value;
			
			return sResultResponse;
		},

		getFullLongTextErrorMessage: function(oError) {
			var aErrorsNotToShow = ["/BOBF/FRW_COMMON/094"],
				oResponse = $.sap.parseJS(oError.responseText),
				aResultResponse = [];

			try {
				if (oResponse.error.message.longtext_url || (oResponse.error.innererror.errordetails.length && oResponse.error.innererror.errordetails[0].longtext_url)) {
					var sLongTextUrl = oResponse.error.message.longtext_url ? oResponse.error.message.longtext_url : oResponse.error.innererror.errordetails[0].longtext_url;
					aResultResponse.push({
						"message": oResponse.error.message.value,
						"longtext_url": window.location.origin + sLongTextUrl
					});
				}

				if (oResponse.error.innererror.errordetails.length) {
					var aResponseRows = oResponse.error.innererror.errordetails.map(function(oResponseMessage, iIndex) {
						return ((iIndex !== 0 || oResponseMessage.message !== oResponse.error.message.value) && (aErrorsNotToShow.indexOf(oResponseMessage.code) < 0) && !!oResponseMessage.longtext_url) ? {
							"message": oResponseMessage.message,
							"longtext_url": window.location.origin + oResponseMessage.longtext_url
						} : {
							"longtext_url": ""
						}

					});
					aResponseRows.forEach(function(oRow) {
						if (oRow.longtext_url !== "") {
							aResultResponse.push(oRow);
						}
					}.bind(this));
				}
				aResultResponse = aResultResponse.length === 0 ? false : aResultResponse;
				return aResultResponse;

			} catch (oCatchError) {
				return null;
			}
		},

		getFullBatchErrorMessage: function(oError) {
			if (!!oError.response) {
				var oResponse = $.sap.parseJS(oError.response.body);

				var sResultResponse = oResponse.error.message.value;
				if (oResponse.error.innererror.errordetails.length) {
					var aResponseRows = oResponse.error.innererror.errordetails.map(function(oResponseMessage, iIndex) {
						return (iIndex !== 0 || oResponseMessage.message !== oResponse.error.message.value) ? oResponseMessage.message : "";
					});
					if (aResponseRows.join("\n\n").trim() !== "") {
						sResultResponse = sResultResponse + "\n\n" + aResponseRows.join("\n\n").trim();
					}
				}
				return sResultResponse;
			} else {
				return "";
			}
		},

		getFileUploadFullErrorMessage: function(oError) {
			var oResponse = xmlToJson($.sap.parseXML(oError.responseRaw));

			var sResultResponse = oResponse.error.message["#text"];

			if (oResponse.error.innererror.errordetails.errordetail && oResponse.error.innererror.errordetails.errordetail.length) {
				var aResponseRows = oResponse.error.innererror.errordetails.errordetail.map(function(oResponseMessage, iIndex) {
					return (oResponseMessage.message["#text"] !== oResponse.error.message["#text"]) ? oResponseMessage.message["#text"] : "";
				});
				sResultResponse = sResultResponse + "\n\n" + aResponseRows.join("\n\n").trim();
			}

			return sResultResponse;
		},

		getFileCploadFullLongTextErrorMessage: function(oError) {
			var oResponse = xmlToJson($.sap.parseXML(oError.responseRaw)),
				aResponseRows = [];

			try {
				if (!!oResponse.error.innererror.longtext_url || (oResponse.error.innererror.errordetails.errordetail && oResponse.error.innererror.errordetails.errordetail.length && oResponse.error.innererror.errordetails.errordetail[0].longtext_url)) {
					var sLongText = oResponse.error.innererror.longtext_url ? oResponse.error.innererror.longtext_url["#text"] : oResponse.error.innererror.errordetails.errordetail[0].longtext_url["#text"];
					aResultResponse.push({
						"message": oResponse.error.message["#text"],
						"longtext_url": window.location.origin + sLongText
					});
				}
				if (oResponse.error.innererror.errordetails.errordetail && oResponse.error.innererror.errordetails.errordetail.length) {
					var aResponseRows = oResponse.error.innererror.errordetails.errordetail.map(function(oResponseMessage, iIndex) {
						return ((iIndex !== 0 || oResponseMessage.longtext_url["#text"] !== oResponse.error.innererror.longtext_url["#text"]) && !!oResponseMessage.longtext_url["#text"]) ? {
							"message": oResponseMessage.message["#text"],
							"longtext_url": window.location.origin + oResponse.error.innererror.longtext_url["#text"]
						} : {
							"message": oResponseMessage.message["#text"],
							"longtext_url": ""
						}
					});
					aResponseRows.forEach(function(oRow) {
						if (oRow.longtext_url !== "") {
							aResultResponse.push(oRow);
						}
					}.bind(this));
				}
				aResultResponse = aResultResponse.length === 0 ? false : aResultResponse;
				return aResultResponse;
			} catch (oError) {
				return null;
			}
		},

		
		getFullWarningMessage: function(oMessage) {
			var oResponse = $.sap.parseJS(oMessage.headers["sap-message"]);

			var sResultResponse = oResponse.message;
			if (oResponse.details.length) {
				var aResponseRows = oResponse.details.map(function(oResponseMessage, iIndex) {
					return (iIndex !== 0 || oResponseMessage.message !== oResponse.message) ? oResponseMessage.message : "";
				});
				sResultResponse = sResultResponse + "\n\n" + aResponseRows.join("\n\n").trim();
			}

			return sResultResponse;
		},

		getFullLongTextWarningMessage: function(oMessage) {
			var oResponse = $.sap.parseJS(oMessage.headers["sap-message"]);
			try {
				var aResultResponse = [];
				if (!!oResponse.longtext_url || (oResponse.details.length && oResponse.details[0].longtext_url)) {
					var sLongTextUrl = oResponse.longtext_url ? oResponse.longtext_url : oResponse.details[0].longtext_url;
					aResultResponse.push({
						"message": oResponse.message,
						"longtext_url": window.location.origin + sLongTextUrl
					});
				}
				if (oResponse.details.length) {
					var aResponseRows = oResponse.details.map(function(oResponseMessage, iIndex) {
						return ((iIndex !== 0 || oResponseMessage.longtext_url !== oResponse.longtext_url) && !!oResponseMessage.longtext_url) ? {
							"message": oResponseMessage.message,
							"longtext_url": window.location.origin + oResponseMessage.longtext_url
						} : {
							"message": oResponseMessage.message,
							"longtext_url": ""
						}
					});
					aResponseRows.forEach(function(oRow) {
						if (oRow.longtext_url !== "") {
							aResultResponse.push(oRow);
						}
					}.bind(this));
				}
				aResultResponse = aResultResponse.length === 0 ? false : aResultResponse;
				return aResultResponse;
			} catch (oError) {
				return null;
			}
		},

		_showHttpError: function(oResponse) {
			const sNewErrorText = "Error " + oResponse.statusCode + ": " + oResponse.statusText + "\n\n" + oResponse.responseText;
			if (sNewErrorText !== this._sErrorText) {
				MessageBox.error(sNewErrorText);
				this._sErrorText = sNewErrorText;
			}
		},

		/**
		 * Shows a {@link sap.m.MessageBox} when the metadata call has failed.
		 * The user can try to refresh the metadata.
		 * @param {string} sDetails a technical error to be displayed on request
		 * @private
		 */
		_showMetadataError: function(sDetails) {
			MessageBox.error(
				this._sErrorText, {
					id: "metadataErrorMessageBox",
					details: sDetails,
					styleClass: this._oComponent.getContentDensityClass(),
					actions: [MessageBox.Action.RETRY, MessageBox.Action.CLOSE],
					onClose: function(sAction) {
						if (sAction === MessageBox.Action.RETRY) {
							this._oModel.refreshMetadata();
						}
					}.bind(this)
				}
			);
		},

		/**
		 * Shows a {@link sap.m.MessageBox} when a service call has failed.
		 * Only the first error message will be display.
		 * @param {string} sDetails a technical error to be displayed on request
		 * @private
		 */
		_showServiceError: function(sDetails) {
			this._oComponent._oMessageManager.removeAllMessages();
			this._oComponent._oMessageManager.addMessages(
				new sap.ui.core.message.Message({
					message: sDetails,
					type: MessageType.Error,
					processor: this._oComponent._oMessageProcessor
				})
			);
		}
	});

});
