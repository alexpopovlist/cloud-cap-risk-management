sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"ZO2C_COM_PROD/ZO2C_COM_PROD/custom/class/Common",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/m/MessagePopover",
	"sap/m/MessageItem",
	"sap/ui/model/Filter",
	"sap/ui/model/Sorter",
	"sap/m/Token",
	"sap/m/Text",
	"sap/m/Link"
], function(Controller, Common, MessageBox, MessageToast,
	MessagePopover, MessageItem, Filter, Sorter, Token, Text, Link) {
	"use strict";

	/**
	 * @class
	 * @extends sap.ui.core.mvc.Controller
	 *
	 * @constructor
	 * @public
	 * @alias zgagarin.zsupplyproc.controller.BaseController
	 */
	var BaseController = Controller.extend(
		"ZO2C_COM_PROD.ZO2C_COM_PROD.controller.BaseController",
		/** @lends zgagarin.zsupplyproc.controller.BaseController.prototype */
		{

			common: Common,
			_oLotsAndPositionsDeleteOptionsDialog: null,

			/**
			 * Инициализирует контроллер, вызывает метод в котором определенным контролам присваиваются функции обработки события изменения.
			 */
			onInit: function() {
				this.attachFieldChangeHandler();
			},

			/**
			 * Возвращает объект роутинга.
			 * @returns {Object}
			 */
			getRouter: function() {
				return this.getOwnerComponent().getRouter();
			},

			/**
			 * Возвращает модель.
			 * @param {string} sName Название модели.
			 * @returns {Object}
			 */
			getModel: function(sName) {
				return (this.getOwnerComponent()) ? this.getOwnerComponent().getModel(sName) : this.getView().getModel(sName);
			},


			/**
			 * Возвращает конкретное свойство "state" модели.
			 * @param {string} sProperty Путь к свойству.
			 * @returns {*}
			 */
			getStateProperty: function(sProperty) {
				if (this.getModel("state")) {
					return this.getModel("state").getProperty(sProperty);
				}
			},


			/**
			 * Устанавливает новое значение конкретного свойства "state" модели.
			 * @param {string} sProperty Путь к устанавливаемому свойству.
			 * @param {*} oValue Устанавливаемое значение свойства.
			 * @param {boolean} [bMerge] Обновлять ли другие зависимые с этим свойством bindings асинхронно.
			 */
			setStateProperty: function(sProperty, oValue, bMerge) {
				if (this.getModel("state")) {
					return this.getModel("state").setProperty(sProperty, oValue, !!bMerge);
				}
			},

			/**
			 * Устанавливает или сбрасывает модель на задаваемую модель для конкретного компонента или страницы (View).
			 * @param {sap.ui.model.Model} oModel Устанавливаемая модель или null или undefined.
			 * @param {string} [sName] Имя модели, либо undefined.
			 * @returns {*}
			 */
			setModel: function(oModel, sName) {
				const oSource = (this.getOwnerComponent()) ? this.getOwnerComponent() : this.getView();
				return oSource.setModel(oModel, sName);
			},

			/**
			 * Устанавливает Busy Indicator на приложение.
			 */
			showBusy: function() {
				this.setStateProperty("/app/busy", true);
				sap.ui.core.BusyIndicator.show(0);
			},

			/**
			 * Убирает Busy Indicator из приложения.
			 */
			hideBusy: function(bSync) {
				if (bSync) {
					this.do(function() {
						this.setStateProperty("/app/busy", false);
						sap.ui.core.BusyIndicator.hide();
						this.doResolve();
					}.bind(this));
				} else {
					this.setStateProperty("/app/busy", false);
					sap.ui.core.BusyIndicator.hide();
				}
			},

			getResourceBundle: function() {
				return this.getOwnerComponent().getModel("i18n").getResourceBundle();
			},

			cleanMessageLog: function() {
				var oMM = this.getOwnerComponent().getMessageManager();
				oMM.removeAllMessages();
			},

			/**
			 * Преобразует локальный индентификатов в глабольный, уникальный, добавляя название своего м
			 * @param Id Локальный идентификатор объекта.
			 * @returns {string}
			 */
			createId: function(Id) {
				return this.getView().createId(Id);
			},

			/**
			 * Возвращает элемент с заданным ID, либо false.
			 * @param {string} sId ID элемента
			 * @returns {sap.ui.core.Control | false}
			 */
			getById: function(sId) {
				if (sap.ui.getCore().byId(sId)) {
					return sap.ui.getCore().byId(sId);
				}

				if (sap.ui.getCore().byId(this.getView().createId(sId))) {
					return sap.ui.getCore().byId(this.getView().createId(sId));
				}

				if (this.getView().byId(sId)) {
					return this.getView().byId(sId);
				}

				return false;
			},

			
			/**
			 * Возвращает контролы по заданному групповому идентификатору (FieldGroupId).
			 * @param {string} sId Общий идентификатор группы связанных друг с другом элементов.
			 * @returns {sap.ui.core.Control[]}
			 */
			getControlsByFieldGroupId: function(sId) {
				return this.getView().getControlsByFieldGroupId(sId);
			},

			/**
			 * Возвращает текст по передаваемому ключевому полю.
			 * @param {string} sKey Ключь по которому можно определить какой текст нужно вернуть.
			 * @param {*} [arArguments] Дополнительные аргументы.
			 * @returns {string}
			 */
			getText: function(sKey, arArguments) {
				return this.getModel("i18n").getResourceBundle().getText(sKey, arArguments);
			},

			/**
			 * Возвращает объект с методами Error Handler.
			 * @returns {null|*}
			 */
			getErrorHandler: function() {
				if (this.getOwnerComponent()) {
					return this.getOwnerComponent()._oErrorHandler;
				}
			},

			/**
			 * Обрабатывает вернувшийся ответ сервера при отклонении пакета запросов в oData модель.
			 * @param {Object} oBatchRequestResponse Ответ на batch.
			 */
			defaultBatchRequestErrorHandler: function(oBatchRequestResponse) {
				this.hideBusy();
				var aReturnFullErrorMessage = [];
				var aFullErrorMessage = oBatchRequestResponse.reduce(function(aFullErrorMessage, oCurrentError) {
					aFullErrorMessage.push(this.getErrorHandler().getFullBatchErrorMessage(oCurrentError));
					return aFullErrorMessage;
				}.bind(this), []);
				if (!!aFullErrorMessage && aFullErrorMessage.length > 0) {
					aFullErrorMessage.forEach(function(sItem) {
						if (sItem.trim() !== "") {
							aReturnFullErrorMessage.push(sItem);
						}
					});
				} else {
					aReturnFullErrorMessage = aFullErrorMessage;
				}

				MessageBox.error(aReturnFullErrorMessage.join());
			},

			onInLinkSelectRelation: function (oControlEvent) {
				var sObjectPath = oControlEvent.getSource().getBindingContext().getPath();
				var oEntry = {
					"LinkVariant": this.getStateProperty("/_GET").LinkVariant,
					"InLink": oControlEvent.getSource().getSelected()
				};
				
				this.getModel().update(sObjectPath,oEntry, {success: function (oData) {
						var oList = sap.ui.getCore().byId(this.getStateProperty("/app/currentView")).getControlsByFieldGroupId("idRelationList")[0];
						oList.getBinding("items").refresh(true);
					}.bind(this)
				});
			},

			/**
			 * Обрабатывает вернувшийся ответ сервера при отклонении запроса в oData модель.
			 * @param {Object} oError Ответ на запрос.
			 */
			defaultRequestErrorHandler: function(oError) {
				this.hideBusy();
				const sFullErrorMessage = this.getErrorHandler().getFullErrorMessage(oError);
				const sFullLongTextMessage = this.getErrorHandler().getFullLongTextErrorMessage(oError);
				if (!!sFullLongTextMessage) {
					var sFormattedErrorMessage = "";
					sFullLongTextMessage.forEach(function(oFullLongText, i, sFullLongTextMessage) {
						var sLongTextUrl = oFullLongText.longtext_url;
						if (sLongTextUrl) {
							jQuery.ajax({
								type: "GET",
								url: sLongTextUrl,
								success: function(data) {
									var sEnding = '<p>' + '<br />' + '</p>\n';
									sFormattedErrorMessage += jQuery.sap._sanitizeHTML('<p class="separatorForLongtextsInMessageBox">' + oFullLongText.message + '</p>\n') + jQuery.sap._sanitizeHTML(data) + jQuery.sap._sanitizeHTML(sEnding);
									if (i === sFullLongTextMessage.length - 1) {
										MessageBox.error(sFullErrorMessage, {
											styleClass: "z",
											details: sFormattedErrorMessage
										});
									}
								},
								error: function() {
									var sError = "Ошибка при загрузке длинного текста: " + sLongTextUrl;
									jQuery.sap.log.error(sError);
								}
							});
						}
					}.bind(this));
				} else {
					MessageBox.error(sFullErrorMessage);
				}
			},

			/**
			 * Формирует хэш.
			 * @param {string} sAction Параметр для определения типа объекта (Строка Плана, ЗП, Заявка на ЗП, Результат ЗП).
			 * @param {Object} [oParams] Объект, содержащий дополнительные парамерты для формирования хэша.
			 * @returns {string} Хэш.
			 * @private
			 */
			_createHash: function(sAction, oParams) {
				var sHash = this.getRouter().getURL(sAction, oParams)
				if (this.getStateProperty("/app/name") && this.getStateProperty("/app/action")) {
					sHash = (this.getStateProperty("/app/action")!=="chain") ?  this.getStateProperty("/app/name") + "-" + this.getStateProperty("/app/action") + "&/" + sHash : this._createExtHash(sAction,oParams)+ "&/" + sHash;
				}
				return sHash;
			},
			/**
			 * Формирует хэш.
			 * @param {string} sAction Параметр для определения типа объекта (Строка Плана, ЗП, Заявка на ЗП, Результат ЗП).
			 * @param {Object} [oParams] Объект, содержащий дополнительные парамерты для формирования хэша.
			 * @returns {string} Хэш.
			 * @private
			 */
			_createExtHash: function(sAction, oParams) {
				var oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");
				return oCrossAppNav.hrefForExternal({
					target: {
						semanticObject: this.getStateProperty("/app/name"),
						action:  this.getStateProperty("/app/action"),
					},
					params: {
						FilterUuid: this.getFilterUuidForChainApp(),
					}
				});
			},

			/**
			 * Метод для создания новых записей при MultiToggle
			 *  @param {sap.ui.base.Event} oEvent Объект взаимодействия с пользователем.
			 */
			onAddSelectRowsToEntityPromise:function(oEvent){
				/**
				 * Конструктор отправляемого объекта
				 * @param {Array} [aProperties] Массив свойств.
				 * @param {Object} oValues Объект записи в таблице.
				 * @param {Array} stateProperties Массив свойств для глобальных значений.
				 * @param {Array} statePropertiesPath Массив путей глобальных значений, которые нужно брать при помощи getStateProperty  ┬──┬ ノ(゜-゜ノ) (╯°□°）╯︵ ┻━┻.
				 */
				var sendObject= function(aProperties,oValues,stateProperties, statePropertiesPath){
					var property,
						stateProperty,
						statePropertyPath;

					for(var i=0; i<aProperties.length;i++){
						property= aProperties[i];
						this[property]= oValues[property];
					}

					if(stateProperties && statePropertiesPath){
						for(var i=0; i<stateProperties.length;i++){
							stateProperty= stateProperties[i];
							statePropertyPath= statePropertiesPath[i];
							if(stateProperty && statePropertyPath){
								this[stateProperty]= that.getStateProperty(statePropertyPath);
							};
						}
					}
					return;
				};
				var aPromise = [];
				var that=this;
				var oControlEvent = $.extend(true, {}, oEvent);
				var oControl = oEvent.getSource();
				var oTable = this.getControlsByFieldGroupId(oControl.data("selectedTableFieldGroup"))[0].getTable();
				var aObjectEntry=[];
				var aProperties = oControl.data('writeProperties') ? oControl.data('writeProperties').split(',') : '';
				var stateProperties =oControl.data('stateProperties') ? oControl.data('stateProperties').split(',') : undefined;
				var statePropertiesPath =oControl.data('statePropertiesPath') ? oControl.data('statePropertiesPath').split(',') : undefined;
				var selectRows = oTable.getSelectedIndices();
				for (var i = 0; i <selectRows.length; i ++) {
					if (oTable.isIndexSelected (selectRows[i])) {
						var cxt = oTable.getContextByIndex (selectRows[i]);
						var obj = oTable.getModel (). getProperty (cxt.sPath);
						aObjectEntry.push(new sendObject(aProperties,obj,stateProperties,statePropertiesPath));
					}
				};
				for(var i=0; i<aObjectEntry.length;i++){
					this.showBusy();
					var oPromise = new Promise(function (resolve, reject) {
						this.getModel().create("/" + this.createCurrentKey() +"/"+oControl.data('navProp'), aObjectEntry[i], {
							success: function(oResponse, oMessage) {
								this.hideBusy();
								this.updateTables(oControlEvent);
								resolve(oMessage);
							}.bind(this),
							error: function(oError) {
								this.hideBusy();
								reject(oError);
							}.bind(this)
						});
					}.bind(this));

					aPromise.push(oPromise);
				};

				Promise.all(aPromise).then(
					function (oMessage) {
						if (!!oMessage) {
							try {
							  var sMsg = "";
							  oMessage.forEach(function(oDataItem) {
							  	if (!!oDataItem.headers["sap-message"]) {
							  		sMsg += $.sap.parseJS(oDataItem.headers["sap-message"]).message + '\n\n';
							 	}
							  }.bind(this));

							  if(sMsg !== "") {
							  	MessageToast.show(sMsg);
							  } else {
							  	MessageToast.show(this.getResourceBundle().getText("textCreateItemsSuccess"));
							  }
							
							} catch (err) {
							  MessageToast.show(this.getResourceBundle().getText("textCreateItemsSuccess"));
							}
						} else {
							MessageToast.show(this.getResourceBundle().getText("textCreateItemsSuccess"));
						}
					}.bind(this), 
					function(oError) {
						MessageToast.show(this.getResourceBundle().getText("textCreateItemsError"));
				}.bind(this));
			},

			/**
			 * Метод для создания новых записей при MultiToggle
			 *  @param {sap.ui.base.Event} oEvent Объект взаимодействия с пользователем.
			 */
			onAddSelectRowsToEntity:function(oEvent){
				/**
				 * Конструктор отправляемого объекта
				 * @param {Array} [aProperties] Массив свойств.
				 * @param {Object} oValues Объект записи в таблице.
				 * @param {Array} stateProperties Массив свойств для глобальных значений.
				 * @param {Array} statePropertiesPath Массив путей глобальных значений, которые нужно брать при помощи getStateProperty  ┬──┬ ノ(゜-゜ノ) (╯°□°）╯︵ ┻━┻.
				 */
				var sendObject= function(aProperties,oValues,stateProperties, statePropertiesPath){
					var property,
						stateProperty,
						statePropertyPath;

					for(var i=0; i<aProperties.length;i++){
						property= aProperties[i];
						this[property]= oValues[property];
					}

					if(stateProperties && statePropertiesPath){
						for(var i=0; i<stateProperties.length;i++){
							stateProperty= stateProperties[i];
							statePropertyPath= statePropertiesPath[i];
							if(stateProperty && statePropertyPath){
								this[stateProperty]= that.getStateProperty(statePropertyPath);
							};
						}
					}
					return;
				};
				var that=this;
				var oControlEvent = $.extend(true, {}, oEvent);
				var oControl = oEvent.getSource();
				var oTable = this.getControlsByFieldGroupId(oControl.data("selectedTableFieldGroup"))[0].getTable();
				var aObjectEntry=[];
				var aProperties = oControl.data('writeProperties') ? oControl.data('writeProperties').split(',') : '';
				var stateProperties =oControl.data('stateProperties') ? oControl.data('stateProperties').split(',') : undefined;
				var statePropertiesPath =oControl.data('statePropertiesPath') ? oControl.data('statePropertiesPath').split(',') : undefined;
				var selectRows = oTable.getSelectedIndices();
				for (var i = 0; i <selectRows.length; i ++) {
					if (oTable.isIndexSelected (selectRows[i])) {
						var cxt = oTable.getContextByIndex (selectRows[i]);
						var obj = oTable.getModel (). getProperty (cxt.sPath);
						aObjectEntry.push(new sendObject(aProperties,obj,stateProperties,statePropertiesPath));
					}
				};
				for(var i=0; i<aObjectEntry.length;i++){
					this.showBusy();
					this.getModel().create("/" + this.createCurrentKey() +"/"+oControl.data('navProp'), aObjectEntry[i], {
						success: function(oResponse, oMessage) {
							this.hideBusy();
							this.updateTables(oControlEvent);
						}.bind(this),
						error: function(oError) {
							this.hideBusy();
							return false;
						}.bind(this)
					});
				};
				return true;
			},
			/**
			 * Обновление списка таблиц, указанных в CustomData
			 *  @param {sap.ui.base.Event} oEvent Объект взаимодействия с пользователем.
			 */
			updateTables:function(oEvent){
				var oControl = oEvent.getSource();
				var aProperties = oControl.data('updateFieldGroupId') ? oControl.data('updateFieldGroupId').split(',') : [];
				if(aProperties.length!==0){
					aProperties.forEach(function (oItem) {
						if(this.getControlsByFieldGroupId(oItem)[0]){
							this.refreshTable(this.getControlsByFieldGroupId(oItem)[0]);
						}
					}.bind(this));
				}
			},

			/**
			 * Устанавливает хэш.
			 * @param {string} sAction Параметр для определения типа объекта (Строка Плана, ЗП, Заявка на ЗП, Результат ЗП).
			 * @param {Object} [oParams] Объект, содержащий дополнительные парамерты для формирования хэша.
			 */
			setHash: function(sAction, oParams) {
				const sHash = this._createHash(sAction, oParams);
				this.getRouter().setHash(sHash);
			},

			/**
			 * Заменяет хэш.
			 * @param {string} sAction Параметр для определения типа объекта (Строка Плана, ЗП, Заявка на ЗП, Результат ЗП).
			 * @param {Object} [oParams] Объект, содержащий дополнительные парамерты для формирования хэша.
			 */
			replaceHash: function(sAction, oParams) {
				const sHash = this._createHash(sAction, oParams);
				this.getRouter().replaceHash(sHash);
			},

			
			/**
			 * Включает возможность автосохранения.
			 * @private
			 */
			_enableAutoSave: function() {
				var oModel = this.getModel();
				this._removeModelPropertyChangeListeners(oModel);
				const handlerFunction = this.saveChangesDelayed;
				this.setStateProperty("/modelPropertyChangeHandler", {
					handlerFunction: handlerFunction,
					listener: this
				});
				oModel.attachPropertyChange(handlerFunction, this);
			},

			
			/**
			 * Убирает слушатели события изменения данных в модели.
			 * @param {sap.ui.model.odata} oModel oData модель.
			 * @private
			 */
			_removeModelPropertyChangeListeners: function(oModel) {
				const oHandler = this.getStateProperty("/modelPropertyChangeHandler")
				if (oHandler) {
					oModel.detachPropertyChange(oHandler.handlerFunction, oHandler.listener)
				}
			},

			/**
			 * Сохраняет изменения с заданной задержкой.
			 * @param {function} fnSuccess Функция обратного вызова, выполняемая после успешного сохранения.
			 */
			saveChangesDelayed: function(fnSuccess) {
				const fnSuccessCallback = ($.isFunction(fnSuccess)) ? fnSuccess : null;
				if (this.getModel().hasPendingChanges()) {
					this.getModel().setLastSaveNow();
					this.getModel().setWaitingForSave(true);
					setTimeout(function() {
						const oNow = new Date();
						if (
							oNow.getTime() - this.getModel().getLastSave() >= this.getModel().getDelayBeforeSave() &&
							this.getModel().getWaitingForSave() &&
							this.getModel().hasPendingChanges()
						) {
							this.save(false, fnSuccess);
						}
					}.bind(this), this.getModel().getDelayBeforeSave());
				}
			},

			saveChanges: function(bRefreshAfterChange, fnSuccess) {
				this._customObjectDraftIndicator = this.getStateProperty("/app/customObjectDraftIndicator");

				this.getModel().setRefreshAfterChange(!!bRefreshAfterChange);
				if (this.getModel().hasPendingChanges()) {
					this.getModel().setLastSaveNow();
					this._customObjectDraftIndicator.setText(this.getText("Saving"));
					this.getModel().submitChanges({
						success: function(oResponse, oMessage) {
							const bIsError = oResponse.__batchResponses.some(function(oBatchResponse) {
								if (oBatchResponse.__changeResponses && oBatchResponse.__changeResponses.length) {
									return oBatchResponse.__changeResponses.some(function(oChangeResponse) {
										return ["400"].indexOf(oChangeResponse.statusCode) >= 0;
									})
								} else {
									return (oBatchResponse && oBatchResponse.response) ? ["400"].indexOf(oBatchResponse.response.statusCode) >= 0 : false;
								}
							});
							if (!bIsError) {
								const iDisplayTime = 400;
								this._customObjectDraftIndicator.setText(this.getText("Saved"));
								setTimeout(function() {
									this._customObjectDraftIndicator.setText("");
								}.bind(this), 4000);
							} else {
								this.defaultBatchRequestErrorHandler(oResponse.__batchResponses);
								this.getModel().resetChanges();
							}
							if ($.isFunction(fnSuccess)) {
								fnSuccess.apply(this);
							}
						}.bind(this),
						error: function(oError) {
							this.hideBusy();
							this.getModel().resetChanges();
							this.defaultRequestErrorHandler(oError);
							if ($.isFunction(fnSuccess)) {
								fnSuccess.apply(this);
							}
						}.bind(this)
					});
				} else {
					this._customObjectDraftIndicator.setText("");
					if ($.isFunction(fnSuccess)) {
						fnSuccess.apply(this);
					}
				}
			},

			/**
			 * Сохраняет все изменения, после чего запускает функцию обратного вызова.
			 * @param {boolean} [bRefreshAfterChange] Если true, то обновит биндинги после сохранения изменений.
			 * @param {function} fnSuccess Функция обратного вызова после успешного сохранения данных.
			 */
			save: function(bRefreshAfterChange, fnSuccess) {
				this.getModel().setRefreshAfterChange(!!bRefreshAfterChange);
				this.do(
					function() {
						if (this.getModel().hasPendingChanges()) {
							this.getModel().setLastSaveNow();
							this._customObjectDraftIndicator.setText(this.getText("Saving"));
							this.getModel().submitChanges({
								success: function(oResponse, oMessage) {
									const bIsError = oResponse.__batchResponses.some(function(oBatchResponse) {
										if (oBatchResponse.__changeResponses && oBatchResponse.__changeResponses.length) {
											return oBatchResponse.__changeResponses.some(function(oChangeResponse) {
												return ["400"].indexOf(oChangeResponse.statusCode) >= 0;
											})
										} else {
											return (oBatchResponse && oBatchResponse.response) ? ["400"].indexOf(oBatchResponse.response.statusCode) >= 0 : false;
										}
									});

									if (!bIsError) {
										this._customObjectDraftIndicator.setText(this.getText("Saved"));
										setTimeout(function() {
											this._customObjectDraftIndicator.setText("");
										}.bind(this), 4000);

										this.doResolve(oResponse, oMessage);
									} else {
										this.defaultBatchRequestErrorHandler(oResponse.__batchResponses);
										this.getModel().resetChanges();
										this.doReject(oResponse.__batchResponses);
									}
									this.getView().getModel().refresh();
								}.bind(this),
								error: function(oError) {
									this.hideBusy();
									this.getModel().resetChanges();
									this.defaultRequestErrorHandler(oError);
									this.doReject(oError);
								}.bind(this)
							});
						} else {
							this._customObjectDraftIndicator.setText("");
							this.doResolve();
						}
					}.bind(this)
				);

				if ($.isFunction(fnSuccess)) {
					this.do(function() {
						fnSuccess.apply(this);
					});
				}
			},
			showRequestError: function(oError) {
				MessageBox.error(JSON.parse(oError.responseText).error.message.value);
			},
			/**
			 * Обновляет зависимые поля, определяемые с помощью fieldGroupId и параметов идентификации.
			 * @param {sap.ui.base.Event} oControlEvent Изменение значения поля.
			 * @param {string} oControlEvent.getSource().data("updateFieldGroupId") один или несколько (через запятую) fieldGroupId, для элементов которых происходит обновление в
			 * случае, если есть совпадение по groupIdentifier.
			 * @param {string} oControlEvent.getSource().data("groupIdentifier") один или несколько (через запятую) GUID, для которых будет выполнено обновление. Должен быть
			 * проставлен как в текущем контроле, так и зависимых контролах. В зависимых контролах также должен быть указан
			 * список полей для обновления через запятую (fields).
			 */
			calculatedFieldChange: function(oControlEvent) {
				const oModel = this.getModel();
				const aGroupIdentifiers = oControlEvent.getSource().data("groupIdentifier").split(",");
				const aUpdateFieldGroupIds = !!oControlEvent.getSource().data("updateFieldGroupId") ? oControlEvent.getSource().data("updateFieldGroupId").split(",") : false;
				if (!!oControlEvent.getSource().data("tabReload")) {
					oControlEvent.getSource().data("tabReload").split(",").forEach(function(sTab) {
						this.setStateProperty("/tabReload/" + sTab + "/value", true);
					}.bind(this));
				}
				const aReadRequests = aUpdateFieldGroupIds === false ? [] : aUpdateFieldGroupIds.reduce(function(aReadRequests, sFieldGroupid) {
					var aControls = sap.ui.getCore().byFieldGroupId(sFieldGroupid);
					var aFilteredRequestMap = aControls.filter(function(oControl) {
						const aIdent = oControl.data("groupIdentifier");
						if (aIdent) {
							return aIdent.split(",").every(function(sIdent) {
									return aGroupIdentifiers.some(function(sSourceIdent) {
										return sSourceIdent === sIdent;
									});
								}) ||
								aGroupIdentifiers.every(function(sIdent) {
									return aIdent.split(",").some(function(sSourceIdent) {
										return sSourceIdent === sIdent;
									});
								});
						} else {
							return false;
						}
					}.bind(this));
					var aRequestMap = aFilteredRequestMap.reduce(function(aRequestMap, oControl) {
						const sBindingContextPath = oControl.getBindingContext().getPath();
						if (oControl.data("fields")) {
							const aFields = oControl.data("fields").split(",");
							if (!aRequestMap.hasOwnProperty(sBindingContextPath)) {
								aRequestMap[sBindingContextPath] = aFields;
							} else {
								var mCheckMap = {};
								aRequestMap[sBindingContextPath].forEach(function(item) {
									mCheckMap[item] = true;
								});
								aFields.forEach(function(item) {
									mCheckMap[item] = true;
								});
								aRequestMap[sBindingContextPath] = Object.keys(mCheckMap);
							}
						}
						return aRequestMap;
					}, {});
					var aRequestMapObjectKeys = Object.keys(aRequestMap);
					var oCurrentRequestsPreMap = aRequestMapObjectKeys.map(function(sKey) {
						return {
							path: sKey,
							fields: aRequestMap[sKey]
						}
					});
					var oCurrentRequests = oCurrentRequestsPreMap.map(function(oPathFieldRecord) {
						return function() {
							oModel.read(oPathFieldRecord.path, {
								urlParameters: {
									"$select": oPathFieldRecord.fields.join(","),
									"$expand": oPathFieldRecord.fields.filter(function(sPath) {
										return sPath.split("/").length > 1;
									}).map(function(sPath) {
										return sPath.split("/")[0];
									}).join(",")
								},
								success: function(oResponse, oData) {
									this.hideBusy();
								}.bind(this)
							});
						}.bind(this)
					}.bind(this));
					return aReadRequests.concat(oCurrentRequests);
				}.bind(this), []);
				this.getPageController().save();
				this.do(function() {
					if (aReadRequests.length) {
						aReadRequests.forEach(function(fnRead) {
							fnRead();
						}, this);
						this.attachResolveOnBatchComplete();
					} else {
						this.hideBusy();
						this.doResolve();
					}
				});
			},

			
			/**
			 * Обновляет данные таблицы. Устанавливает путь биндинга таблицы, если его нет.
			 * @param {string} sId Идентификатор таблицы для обновления.
			 * @param {string} [sRelativeTableBindingPath] Путь для задания биндинга таблицы.
			 */
			executeRefreshSmartTable: function(sId, sRelativeTableBindingPath) {
				var oSmartTable = this.getById(sId);
				if (oSmartTable && oSmartTable.getMetadata().getName() === "sap.ui.comp.smarttable.SmartTable") {
					var sTableBindingPath = "/" + this.createCurrentKey() + "/" + sRelativeTableBindingPath;
					oSmartTable.setTableBindingPath(sTableBindingPath);
					if (!!this.getStateProperty("/_GET").bChangeLog) {
						this.refreshTable(oSmartTable, null, true);
					} else {
						this.refreshTable(oSmartTable);
					}
				}
			},

			executeRefreshSmartTableViaFieldGroupIds: function(sFieldGroupIds, sRelativeTableBindingPath) {
				var oSmartTable = this.getControlsByFieldGroupId(sFieldGroupIds)[0];
				if (oSmartTable && oSmartTable.getMetadata().getName() === "sap.ui.comp.smarttable.SmartTable") {
					var sTableBindingPath = "/" + this.createCurrentKey() + "/" + sRelativeTableBindingPath;
					oSmartTable.setTableBindingPath(sTableBindingPath);
					this.refreshTable(oSmartTable);
				}
			},

			executeSimpleRefreshSmartTable: function(sId, sRelativeTableBindingPath) {
				var oSmartTable = this.getControlsByFieldGroupId(sId)[0];
				if (oSmartTable && oSmartTable.getMetadata().getName() === "sap.ui.comp.smarttable.SmartTable") {
					if (oSmartTable.getId().indexOf(sId) > -1) {
						var sTableBindingPath = "/" + sRelativeTableBindingPath;
						oSmartTable.setTableBindingPath(sTableBindingPath);
						this.refreshTable(oSmartTable);
					}
				}
			},

			executeCountRequest: function(sFieldGroupIds, sRelativeTableBindingPath, sSearchValue, aFilters) {
				this.showBusy();
				var oSmartTable = this.getControlsByFieldGroupId(sFieldGroupIds)[0];
				if (oSmartTable && oSmartTable.getMetadata().getName() === "sap.ui.comp.smarttable.SmartTable") {
					var sCountPath = "/" + this.createCurrentKey() + "/" + sRelativeTableBindingPath + "/$count";
					this.getModel().read(sCountPath, {
						filters: aFilters,
						urlParameters: {
							"search": sSearchValue
						},
						success: function(oResponse) {
							this.hideBusy();
							if (this.getStateProperty("/_GET").Tab === "Classif") {
								this.setStateProperty("/count/Classif", oResponse);
							}
							if (this.getStateProperty("/_GET").Tab === "Chemical") {
								this.setStateProperty("/count/Chemical", parseInt(oResponse, 10) / 4);
							}
						}.bind(this),
						error: function(oError) {
							this.hideBusy();
						}.bind(this)
					});
				}
			},

			_executeCreateFilter: function(oUrlParam, bSaveHistory) {
				var sFilterUuid = this.getFilterUuidForChainApp();
				var sFIName = !!sFilterUuid ? '/CreateChainVisFilter' : '/CreateFilter';
				if(sFilterUuid){
					oUrlParam["FilterUuid"]= sFilterUuid;
				}
				this.showBusy();
				this.getModel().callFunction(sFIName, {
					method: "POST",
					urlParameters: oUrlParam,
					success: function(oData, oMessage) {
						this.hideBusy();
						if (!!oData && !!oData.Uuid) {
							this.getRouter().navTo("objectPageSearch", {
								AppMode: "search",
								CodeCp: oData.Uuid,
								Tab: "General"
							}, bSaveHistory);
						}
						MessageToast.show(this.getResourceBundle().getText("successCreateFilter"));
					}.bind(this),
					error: function(oError) {
						this.hideBusy();
						MessageBox.error(this.parseRequestError(oError));
					}.bind(this)
				});
			},
			getFilterUuidForChainApp: function(){
				return this.getOwnerComponent().getComponentData()
					&& this.getOwnerComponent().getComponentData().startupParameters
					&& this.getOwnerComponent().getComponentData().startupParameters.FilterUuid
					&& this.getOwnerComponent().getComponentData().startupParameters.FilterUuid[0];
			},

			_executeCreateFilterByTemplate: function(oUrlParam, bSaveHistory) {
				this.showBusy();
				this.getModel().callFunction("/CreateFilterByTemplate", {
					method: "POST",
					urlParameters: oUrlParam,
					success: function(oData, oMessage) {
						this.hideBusy();
						if (!!oData && !!oData.Uuid) {
							this.getRouter().navTo("objectPageSearch", {
								AppMode: "search",
								CodeCp: oData.Uuid,
								Tab: "General"
							}, bSaveHistory);
						}
						MessageToast.show(this.getResourceBundle().getText("successCreateFilterByTemplate"));
					}.bind(this),
					error: function(oError) {
						this.hideBusy();
						MessageBox.error(this.parseRequestError(oError));
					}.bind(this)
				});
			},

			_executeSaveTemplate: function(oUrlParam, bSaveHistory) {
				this.showBusy();
				this.getModel().callFunction("/CreateTemplate", {
					method: "POST",
					urlParameters: oUrlParam,
					success: function(oData, oMessage) {
						this.hideBusy();
						if (!!oData && !!oData.Uuid) {
							this.getRouter().navTo("objectPageSearch", {
								AppMode: "search",
								CodeCp: oData.Uuid,
								Tab: "General"
							}, bSaveHistory);
						}
						MessageToast.show(this.getResourceBundle().getText("successCreateFilterByTemplate"));
					}.bind(this),
					error: function(oError) {
						this.hideBusy();
						MessageBox.error(this.parseRequestError(oError));
					}.bind(this)
				});
			},

			_executeCreateNewCP: function(oUrlParam, bSaveHistory) {
				this.showBusy();
				this.getModel().callFunction("/CreateCP", {
					method: "POST",
					urlParameters: oUrlParam,
					success: function(oData, oMessage) {
						this.hideBusy();
						if (!!oData && !!oData.CodeCp && !!oData.StatusCp) {

							if (this.getStateProperty("/_GET").AppMode === "edit"){
								this.cleanMessageLog();
							}

							this.getOwnerComponent()._oMessageManager.removeAllMessages();

							this.getRouter().navTo("objectPage", {
								AppMode: "create",
								CodeCp: oData.CodeCp,
								StatusCp: oData.StatusCp,
								Tab: "General"
							}, bSaveHistory);
						}
					}.bind(this),
					error: function(oError) {
						this.hideBusy();
						MessageBox.error(this.parseRequestError(oError));
					}.bind(this)
				});
			},

			_executeSaveTemplate: function(oUrlParam, bSaveHistory) {
				this.showBusy();
				this.getModel().callFunction("/CreateTemplate", {
					method: "POST",
					urlParameters: oUrlParam,
					success: function(oData, oMessage) {
						this.hideBusy();
						MessageToast.show(this.getResourceBundle().getText("successSaveTemplate"));
					}.bind(this),
					error: function(oError) {
						this.hideBusy();
						MessageBox.error(this.parseRequestError(oError));
					}.bind(this)
				});
			},

			_executeResetFilter: function(oUrlParam, bSaveHistory) {
				this.showBusy();
				this.getModel().callFunction("/ResetFilter", {
					method: "POST",
					urlParameters: oUrlParam,
					success: function(oData, oMessage) {
						this.hideBusy();
						MessageToast.show(this.getResourceBundle().getText("successResetFilter"));
						if (this.getStateProperty("/_GET").Tab === "General") {
							this.setStateProperty("/app/rerenderEInput/General", true);
							this.getSelectedTabController().processLoad(true);
						}
						if (this.getStateProperty("/_GET").Tab === "Technical") {
							var oSmartTable = this.getControlsByFieldGroupId("TechnicalSearchCPSmartTable")[0];
							oSmartTable.getTable().getBinding("rows").refresh(true);
						}
						if (this.getStateProperty("/_GET").Tab === "Mechanical") {
							var oSmartTable = this.getControlsByFieldGroupId("MechanicalCPSmartTable")[0];
							oSmartTable.getTable().getBinding("rows").refresh(true);
						}
						if (this.getStateProperty("/_GET").Tab === "Classif") {
							var oSmartTable = this.getControlsByFieldGroupId("ClassifSmartTable")[0];
							oSmartTable.getTable().getBinding("rows").refresh(true);
						}
						if (this.getStateProperty("/_GET").Tab === "Chemical") {
							this.setStateProperty("/oSearchChemicalValueEnableESelect", {});
							this.getSelectedTabController().processLoad(true);
						}
						if (this.getStateProperty("/_GET").Tab === "ProfileSize") {
							var oSmartTableProfile = this.getControlsByFieldGroupId("ProfileSearchSmartTable")[0];
							oSmartTableProfile.getTable().getBinding("items").refresh(true);
							var oSmartTableProfileSize = this.getControlsByFieldGroupId("ProfileSizeSearchSmartTable")[0];
							oSmartTableProfileSize.getTable().getBinding("items").refresh(true);
						}
						if (this.getStateProperty("/_GET").Tab === "OtherCharact") {
							var oSmartTable = this.getControlsByFieldGroupId("OtherCharactSearchSmartTable")[0];
							oSmartTable.getTable().getBinding("rows").refresh(true);
						}
						if (this.getStateProperty("/_GET").Tab === "RAL") {
							var oSmartTableRALFace = this.getControlsByFieldGroupId("RALFaceSearchSmartTable")[0];
							oSmartTableRALFace.getTable().getBinding("items").refresh(true);
							var oSmartTableRALBack = this.getControlsByFieldGroupId("RALBackSearchSmartTable")[0];
							oSmartTableRALBack.getTable().getBinding("items").refresh(true);
						}
						if (this.getStateProperty("/_GET").Tab === "DecorativeTape") {
							var oSmartTableDecorativeTape = this.getControlsByFieldGroupId("DecorativeTapeSearchSmartTable")[0];
							oSmartTableDecorativeTape.getTable().getBinding("items").refresh(true);
						}
						if (this.getStateProperty("/_GET").Tab === "General") {
							this.getSelectedTabController().processLoad(true);
						}
					}.bind(this),
					error: function(oError) {
						this.hideBusy();
						MessageBox.error(this.parseRequestError(oError));
					}.bind(this)
				});
			},

			_executeEditCP: function(oUrlParam, bSaveHistory) {
				this.showBusy();
				this.getModel().callFunction("/EditCP", {
					method: "POST",
					urlParameters: oUrlParam,
					success: function(oData, oMessage) {
						this.hideBusy();

						if (!!oData && !!oData.CodeCp && !!oData.StatusCp) {

							if (this.getStateProperty("/_GET").AppMode === "create"){
								this.cleanMessageLog();
							}

							this.getRouter().navTo("objectPage", {
								AppMode: "edit",
								CodeCp: oData.CodeCp,
								StatusCp: oData.StatusCp,
								Tab: this.getStateProperty("/_GET").Tab
							}, bSaveHistory);
						}
					}.bind(this),
					error: function(oError) {
						this.hideBusy();
						MessageBox.error(this.parseRequestError(oError));
					}.bind(this)
				});
			},

			_executeCreateCPByTemplate: function(oUrlParam, bSaveHistory) {
				this.showBusy();
				this.getModel().callFunction("/CreateCPByTemplate", {
					method: "POST",
					urlParameters: oUrlParam,
					success: function(oData, oMessage) {
						this.hideBusy();
						if (!!oData && !!oData.CodeCp && !!oData.StatusCp) {
							this.getRouter().navTo("objectPage", {
								AppMode: "create",
								CodeCp: oData.CodeCp,
								StatusCp: oData.StatusCp,
								Tab: "General"
							}, bSaveHistory);
						}
					}.bind(this),
					error: function(oError) {
						this.hideBusy();
						MessageBox.error(this.parseRequestError(oError));
					}.bind(this)
				});
			},

			_executeGetCPInSearchResult: function(oUrlParam, bSaveHistory) {
				this.showBusy();
				this.getModel().callFunction("/GetCPInSearchResult", {
					method: "POST",
					urlParameters: oUrlParam,
					success: function(oData, oMessage) {
						this.hideBusy();
						if (!!oData && !!oData.CodeCp && !!oData.StatusCp) {
							this.getRouter().navTo("objectPage", {
								AppMode: "view",
								CodeCp: oData.CodeCp,
								StatusCp: oData.StatusCp,
								Tab: this.getStateProperty("/_GET").Tab
							}, bSaveHistory);
						}
					}.bind(this),
					error: function(oError) {
						this.hideBusy();
						MessageBox.error(this.parseRequestError(oError));
					}.bind(this)
				});
			},

			_executeCancelChanges: function(oUrlParam, bSaveHistory) {
				this.showBusy();
				this.getModel().callFunction("/CancelChanges", {
					method: "POST",
					urlParameters: oUrlParam,
					success: function(oData, oMessage) {
						this.hideBusy();
						if (this.getStateProperty("/_GET").AppMode === "edit") {
							if (this.getStateProperty("/_GET").Tab === "General") {
								this.getRouter().navTo("objectPage", {
									AppMode: "view",
									CodeCp: oData.CodeCp,
									StatusCp: oData.StatusCp,
									Tab: "Technical"
								}, bSaveHistory);
							} else {
								this.getRouter().navTo("objectPage", {
									AppMode: "view",
									CodeCp: oData.CodeCp,
									StatusCp: oData.StatusCp,
									Tab: this.getStateProperty("/_GET").Tab
								}, bSaveHistory);
							}
						} else if (this.getStateProperty("/_GET").AppMode === "create") {
							this.getOwnerComponent()._oMessageManager.removeAllMessages();

							if (!!this.getStateProperty("/applyFilter").FilterUuid) {
								this.getRouter().navTo("objectPageSearch", {
									AppMode: "search",
									CodeCp: this.getStateProperty("/applyFilter").FilterUuid,
									Tab: "General"
								}, bSaveHistory);
							} else {
								this._executeCreateFilter({}, true);
							}
						}
					}.bind(this),
					error: function(oError) {
						this.hideBusy();
						MessageBox.error(this.parseRequestError(oError));
					}.bind(this)
				});
			},

			_getAssimErrorRowFilters: function(bAssimilate, bErrorRow, aBindingParamfilters) {
				var aFilters = !!aBindingParamfilters ? aBindingParamfilters : [];
				if (bErrorRow || bAssimilate){
					if (!(bErrorRow && bAssimilate)) {
						if (!bErrorRow) {
							aFilters.push(new Filter("ErrorRow", "EQ", bErrorRow));
						}
						if (!bAssimilate) {
							aFilters.push(new Filter("Assimilate", "EQ", !bAssimilate));
						}
					}
				} else {
						aFilters.push(new Filter("ErrorRow", "EQ", false));
						aFilters.push(new Filter("Assimilate", "EQ", true));
				}
				return aFilters;
			},

			_onErrorRowOnTablePress: function(oControlEvent, fnSuccess, bRefresh) {
				var sPath = oControlEvent.getSource().getBindingContext().getPath();
				this.saveChanges(false, function() {
					if (bRefresh !== false) {
						this.getModel().read(sPath);
					}
					if (jQuery.isFunction(fnSuccess)) {
						fnSuccess();
					}
				}.bind(this));
			},

			_onAssimilateOnTablePress: function (oControlEvent, fnSuccess, bRefresh) {
				var oCotext = oControlEvent.getSource().getBindingContext();
				var sPath = oCotext.getPath();
				var bVal = oControlEvent.getParameter("selected");
				this.getModel().setProperty(oCotext.getPath() + "/Assimilate",bVal);
				this.saveChanges(false, function() {
					if (bRefresh !== false) {
						this.getModel().read(sPath);
					}
					if (jQuery.isFunction(fnSuccess)) {
						fnSuccess();
					}
				}.bind(this));
			},

			_executeSaveCP: function(oUrlParam, bSaveHistory) {
				this.showBusy();
				this.getModel().callFunction("/SaveCP", {
					method: "POST",
					urlParameters: oUrlParam,
					success: function(oData, oMessage) {
						this.hideBusy();
						if (!!oData && !!oData.CodeCp && !!oData.StatusCp) {
							var sCurrentTab = this.getStateProperty("/_GET").Tab;
							if (sCurrentTab === "General") {
								sCurrentTab = "Technical";
							}
							this.getRouter().navTo("objectPage", {
								AppMode: "view",
								CodeCp: oData.CodeCp,
								StatusCp: oData.StatusCp,
								Tab: sCurrentTab
							}, bSaveHistory);
						}
						MessageToast.show(this.getResourceBundle().getText("successSaveCP"));
					}.bind(this),
					error: function(oError) {
						this.hideBusy();
						MessageBox.error(this.parseRequestError(oError));
					}.bind(this)
				});
			},

			_executeClearFilterView: function(oUrlParam, bSaveHistory) {
				this.showBusy();
				this.getModel().callFunction("/ClearFilterView", {
					method: "POST",
					urlParameters: oUrlParam,
					success: function(oData, oMessage) {
						this.hideBusy();
						MessageToast.show(this.getResourceBundle().getText("successClearFilterView"));
						if (this.getStateProperty("/_GET").Tab === "General") {
							this.setStateProperty("/app/rerenderEInput/General", true);
							this.getSelectedTabController().processLoad(true);
						}
						if (this.getStateProperty("/_GET").Tab === "Technical") {
							var oSmartTable = this.getControlsByFieldGroupId("TechnicalSearchCPSmartTable")[0];
							oSmartTable.getTable().getBinding("rows").refresh(true);
						}
						if (this.getStateProperty("/_GET").Tab === "Mechanical") {
							var oSmartTable = this.getControlsByFieldGroupId("MechanicalCPSmartTable")[0];
							oSmartTable.getTable().getBinding("rows").refresh(true);
						}
						if (this.getStateProperty("/_GET").Tab === "Classif") {
							var oSmartTable = this.getControlsByFieldGroupId("ClassifSmartTable")[0];
							oSmartTable.getTable().getBinding("rows").refresh(true);
						}
						if (this.getStateProperty("/_GET").Tab === "Chemical") {
							this.setStateProperty("/oSearchChemicalValueEnableESelect", {});
							this.getSelectedTabController().processLoad(true);
						}
						if (this.getStateProperty("/_GET").Tab === "ProfileSize") {
							var oSmartTableProfile = this.getControlsByFieldGroupId("ProfileSearchSmartTable")[0];
							oSmartTableProfile.getTable().getBinding("items").refresh(true);
							var oSmartTableProfileSize = this.getControlsByFieldGroupId("ProfileSizeSearchSmartTable")[0];
							if (oSmartTableProfileSize.getTable().getBinding("items")) {
								oSmartTableProfileSize.getTable().getBinding("items").refresh(true);
							}
						}
						if (this.getStateProperty("/_GET").Tab === "OtherCharact") {
							var oSmartTable = this.getControlsByFieldGroupId("OtherCharactSearchSmartTable")[0];
							oSmartTable.getTable().getBinding("rows").refresh(true);
						}
						if (this.getStateProperty("/_GET").Tab === "RAL") {
							var oSmartTableRALFace = this.getControlsByFieldGroupId("RALFaceSearchSmartTable")[0];
							oSmartTableRALFace.getTable().getBinding("items").refresh(true);
							var oSmartTableRALBack = this.getControlsByFieldGroupId("RALBackSearchSmartTable")[0];
							if (oSmartTableRALBack.getTable().getBinding("items")) {
								oSmartTableRALBack.getTable().getBinding("items").refresh(true);
							}
						}
						if (this.getStateProperty("/_GET").Tab === "DecorativeTape") {
							var oSmartTable = this.getControlsByFieldGroupId("DecorativeTapeSearchSmartTable")[0];
							oSmartTable.getTable().getBinding("rows").refresh(true);
						}
						if (this.getStateProperty("/_GET").Tab === "General") {
							this.getSelectedTabController().processLoad(true);
						}
					}.bind(this),
					error: function(oError) {
						this.hideBusy();
						MessageToast.show(this.getResourceBundle().getText("errorClearFilterView"));
					}.bind(this)
				});
			},

			_executeSaveView: function(oUrlParam, bSaveHistory) {
				this.showBusy();
				this.getModel().callFunction("/SaveView", {
					method: "POST",
					urlParameters: oUrlParam,
					success: function(oData, oMessage) {
						this.hideBusy();
						MessageToast.show(this.getResourceBundle().getText("successSaveView"));
					}.bind(this),
					error: function(oError) {
						this.hideBusy();
						MessageToast.show(this.getResourceBundle().getText("errorSaveView"));
					}.bind(this)
				});
			},

			_executeCheckCP: function(oUrlParam, bSaveHistory) {
				this.showBusy();
				this.getModel().callFunction("/CheckCP", {
					method: "POST",
					urlParameters: oUrlParam,
					success: function(oData, oMessage) {
						this.hideBusy();
						MessageToast.show(this.getResourceBundle().getText("successCheckCP"));
					}.bind(this),
					error: function(oError) {
						this.hideBusy();
						MessageToast.show(this.getResourceBundle().getText("errorCheckCP"));
					}.bind(this)
				});
			},

			_executeClearCPView: function(oUrlParam, bSaveHistory) {
				this.showBusy();
				this.getModel().callFunction("/ClearCPView", {
					method: "POST",
					urlParameters: oUrlParam,
					success: function(oData, oMessage) {
						this.hideBusy();
						MessageToast.show(this.getResourceBundle().getText("successClearCPView"));
						if (this.getStateProperty("/_GET").Tab === "Technical") {
							var oSmartTable = this.getControlsByFieldGroupId("TechnicalCPSmartTable")[0];
							oSmartTable.getTable().getBinding("rows").refresh(true);
						}
						if (this.getStateProperty("/_GET").Tab === "Mechanical") {
							var oSmartTable = this.getControlsByFieldGroupId("MechanicalCPSmartTable")[0];
							oSmartTable.getTable().getBinding("rows").refresh(true);
						}
						if (this.getStateProperty("/_GET").Tab === "Classif") {
							var oSmartTable = this.getControlsByFieldGroupId("ClassifSmartTable")[0];
							oSmartTable.getTable().getBinding("rows").refresh(true);
						}
						if (this.getStateProperty("/_GET").Tab === "Chemical") {
							var oSmartTable = this.getControlsByFieldGroupId("smartTableChemicalComposition")[0];
							oSmartTable.getTable().getBinding("rows").refresh(true);
						}
						if (this.getStateProperty("/_GET").Tab === "ProfileSize") {
							var oSmartTableProfile = this.getControlsByFieldGroupId("ProfileSmartTable")[0];
							oSmartTableProfile.getTable().getBinding("items").refresh(true);
							var oSmartTableProfileSize = this.getControlsByFieldGroupId("ProfileSizeSmartTable")[0];
							if (oSmartTableProfileSize.getTable().getBinding("items")) {
								oSmartTableProfileSize.getTable().getBinding("items").refresh(true);
							}
						}
						if (this.getStateProperty("/_GET").Tab === "OtherCharact") {
							var oSmartTable = this.getControlsByFieldGroupId("OtherCharactSmartTable")[0];
							oSmartTable.getTable().getBinding("rows").refresh(true);
						}
						if (this.getStateProperty("/_GET").Tab === "RAL") {
							var oSmartTableRALFace = this.getControlsByFieldGroupId("RALFaceSmartTable")[0];
							oSmartTableRALFace.getTable().getBinding("items").refresh(true);
							var oSmartTableRALBack = this.getControlsByFieldGroupId("RALBackSmartTable")[0];
							if (oSmartTableRALBack.getTable().getBinding("items")) {
								oSmartTableRALBack.getTable().getBinding("items").refresh(true);
							}
						}
						if (this.getStateProperty("/_GET").Tab === "DecorativeTape") {
							var oSmartTableDecorativeTape = this.getControlsByFieldGroupId("DecorativeTapeSmartTable")[0];
							oSmartTableDecorativeTape.getTable().getBinding("rows").refresh(true);
						}
					}.bind(this),
					error: function(oError) {
						this.hideBusy();
						MessageToast.show(this.getResourceBundle().getText("errorClearCPView"));
					}.bind(this)
				});
			},

			_executeActualizeCPRecords: function(oUrlParam, bSaveHistory) {
				this.showBusy();
				this.getModel().callFunction("/SetActual", {
					method: "POST",
					urlParameters: oUrlParam,
					success: function(oData, oMessage) {
						this.hideBusy();
						MessageToast.show(this.getResourceBundle().getText("successActualizeCPRecords"));
					}.bind(this),
					error: function(oError) {
						this.hideBusy();
						MessageToast.show(this.getResourceBundle().getText("errorActualizeCPRecords"));
					}.bind(this)
				});
			},

			_executeCheckOnRelation: function(oUrlParam, bSaveHistory) {
				this.showBusy();
				this.getModel().callFunction("/CheckLinkCP", {
					method: "POST",
					urlParameters: oUrlParam,
					success: function(oData, oMessage) {
						this.hideBusy();
						MessageToast.show(this.getResourceBundle().getText("successCheckLinkCP"));
					}.bind(this),
					error: function(oError) {
						this.hideBusy();
						MessageToast.show(this.getResourceBundle().getText("errorCheckLinkCP"));
					}.bind(this)
				});
			},

			/**
			 * Устанавливает контролу функцию для обработки события изменения.
			 * @param {Object} oControl Контрол
			 * @param {function} fnCallBack Функция для обработки события изменения.
			 * @private
			 */
			_attachChangeEvent: function(oControl, fCallback) {
				switch (oControl.getMetadata().getElementName()) {
					case "sap.m.CheckBox":
						oControl.attachSelect(fCallback, this);
						break;
					case "sap.m.Text":
						oControl.attachEvent("change", fCallback, this);
						break;
					default:
						oControl.attachChange(fCallback, this);
				}
			},

			/**
			 * Привязывает к контролам, у которых FieldGroupId установлен "refreshAfterUpdate", обработчик события изменения.
			 */
			attachFieldChangeHandler: function() {
				const aControls = this.getView().getControlsByFieldGroupId("refreshAfterUpdate");
				aControls.forEach(function(oControl) {
					this._attachChangeEvent(oControl, function() {
						this.getModel().setRefreshAfterChange(true);
					}.bind(this));
				}, this);
			},

			
			/**
			 * Ожидает выполнения всех текущих запросов, после чего выполняет функции обратного вызова.
			 * @param {function} fnSuccess Функция обратного вызова после успешного выполнения всех запросов.
			 * @param {object[]} [aSuccessArguments] Агрументы, передаваемые в fnSuccess.
			 * @param {function} [fnError] Функция обратного вызова после ошибки при выполнеии запроса.
			 * @param {object[]} [aErrorArguments] Агрументы, передаваемые в fnError.
			 */
			do: function(fnSuccess, aSuccessArguments, fnError, aErrorArguments) {
				if (this.getView().getId() !== this.getPageView().getId()) {
					this.getPageController().do(fnSuccess, aSuccessArguments, fnError, aErrorArguments);
				} else {
					if (!fnSuccess && !fnError) {
						return;
					}

					if (!aSuccessArguments) {
						aSuccessArguments = [];
					}

					var fnPromisedError = (!!fnError) ? fnError : fnSuccess;
					var aPromisedErrorArguments = (!!aErrorArguments) ? aErrorArguments : aSuccessArguments;

					this.getModel()._do = this.getModel()._do.then(
						function() {
							return new Promise(
								function(resolve, reject) {
									this.getModel()._doFn = fnSuccess;
									this.getModel()._doResolve = resolve;
									this.getModel()._doReject = reject;
									fnSuccess.apply(this, aSuccessArguments);
								}.bind(this)
							);
						}.bind(this),
						function() {
							return new Promise(
								function(resolve, reject) {
									this.getModel()._doFn = fnPromisedError;
									this.getModel()._doResolve = resolve;
									this.getModel()._doReject = reject;
									aPromisedErrorArguments.push(resolve, reject);
									fnPromisedError.apply(this, aPromisedErrorArguments);
								}.bind(this)
							);
						}.bind(this)
					);
				}
			},

			/**
			 * Resolve для метода <code>do</code> в случае, когда запрос успешно выполнен.
			 */
			doResolve: function() {
				if (this.getView().getId() !== this.getPageView().getId()) {
					this.getPageController().getModel()._doResolve.apply(this, arguments);
				} else {
					this.getModel()._doResolve.apply(this, arguments);
				}
			},

			/**
			 * Reject для метода <code>do</code> в случае, когда запрос не был успешно выполнен.
			 */
			doReject: function() {
				if (this.getView().getId() !== this.getPageView().getId()) {
					this.getPageController().getModel()._doReject.apply(this, arguments);
				} else {
					this.getModel()._doReject.apply(this, arguments);
				}
			},

			/**
			 * Добавляет Resolve к батч запросу по его выполнению.
			 */
			attachResolveOnBatchComplete: function() {
				this.getModel().attachEventOnce("batchRequestCompleted", function() {
					this.doResolve.apply(this, arguments);
				}.bind(this));
			},


			/**
			 * Открывает диалог с сообщениями в футере страницы.
			 * @param {sap.ui.base.Event} oControlEvent Нажатие на кнопку.
			 */
			onMessagesButtonPress: function(oControlEvent) {
				const oMessagesButton = oControlEvent.getSource();
				if (!this._messagePopover) {

					this._messagePopover = new MessagePopover("idMessagePopover", {
						items: {
							path: "message>/",
							template: new MessageItem({
								description: "{message>description}",
								type: "{message>type}",
								title: "{message>message}",
								longtextUrl: "{message>descriptionUrl}",
							}),
						},
					});
					oMessagesButton.addDependent(this._messagePopover);
				}
				this._messagePopover.toggle(oMessagesButton);
			},

			onSelectMessagePopoverItem: function(oControlEvent) {
				var oItem = oControlEvent.getParameter("item"),
					oLink = oItem.getLink(),
					sLongLextUrl = oItem.getProperty("longtextUrl");
				if (!!sLongLextUrl) {
					oLink.setHref(sLongLextUrl);
				} else {
					oLink.setVisible(false);
				}

			},

			/***
			 * Формирует ключ в модели с основным данным текущего объекта.
			 * @param {string} [Preffix] Префикс для пути, по которому будет сформирован ключ.
			 * @returns {string}
			 */
			createCurrentKey: function(sPreffix) {
				const sResultPreffix = (!!sPreffix && typeof sPreffix === "string") ? sPreffix : "";
				var sMainServiceName = this.getStateProperty("/app/mainServiceName");

				var oStruct = {
					CodeCp: this.getStateProperty("/_GET").CodeCp,
					StatusCp: this.getStateProperty("/_GET").StatusCp
				};

				if (this.getStateProperty("/app/mainServiceName") === "FilterCPSet") {
					oStruct = {
						Uuid: this.getStateProperty("/_GET").CodeCp //Поле "Uuid"
					}
				}

				if (this.getStateProperty("/_GET").AppMode === "relation" && !!this.getStateProperty("/_GET").LinkVariant) {
					oStruct = {
						CodeCp: this.getStateProperty("/_GET").CodeCp,
						LinkVariant: this.getStateProperty("/_GET").LinkVariant,
						StatusCp: this.getStateProperty("/_GET").StatusCp
					};
					sMainServiceName = this.getStateProperty("/app/linkServiceName");
				}

				const sKey = (!$.isEmptyObject(this.getStateProperty("/_GET"))) ?
					this.getModel().createKey(sResultPreffix + sMainServiceName, oStruct) : "";
				return sKey;
			},


			/**
			 * Обновляет таблицу.
			 * @param {sap.m.table | sap.ui.comp.smarttable.SmartTable} [oTable] Таблица, которую нужно обновить.
			 * @param {function} [fnCallback] Функция обратного вызова, после обновления таблицы.
			 */
			refreshTable: function(oTable, fnCallback, bHardRebindTable) {
				var oTableToRefresh,
					sTableAggregation = "items",
					bIsSmartTable = false,
					bIsSmartBindingActual = true;

				if (!!oTable) {
					bIsSmartTable = (oTable.getMetadata().getName() === "sap.ui.comp.smarttable.SmartTable");
					oTableToRefresh = (bIsSmartTable) ? oTable.getTable() : oTable;
					sTableAggregation = (oTableToRefresh.getMetadata().getName() === "sap.m.Table") ? "items" : "rows";
					if (bIsSmartTable) {
						bIsSmartBindingActual = (!oTableToRefresh.getBinding(sTableAggregation) ||
							oTable.getTableBindingPath() === oTableToRefresh.getBinding(sTableAggregation).getPath()
						);
					}
				} else {
					const sTableId = this.getStateProperty("/uploadCollection/tableId") ? this.getStateProperty("/uploadCollection/tableId") : this.getStateProperty("/fileUploader/tableId");
					oTableToRefresh = this.getById(sTableId);
				}

				if (!!oTableToRefresh.getBinding(sTableAggregation) && bIsSmartBindingActual && !bHardRebindTable) {
					oTableToRefresh.getBinding(sTableAggregation).refresh(true);
					if (fnCallback) {
						fnCallback(oTableToRefresh);
					}
				} else {
					if (bIsSmartTable) {
						oTable.rebindTable();
					}
				}
			},

			/**
			 * Устанавливает через запись в статическию можель для всех вкладок состояние, требуюшее обновления.
			 */
			resetAllTabsLoaded: function() {
				this.setStateProperty("/app/refreshObject", true);
				this.setStateProperty("/prevTabId", "");
			},

			/**
			 * Возвращает View текущей вкладки.
			 * @returns {*|Object|false}
			 */
			getPageView: function() {
				const vMaymePageView = this.getById(this.getStateProperty("/app/currentView"));
				return (!!vMaymePageView) ? vMaymePageView : this.getView();
			},

			/**
			 * Возвращает контроллер текущей вкладки.
			 * @returns {object}
			 */
			getPageController: function() {
				return this.getPageView().getController();
			},

			/**
			 * Вызывается, когда не удалось получить данные с бэкэнда.
			 * @param {object} oResponse.getParameter("response") Объект, который содержит в себе ответ обращения в модели.
			 */
			onRequestFailed: function(oResponse) {
				var oParamaters = oResponse.getParameter("response");
				oParamaters.url = window.location.href;
				this.setStateProperty("/app/navError", oParamaters);
			},

			/**
			 *
			 * @param bHideOnBindElementNoQuery
			 */
			makeElementBinding: function(bHideOnBindElementNoQuery) {
				const oPageController = this.getPageController();
				var sHeaderMode = this.getStateProperty("/_GET/AppMode");
				var oParam = {
					expand: "toActionControls"
				};
				
				if (sHeaderMode === "search" || sHeaderMode === "Chemical") {
					oParam = {
						expand: "toChemicalArea,toActionControls"
					};
				} else if (sHeaderMode === "relation") {
					oParam = {};
				}

				this.setStateProperty("/app/lastBindingTabView", this.getView().getId());
				
				this.getView().bindElement({
					path: this.createCurrentKey("/"),
					parameters: oParam,
					events: {
						dataRequested: function(oData) {
							oPageController.setStateProperty("/app/refreshObject", false);
							this.getModel().attachEventOnce("requestFailed", this.onRequestFailed.bind(this));
						}.bind(this),
						change: function(oData) {
							this.setStateProperty("/prevTabId", oPageController.getSelectedTabView(true).getId());
							if (this.getStateProperty("/app/refreshObject")) {
								this.getView().getElementBinding().refresh();
							} else {
								this.getModel().detachEvent("requestFailed", this.onRequestFailed);
								if (bHideOnBindElementNoQuery) {
									this.hideBusy();
									this.doResolve();
								} else {
									this.attachResolveOnBatchComplete();
								}
							}
						}.bind(this),
						dataReceived: function(oResponse) {
							this.setStateProperty("/app/GeneralMode", this.getStateProperty("/_GET").AppMode);

							var oResponse = oResponse.getParameter("data");
							this.getModel().detachEvent("requestFailed", this.onRequestFailed);

							this.hideBusy();
							if (this.getPageController()._ObjectPage) {
								this.getPageController()._ObjectPage.setSelectedSection(this.getPageController().createId(this.getStateProperty("/_GET").Tab + "ObjectPageSection"));
							}

							if (oResponse) {

								this._createFcModel(oResponse);

								if (!!oResponse.FilterUuid && oResponse.FilterUuid !== "") {
									this.setStateProperty("/applyFilter/FilterUuid", oResponse.FilterUuid);
								}

								if (!!oResponse.Assimilate) {
									this.setStateProperty("/check/urgency", oResponse.Assimilate);
								} else if (!!oResponse.AssimilateFlt) {
									this.setStateProperty("/check/urgency", oResponse.AssimilateFlt);
								}

								if (oResponse.CodeCp === "0000000000") {
									this.getRouter().navTo("notFound", {}, true);
								} else if (this.getStateProperty("/app/showErrorPopover")) {
									oPageController.setStateProperty("/app/showErrorPopover", false);
									this.getPageController().getById("ObjectMessagesIndicator").firePress();
								}
							} else {
								this.getRouter().navTo("notFound", {}, true);
							}
							this.doResolve();
						}.bind(this)
					}
				});

				this._bindHeader();
				if (this.getStateProperty("/_GET").AppMode === "relation") {
					this._bindLeftPanelRelation();
				}
			},

			_bindHeader: function() {
				this.getPageView().getControlsByFieldGroupId("ObjectPageLayout")[0].bindElement({
					path: this.createCurrentKey("/")
				});
			},

			_createFcModel: function (oResponse) {
				var oFcModel = {};

				if (!!oResponse) {
					$.extend(oFcModel, oResponse);
				}

				this.setStateProperty("/app/fcModel", oFcModel);
			},


			_bindLeftPanelRelation: function() {
				this.getPageView().byId("idRelationVBox").bindElement({
					path: this.createCurrentKey("/")
				});
			},

			
			/**
			 * Запрос в OData модель на создание записи.
			 * @param {string} sCreatePath Путь для POST запроса.
			 * @param {object} mSettings Объект с деталями запроса.
			 * @param {object} mSettings.properties  Объект со свойствами по умолчанию для создание объекта.
			 * @param {function} mSettings.success Функция обратного вызова при успешном выполнении запроса.
			 * @param {function} mSettings.error Функция обратного вызова при ошибке.
			 * @private
			 */
			_createNewItem: function(sCreatePath, mSettings) {
				if (!mSettings.preventRefreshAfterUpdate) {
					this.getModel().setRefreshAfterChange(true);
				}
				this.getModel().create(sCreatePath, mSettings.properties, {
					success: function(oData, response) {
						if (mSettings.success) {
							mSettings.success.call(this, oData, response);
						}
					}.bind(this),
					error: function(oError) {
						if (mSettings.error) {
							mSettings.error.call(this, oError);
						}
					}.bind(this),
				})
			},

			/**
			 * Добавление массива объектов через запрос на создание в OData модель.
			 * @param {object[]} aItems Массив объектов для создания.
			 * @param {boolean} bRefresh Если <code>true/code> произойдет обновление модели после изменения.
			 * @returns {Promise} <code>Promise</code> объект представляет выполнение всех запросов.
			 */
			createItems: function(aItems, bRefresh) {
				var oModel = this.getModel();
				return Promise.all(aItems.map(function(sPath) {
					return createItem(sPath);
				}));

				function createItem(oItem, bRefresh) {
					return new Promise(function(resolve, reject) {
						oModel.create(oItem.path, oItem.properties, {
							success: function(oData, response) {
								resolve({
									data: oData,
									response: response
								});
							},
							error: function(oError) {
								reject(oError);
							},
							refreshAfterChange: bRefresh
						});
					})
				}
			},

			
			/**
			 * Запрос в OData модель на создание новой записи.
			 * @param {sap.ui.base.Event} oControlEvent Событие нажатия на иконку добавления записи таблицу.
			 * @param {function} [fnSuccess] Функция обратного вызова при успешном выполнении запроса.
			 */
			addEmptyRecord: function(oControlEvent, fnSuccess) {
				this.showBusy();
				const oSource = oControlEvent.getSource();
				const sNavProp = oSource.getId().split("add_")[1];
				const sObjectContextPath = this.getView().getBindingContext().getPath();
				const sCreatePath = sObjectContextPath + "/" + sNavProp;
				const oSmartTable = this.getSpecificParent(oSource, "sap.ui.comp.smarttable.SmartTable");
				const oModel = this.getModel();
				oModel.createEntry(sCreatePath);
				this.getPageController().save();
				this.do(function() {
					if (jQuery.isFunction(fnSuccess))
						fnSuccess();
					if (!!oSmartTable.getTable().getBinding("items")) {
						oSmartTable.getTable().getBinding("items").refresh(true);
						this.attachResolveOnBatchComplete();
					} else {
						this.doResolve();
					}
					if (!!oSmartTable.getTable().getBinding("rows")) {
						oSmartTable.getTable().getBinding("rows").refresh(true);
						this.hideBusy();
					}
				}.bind(this));
			},

			/**
			 * Возвращает родительский объект соответствующий заданному классу.
			 * @param {Object} oSource Объект, относительно которого ищется конкретный родитель.
			 * @param {string} sClassName Имя класса искомого родителя.
			 * @returns {Object}
			 */
			getSpecificParent: function(oSource, sClassName) {
				var oCurrentParent = oSource;
				while (oCurrentParent && oCurrentParent.getMetadata().getName() !== sClassName) {
					oCurrentParent = oCurrentParent.getParent();
				}
				return oCurrentParent;
			},

			
			parseRequestError: function(oError) {
				var sResultResponse = "";
				try {
					if (!!oError) {
						if (!!oError.responseText) {
							if (!!JSON.parse(oError.responseText)) {
								var oResponse = JSON.parse(oError.responseText);
								if (!!oResponse.error && !!oResponse.error.message && !!oResponse.error.message.value) {
									sResultResponse = oResponse.error.message.value;
								}
							}
						}
						if (sResultResponse === "") {
							if (!!oError.statusCode && !!oError.statusText) {
								sResultResponse = oError.statusCode + " " + oError.statusText;
							} else if (!!oError.message) {
								sResultResponse = oError.message;
							}
						}
					}
					if (sResultResponse === "") {
						sResultResponse = this.getResourceBundle().getText("textUnhandledError");
					}
				} catch (err) {
					sResultResponse = this.getResourceBundle().getText("textUnhandledError");
				}
				return sResultResponse;
			},
			spacerChange: function(){
				var aSection= this.getView().getControlsByFieldGroupId("ObjectPageSection");
				aSection.forEach(function (element) {
					element.addEventDelegate({
						onAfterRendering: function() {
							$("#application-zo2c_com_prod-open-component---idObject--ObjectPageLayout-spacer").attr('style', 'height:0px');
						}.bind(this)
					});
				}.bind(this));
			}

		});

	return BaseController;
});
