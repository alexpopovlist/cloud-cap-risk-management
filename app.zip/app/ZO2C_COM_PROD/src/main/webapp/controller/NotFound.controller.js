sap.ui.define([
	"ZO2C_COM_PROD/ZO2C_COM_PROD/controller/BaseController",
	"sap/ui/core/routing/History",
	"sap/m/MessageBox"

], function(BaseController, History, MessageBox) {
	"use strict";

	/**
	 * @class
	 *
	 * @constructor
	 * @public
	 * @alias zgagarin.zsupplyproc.controller.NotFound
	 */
	var oNotFound = BaseController.extend("ZO2C_COM_PROD.ZO2C_COM_PROD.controller.NotFound",
		/** @lends zgagarin.zsupplyproc.controller.NotFound.prototype */
		{

			/**
			 *onInit hook. При инициализации присваивает событие attachPatternMatched. Само событие - _routePatternMatched
			 */
			onInit: function() {
				this.getRouter().attachBypassed(this._routePatternMatched);
				this.getRouter().attachRoutePatternMatched(this._routePatternMatched);
			},

			_routePatternMatched: function(oControlEvent) {
				sap.ui.core.BusyIndicator.hide();
			},

			/**
			 * Форматтер ошибок. На вход функция принимает new Error() - JSON объект
			 * @param {Error} oError  JSON объект ошибки.
			 * @returns {string} возвращает текст ошибки 404 notFoundMessage
			 */

			errorMessageFormatter: function(oError) {
				var sResultError = this.getText("defaultErrorText");
				if (oError && !$.isEmptyObject(oError)) {
					switch (oError.statusCode) {
						case "404":
							sResultError = this.getText("notFoundMessage", [this.getStateProperty('/options/wordsForms/item')]);
							break;
						default:
							sResultError = this.getText("requestedUrl") + ":\n" + oError.url + "\n\n" + this.getErrorHandler().getFullErrorMessage(oError);
					}
				}

				return sResultError;
			},

			/**
			 * Форматтер ошибок. На вход функция принимает new Error() - JSON объект
			 * @param {Error} oError  JSON объект ошибки.
			 * @returns {string} возвращает текст ошибки
			 */

			errorTitleMessageFormatter: function(oError) {
				var sResultError = this.getText("defaultErrorTitle");
				if (oError && !$.isEmptyObject(oError)) {
					switch (oError.statusCode) {
						case "404":
							sResultError = this.getText("notFoundTitle");
							break;
						default:
							sResultError = oError.message + ": " + oError.statusText;
					}
				}

				return sResultError;
			},

			/**
			 * При нажатии на Link происходит переход назад (на экран WorkList)
			 */

			onLinkPressed: function() {
				MessageBox.information(this.getResourceBundle().getText("textCreateNewFilterOrCP"), {
					actions: [this.getResourceBundle().getText("btnCreateNewFilter"), this.getResourceBundle().getText("btnCreateNewCP"), sap.m.MessageBox.Action.CANCEL],
					onClose: function(sAction) {
						if (sAction !== "CANCEL") {
							if (sAction === this.getResourceBundle().getText("btnCreateNewFilter")) {
								this._executeCreateFilter({}, true);
							} else if (sAction === this.getResourceBundle().getText("btnCreateNewCP")) {
								this._executeCreateNewCP({}, false);
							}
						}
					}.bind(this)
				});
			}

		});
	return oNotFound;
});
