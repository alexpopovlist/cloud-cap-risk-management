sap.ui.define([
	"ZO2C_COM_PROD/ZO2C_COM_PROD/controller/BaseController",
	"ZO2C_COM_PROD/ZO2C_COM_PROD/custom/model/stateModel"

], function (BaseController, stateModel) {
	"use strict";

	return BaseController.extend("ZO2C_COM_PROD.ZO2C_COM_PROD.controller.App", {

		/**
		 * Handles application errors by automatically attaching to the model events and displaying errors when needed.
		 * @class
		 * @public
		 * @namespace ZO2C_COM_PROD.ZO2C_COM_PROD.controller.App
		 */

		onInit: function () {
			BaseController.prototype.onInit.apply(this, arguments);
			this.setModel(stateModel.createJSONModel(this), "state");
			const aSemanticBasic = this.getOwnerComponent().getId().split("application-");
			const oSemantic = (aSemanticBasic.length === 2) ? aSemanticBasic[1].split("-component")[0].split("-") : [false, false];
			this.setStateProperty("/app/action", oSemantic[1]);
		}
	});
});
