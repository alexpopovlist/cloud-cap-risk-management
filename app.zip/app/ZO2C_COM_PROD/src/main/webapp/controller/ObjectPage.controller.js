sap.ui.define([
	"ZO2C_COM_PROD/ZO2C_COM_PROD/controller/BaseController",
	"sap/m/Text",
	"sap/m/Token",
	"sap/m/Tokenizer",
	"sap/m/MessageBox",
	"ZO2C_COM_PROD/ZO2C_COM_PROD/custom/class/Common",
	"sap/ui/core/Fragment",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter"

], function(BaseController, Text, Token, Tokenizer, MessageBox, Common, Fragment, Filter, FilterOperator, Sorter) {
	"use strict";

	/**
	 * @class
	 *
	 * @constructor
	 * @public
	 * @alias ZO2C_COM_PROD.ZO2C_COM_PROD.controller.Object
	 */
	const thisController = BaseController.extend("ZO2C_COM_PROD.ZO2C_COM_PROD.controller.ObjectPage",
		/** @lends ZO2C_COM_PROD.ZO2C_COM_PROD.controller.Object.prototype */
		{

			_ObjectPage: null,
			// _ObjectDraftIndicator: null,
			_customObjectDraftIndicator: null,
			_messagePopover: null,
			_oSaveTemplateDialog: null,
			_oListOfTemplatesDialog: null,
			_oCreateCPByTemplateDialog: null,
			_oListOfFoundCPPopover: null,
			_oSectionSelectEvent: null,
			_relationVBoxContent: null,
			_bRelationVBoxContent: false,

			Common: Common,

			/**
			 *onInit hook. При инициализации присваивает событие attachPatternMatched. Само событие - _onObjectPatternMatched
			 */
			onInit: function() {
				BaseController.prototype.onInit.apply(this, arguments);
				const oInitialState = $.extend(true, {}, this.getStateProperty("/object/initial"));
				this.setStateProperty("/object/current", oInitialState);

				this._ObjectPage = this.getById("ObjectPageLayout");
				this._customObjectDraftIndicator = this.getById("customObjectDraftIndicator");
				this.setStateProperty("/app/customObjectDraftIndicator", this._customObjectDraftIndicator);
				this.getRouter().getRoute("objectPage").attachPatternMatched(this._onObjectPatternMatched, this);
				this.getRouter().getRoute("objectPageSearch").attachPatternMatched(this._onObjectPatternMatched, this);
				this.getRouter().getRoute("createObject").attachPatternMatched(this._onObjectPatternMatched, this);
				this.getRouter().getRoute("createObjectShort").attachPatternMatched(this._onObjectPatternMatched, this);
				this.getRouter().getRoute("createObjectPage").attachPatternMatched(this._onObjectPatternMatched, this);
				this.getRouter().getRoute("link").attachPatternMatched(this._onObjectPatternMatched, this);

				this.spacerChange();
			},
			onAttachButtonPressHandler: function (oControlEvent) {
				var sNavigationProperty = oControlEvent.getSource().data("fileUrl");
				var sBindingContextPath = oControlEvent.getSource().getBindingContext().getPath();
			 	var sDownloadPath = this.getOwnerComponent().getModel().sServiceUrl + sBindingContextPath + "/" + sNavigationProperty + "/$value";
			 	
			 	window.open(sDownloadPath);
			},

			// TODO document it
			_onObjectPatternMatched: function(oControlEvent) {
				this.getOwnerComponent()._oMessageManager.removeAllMessages();
				this._enableAutoSave();
				this.setStateProperty("/count/Classif", "0");
				this.setStateProperty("/_GET", {});
				$.each(oControlEvent.getParameter("arguments"), function(sIndex, vParam) {
					const sNewIndex = (sIndex.indexOf("?") === 0) ? sIndex.slice(1) : sIndex;
					const vNewValue = (!vParam) ? {} : vParam;
					this.getStateProperty("/_GET")[sNewIndex] = vNewValue;
				}.bind(this));
				this.setStateProperty("/app/currentView", this.getView().getId());

				if (!this.getStateProperty("/_GET").Tab && this.getStateProperty("/app").tabs.indexOf(this.getStateProperty("/_GET").Tab) > -1) {
					if (this.getStateProperty("/_GET").AppMode === "search") {
						this.setStateProperty("/_GET/Tab", "General");
						if (!!this.getStateProperty("/_GET").AppMode && !!this.getStateProperty("/_GET").CodeCp) {
							this.getRouter().navTo("objectPageSearch", {
								AppMode: this.getStateProperty("/_GET").AppMode,
								CodeCp: this.getStateProperty("/_GET").CodeCp,
								Tab: this.getStateProperty("/_GET").Tab
							}, false);
						}
					} else {
						if (this.getStateProperty("/_GET").AppMode === "view") {
							this.setStateProperty("/_GET/Tab", "Chemical");
						} else {
							this.setStateProperty("/_GET/Tab", "General");
						}
						if (!!this.getStateProperty("/_GET").AppMode && !!this.getStateProperty("/_GET").CodeCp && !!this.getStateProperty("/_GET").StatusCp) {
							this.getRouter().navTo("objectPage", {
								AppMode: this.getStateProperty("/_GET").AppMode,
								CodeCp: this.getStateProperty("/_GET").CodeCp,
								StatusCp: this.getStateProperty("/_GET").StatusCp,
								Tab: this.getStateProperty("/_GET").Tab
							}, false);
						}
					}
				}

				if (!this.getStateProperty("/_GET").CodeCp || (!this.getStateProperty("/_GET").StatusCp && this.getStateProperty("/_GET").AppMode !== "search")) {
					this.setStateProperty("/searchResults/display", false);
					this._executeCreateFilter({}, true);
				} else {
					this._setModeParameters();
					this.save();
					
					this.getControlsByFieldGroupId("ObjectPageLayout")[0].unbindContext();

					var oLastTab = this.getById(this.getStateProperty("/app/currentTabId"));
					var oChemSet = this.getControlsByFieldGroupId("idFilterChemicalSetSetSearch");

					if (!!oLastTab) {
						oLastTab.unbindContext();
					}

					if (!!oChemSet && !!oChemSet[0]) {
						oChemSet[0].destroy();
					}

					if (this._ObjectPage) {
						this._ObjectPage.setSelectedSection(this.createId(this.getStateProperty("/_GET").Tab + "ObjectPageSection"));
					}
					this.loadObject(true);
				}
			},

			_setModeParameters: function () {
				this.setStateProperty("/app/refreshObject", true);
				this.setStateProperty("/app/GeneralInfo/OPFoundCPPanel", false);
				this.setStateProperty("/app/mainServiceName", "MainCPSet");

				if (this.getStateProperty("/_GET").AppMode === "search") {

						this.setStateProperty("/app/appState", "search");

						this.resizeRelationFragment(false);

						if (this.getStateProperty("/searchResults").display && this.getStateProperty("/searchResults").lastAppliedFilterUuid === this.getStateProperty("/_GET").CodeCp) {
							this.setStateProperty("/app/GeneralInfo/OPFoundCPPanel", true);
						}

						this.setStateProperty("/app/mainServiceName", "FilterCPSet");
						this.setStateProperty("/applyFilter/FilterUuid", this.getStateProperty("/_GET").CodeCp);
						this.setStateProperty("/app/GeneralInfo/ShowObjectPageLayoutHeaderContent", false);
						this.setStateProperty("/app/GeneralInfo/expandedObjectPageTitle", this.getResourceBundle().getText("titleSearchCP"));
						this.setStateProperty("/app/GeneralInfo/snappedObjectPageTitle", this.getResourceBundle().getText("titleSearchCP"));

					} else if (this.getStateProperty("/_GET").AppMode === "view") {

						this.setStateProperty("/app/appState", "view");

						this.resizeRelationFragment(false);
						this.setStateProperty("/app/GeneralInfo/ShowObjectPageLayoutHeaderContent", true);
						this.setStateProperty("/app/GeneralInfo/expandedObjectPageTitle", this.getResourceBundle().getText("titleViewCP"));
						this.setStateProperty("/app/GeneralInfo/snappedObjectPageTitle", this.getResourceBundle().getText("titleViewCP"));

					} else if (this.getStateProperty("/_GET").AppMode === "edit") {
						
						this.setStateProperty("/app/appState", "edit");

						this.resizeRelationFragment(false);
						this.setStateProperty("/app/GeneralInfo/ShowObjectPageLayoutHeaderContent", true);
						this.setStateProperty("/app/GeneralInfo/expandedObjectPageTitle", this.getResourceBundle().getText("titleEditCP"));
						this.setStateProperty("/app/GeneralInfo/snappedObjectPageTitle", this.getResourceBundle().getText("titleEditCP"));

					} else if (this.getStateProperty("/_GET").AppMode === "create") {

						this.setStateProperty("/app/appState", "create");

						this.resizeRelationFragment(false);
						this.setStateProperty("/app/GeneralInfo/ShowObjectPageLayoutHeaderContent", false);
						this.setStateProperty("/app/GeneralInfo/expandedObjectPageTitle", this.getResourceBundle().getText("titleCreateCP"));
						this.setStateProperty("/app/GeneralInfo/snappedObjectPageTitle", this.getResourceBundle().getText("titleCreateCP"));

					} else if (this.getStateProperty("/_GET").AppMode === "relation") {

						this.addRelationFragment();
						this.resizeRelationFragment(true);
						this.setStateProperty("/app/GeneralInfo/ShowObjectPageLayoutHeaderContent", false);
						this.setStateProperty("/app/GeneralInfo/expandedObjectPageTitle", this.getResourceBundle().getText("titleRelationCP"));
						this.setStateProperty("/app/GeneralInfo/snappedObjectPageTitle", this.getResourceBundle().getText("titleRelationCP"));
					}
			},

			/**
			 *Метод загрузки данных объекта
			 *@param {boolean} bSuspendReload параметр перезагрузки данных для текущей вкладки.
			 */
			loadObject: function(bSuspendReload) {
				this.do(
					function(bSuspendReload) {
						this.showBusy();
						if (this.getSelectedTabView()) {
							this.getSelectedTabView().getController().processLoad(true);
						} else {
							this.doResolve();
						}
					}.bind(this), [bSuspendReload]
				);
			},

			onRelationItemsIconPressHandler: function (oControlEvent) {
				var sAppState = this.getStateProperty("/app/appState");
				if( sAppState !== "edit" && sAppState !== "create" ) {
					return;
				}
				var sObjectPath = oControlEvent.getSource().getBindingContext().getPath();
				var oLink = oControlEvent.getSource().getBindingContext().getObject();
				var sDepends = oControlEvent.getSource().getBindingContext().getObject().Depends;
				var sNewVal = sDepends === "R"? "K" : "R";
				var oEntry = {
					"CodeCp": oLink.CodeCp,
					"CpView": oLink.CpView,
					"Depends": sNewVal,
					"RVariant": oLink.RVariant,
					"LinkVariant": oLink.LinkVariant,
					"StatusCp": oLink.StatusCp
				};

				this.getModel().update(sObjectPath,oEntry, {success: function (oData) {
						var oList = sap.ui.getCore().byId(this.getStateProperty("/app/currentView")).getControlsByFieldGroupId("idRelationList")[0];
						oList.getBinding("items").refresh(true);
					}.bind(this)
				});
			},

			resizeRelationFragment: function(bRelation) {
				var oView = sap.ui.getCore().byId(this.getStateProperty("/app/currentView"));

				if (bRelation) {
					if (oView.byId("idDetailVBox").getWidth() !== "80%") {
						oView.byId("idRelationVBox").setWidth('20%');
						oView.byId("idDetailVBox").setWidth('80%');
					}

					this._bRelationVBoxContent = true;
				} else {
					if (oView.byId("idDetailVBox").getWidth() !== "100%") {
						oView.byId("idRelationVBox").setWidth('0%');
						oView.byId("idDetailVBox").setWidth('100%');
					}

					this._bRelationVBoxContent = false;
				}
			},

			onGoToAppl: function(sApplId) {
				return window.location.href.split('#')[0]  + "#zo2c_appl-po&/applHead/" + sApplId;
			},

			addRelationFragment: function() {
				var oVBox = this.getById("idRelationVBox");

				this.destroyVBoxContent("idRelationVBox");

				if (!this._relationVBoxContent) {
					this._relationVBoxContent = new sap.ui.xmlfragment(
						this.createId("relation"),
						"ZO2C_COM_PROD.ZO2C_COM_PROD.view.tabs.Relation.Items",
						this
					);
					this.getView().addDependent(this._relationVBoxContent);
				}

				oVBox.addItem(this._relationVBoxContent);
			},

			destroyVBoxContent: function(sVBoxId) {
				var oVBox = this.getById(sVBoxId);
				var aItems = oVBox.getItems();

				aItems.forEach(function(oItem) {
					oItem.destroy();
				});

				oVBox.removeAllItems();
				this._relationVBoxContent = null;
			},

			onSectionSelectHandler: function(oControlEvent) {
				this._oSectionSelectEvent = $.extend(true, {}, oControlEvent);
				this.saveChanges(false, function() {
					var sId = this._oSectionSelectEvent.getParameter("section").getId(),
						iBegin = sId.lastIndexOf("--") + 2,
						iEnd = sId.indexOf("ObjectPageSection"),
						sTab = sId.slice(iBegin, iEnd);

					if (this.getStateProperty("/_GET").AppMode === "relation") {
						this.replaceHash("link", {
							"AppMode": this.getStateProperty("/_GET").AppMode,
							"CodeCp": this.getStateProperty("/_GET").CodeCp,
							"StatusCp": this.getStateProperty("/_GET").StatusCp,
							"Tab": sTab,
							"bChangeLog": false,
							"LinkVariant": this.getStateProperty("/_GET").LinkVariant
						});
					} else if (!!this.getStateProperty("/_GET").StatusCp) {
						this.replaceHash("objectPage", {
							"AppMode": this.getStateProperty("/_GET").AppMode,
							"CodeCp": this.getStateProperty("/_GET").CodeCp,
							"StatusCp": this.getStateProperty("/_GET").StatusCp,
							"Tab": sTab
						});
					} else {
						this.replaceHash("objectPageSearch", {
							"AppMode": this.getStateProperty("/_GET").AppMode,
							"CodeCp": this.getStateProperty("/_GET").CodeCp,
							"Tab": sTab
						});
					}
				}.bind(this));
			},

			/**
			 *Метод возвращающий выбранную вкладку приложения
			 *@returns {sap.uxap.BlockBase} Объект выбранной вкладки
			 */
			getSelectedTabView: function(bFrorceSelectedView) {
				const sSelectedSectionId = BaseController.prototype.byId.call(this, "ObjectPageLayout").getSelectedSection();
				const oSelectedSection = BaseController.prototype.byId.call(this, sSelectedSectionId);
				if (oSelectedSection instanceof sap.uxap.ObjectPageSubSection) {
					return BaseController.prototype.byId.call(this, oSelectedSection.getBlocks()[0].getSelectedView());
				} else {
					var sSelectedViewId = null;
					if (bFrorceSelectedView) {
						sSelectedViewId = oSelectedSection.getSubSections()[0].getBlocks()[0].getId() + "-Collapsed";
					} else {
						sSelectedViewId = oSelectedSection.getSubSections()[0].getBlocks()[0].getSelectedView();
					}

					var oSubSectionView = BaseController.prototype.byId.call(this, sSelectedViewId);
					return oSubSectionView;
				}
			},

			/**
			 *Метод возвращающий контроллер выбранной вкладки приложения
			 *@returns {sap.ui.core.mvc.Controller} Контроллер выбранной вкладки
			 */
			getSelectedTabController: function() {
				return this.getSelectedTabView().getController();
			},

			/**
			 *Метод возвращающий объект зарегистрированного элемента. Элемент может располагаться как на заголовке, так и на вкладке.
			 *@param {string} sId Id элемента.
			 *@returns {sap.ui.core.Element} Объект элемента
			 */
			getById: function(sId) {
				var vMaymeControl = BaseController.prototype.byId.call(this, sId);
				if (!vMaymeControl) {
					vMaymeControl = (this.getSelectedTabView()) ? BaseController.prototype.byId.call(this, this.getSelectedTabView().createId(sId)) : false;
				}
				return vMaymeControl;
			},

			onCreateNewCPPressHandler: function(oControlEvent) {
				this.showBusy();
				this.getModel().callFunction("/CheckNewExists", {
					method: "POST",
					success: function(oData, oMessage) {
						this.hideBusy();
						if (!!oData && !!oData.CheckNewExists) {
							if (oData.CheckNewExists.FuncResult) {
								if (this._oListOfExistingCPDialog) {
									this._oListOfExistingCPDialog.destroy();
								}
								this._oListOfExistingCPDialog = new sap.ui.xmlfragment("ZO2C_COM_PROD.ZO2C_COM_PROD.view.dialogs.ListOfExistingCP", this);
								this.getView().addDependent(this._oListOfExistingCPDialog);
								this._oListOfExistingCPDialog.open();
							} else {
								this._executeCreateNewCP({}, false);
							}
						}
					}.bind(this),
					error: function(oError) {
						this.hideBusy();
						MessageBox.error(this.parseRequestError(oError));
					}.bind(this)
				});
			},

			applyCreateNewCPByNewButton: function(oEvent) {
				this._executeCreateNewCP({}, false);
				this._oListOfExistingCPDialog.close();
			},

			cancelListOfExistingCPButton: function(oEvent) {
				this._oListOfExistingCPDialog.close();
			},

			onListOfExistingCPSelect: function(oEvent) {
				this._oListOfExistingCPDialog.close();

				var oList = this.getControlsByFieldGroupId("ListOfExistingCP")[0];
				var oSelectedItem = oList.getSelectedItem();
				var oSelectedItemData = oSelectedItem.getBindingContext().getObject();

				if (!!oSelectedItemData && !!oSelectedItemData.CodeCp && !!oSelectedItemData.StatusCp) {

					if(this.getStateProperty("/_GET").AppMode === "edit"){
						this.cleanMessageLog();
					}

					// TODO - FIX all bugs from MessageLog (not to clean as now)
					this.getOwnerComponent()._oMessageManager.removeAllMessages();

					this.getRouter().navTo("objectPage", {
						AppMode: "create",
						CodeCp: oSelectedItemData.CodeCp,
						StatusCp: oSelectedItemData.StatusCp,
						Tab: "General"
					}, false);
				}
			},

			handleListOfExistingCPSearch: function(oEvent) {
				// add filter for search
				var aFilters = [];
				var sQuery = oEvent.getSource().getValue();
				if (sQuery && sQuery.length > 0) {
					var filterCodeCp = new sap.ui.model.Filter("CodeCp", sap.ui.model.FilterOperator.Contains, sQuery);
					aFilters.push(filterCodeCp);
				}
				var filterStatusCp = new sap.ui.model.Filter("StatusCp", sap.ui.model.FilterOperator.EQ, "N");
				aFilters.push(filterStatusCp);

				// update list binding
				var oList = this.getControlsByFieldGroupId("ListOfExistingCP")[0];
				var oBinding = oList.getBinding("items");
				oBinding.filter(aFilters, "Application");
			},

			onSaveTemplatePressHandler: function(oControlEvent) {
				if (this._oSaveTemplateDialog) {
					this._oSaveTemplateDialog.destroy();
				}
				this._oSaveTemplateDialog = new sap.ui.xmlfragment("ZO2C_COM_PROD.ZO2C_COM_PROD.view.dialogs.SaveTemplate", this);
				this.getView().addDependent(this._oSaveTemplateDialog);
				this._oSaveTemplateDialog.open();
			},

			applySaveTemplateButton: function(oEvent) {
				var oInput = this.getControlsByFieldGroupId("inputTemplateName")[0];
				var sTemplateName = oInput.getValue();
				var sFilterUuid = this.getStateProperty("/_GET").CodeCp //Поле Uuid
				var oStruct = {
					TemplateName: sTemplateName,
					FilterUuid: sFilterUuid
				};
				this._executeSaveTemplate(oStruct, false);
				this._oSaveTemplateDialog.close();
			},

			cancelSaveTemplateButton: function() {
				this._oSaveTemplateDialog.close();
			},

			onListOfTemplatesPressHandler: function(oControlEvent) {
				if (this._oListOfTemplatesDialog) {
					this._oListOfTemplatesDialog.destroy();
				}
				this._oListOfTemplatesDialog = new sap.ui.xmlfragment("ZO2C_COM_PROD.ZO2C_COM_PROD.view.dialogs.ListOfTemplates", this);
				this.getView().addDependent(this._oListOfTemplatesDialog);
				this._oListOfTemplatesDialog.openBy(oControlEvent.getSource());
			},

			acceptListOfTemplatesButton: function() {
				this._oListOfTemplatesDialog.close();

				var oTable = this.getControlsByFieldGroupId("TemplatesTable")[0];
				var oSelectedRow = oTable.getSelectedItem();
				var oSelectedRowData = oSelectedRow.getBindingContext().getObject();
				var oUrlParam = {
					TemplateUuid: oSelectedRowData.Uuid
				};
				this._executeCreateFilterByTemplate(oUrlParam, false);
			},

			cancelListOfTemplatesButton: function() {
				this._oListOfTemplatesDialog.close();
			},

			handleListOfTemplatesSearch: function(oEvent) {
				// add filter for search
				var aFilters = [];
				var sQuery = oEvent.getSource().getValue();
				if (sQuery && sQuery.length > 0) {
					var filter = new Filter("TemplateName", "Contains", sQuery);
					aFilters.push(filter);
				}

				// update table binding
				var oTable = this.getControlsByFieldGroupId("TemplatesTable")[0];
				var oBinding = oTable.getBinding("items");
				oBinding.filter(aFilters, "Application");
			},

			onResetFilterPressHandler: function() {
				this.saveChanges(false, function() {
					MessageBox.warning(this.getResourceBundle().getText("textResetFilterCofirmation"), {
						actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
						onClose: function(sAction) {
							if (sAction === "OK") {
								this.setStateProperty("/tabProfileSize/selectedProfileId", null);
								this.setStateProperty("/tabRAL/selectedRALFaceId", null);
								var oUrlParam = {
									Uuid: this.getStateProperty("/_GET").CodeCp //Поле Uuid
								};
								this._executeResetFilter(oUrlParam, false);
							}
						}.bind(this)
					});
				}.bind(this));
			},

			onEditCPPressHandler: function() {
				var oUrlParam = {
					CodeCp: this.getStateProperty("/_GET").CodeCp,
					StatusCp: this.getStateProperty("/_GET").StatusCp
				};

				this._executeEditCP(oUrlParam, false);
			},

			onCreateCPByTemplatePressHandler: function(oControlEvent) {
				if (this._oCreateCPByTemplateDialog) {
					this._oCreateCPByTemplateDialog.destroy();
				}
				this._oCreateCPByTemplateDialog = new sap.ui.xmlfragment("ZO2C_COM_PROD.ZO2C_COM_PROD.view.dialogs.CreateCPByTemplate", this);
				this.getView().addDependent(this._oCreateCPByTemplateDialog);
				this._oCreateCPByTemplateDialog.openBy(oControlEvent.getSource());

				if (this.getStateProperty("/app/fcModel").Profile_fc === 0 && thus.getStateProperty("/app/fcModel").ProfileSize_fc === 0) {
					var iCount = 0;
					this.getStateProperty("/selectDialogData/copy").forEach(function(oTab) {
						if (oTab.text === this.getResourceBundle().getText("profilesizeTab")) {
							this.setStateProperty("/selectDialogData/copy/" + iCount + "/selected", false);
							this.setStateProperty("/selectDialogData/copy/" + iCount + "/visible", false);
						}
						iCount++;
					}.bind(this));
				}
				if (this.getStateProperty("/app/fcModel").RALFace_fc === 0 && this.getStateProperty("/app/fcModel").RALBack_fc === 0) {
					var iCount = 0;
					this.getStateProperty("/selectDialogData/copy").forEach(function(oTab) {
						if (oTab.text === this.getResourceBundle().getText("ralTab")) {
							this.setStateProperty("/selectDialogData/copy/" + iCount + "/selected", false);
							this.setStateProperty("/selectDialogData/copy/" + iCount + "/visible", false);
						}
						iCount++;
					}.bind(this));
				}
				if (this.getStateProperty("/app/fcModel").DecorativeTape_fc === 0) {
					var iCount = 0;
					this.getStateProperty("/selectDialogData/copy").forEach(function(oTab) {
						if (oTab.text === this.getResourceBundle().getText("decorativetapeTab")) {
							this.setStateProperty("/selectDialogData/copy/" + iCount + "/selected", false);
							this.setStateProperty("/selectDialogData/copy/" + iCount + "/visible", false);
						}
						iCount++;
					}.bind(this));
				}
			},

			applyCreateCPByTemplateButton: function(oEvent) {
				var aSelectedPath = this.getControlsByFieldGroupId("SelectionList")[0].getSelectedContextPaths();
				var oStateModel = this.getModel("state");
				var aKey = [];
				aSelectedPath.forEach(function(sPath) {
					aKey.push(oStateModel.getProperty(sPath).key);
				}.bind(this));

				var oUrlParam = {
					SrcCodeCp: this.getStateProperty("/_GET").CodeCp,
					SrcStatusCp: this.getStateProperty("/_GET").StatusCp,
					CopyMain: aKey.indexOf("1") > -1,
					CopyChem: aKey.indexOf("2") > -1,
					CopyMech: aKey.indexOf("3") > -1,
					CopyTech: aKey.indexOf("4") > -1,
					CopyClassif: aKey.indexOf("5") > -1,
					CopyProf: aKey.indexOf("6") > -1,
					CopyOthers: aKey.indexOf("7") > -1,
					CopyRAL: aKey.indexOf("8") > -1,
					CopyDecor: aKey.indexOf("9") > -1
				};

				this._executeCreateCPByTemplate(oUrlParam, false);

				this._oCreateCPByTemplateDialog.close();
			},

			cancelCreateCPByTemplateButton: function() {
				this._oCreateCPByTemplateDialog.close();
			},

			onGetCPInSearchResultPressHandler: function(oEvent) {
				var oButton = sap.ui.getCore().byId(oEvent.getParameter("id"));
				var sDirection = "";
				if (oButton.data("direction") === "forward") {
					sDirection = "F";
				} else if (oButton.data("direction") === "backward") {
					sDirection = "B";
				}

				var oUrlParam = {
					CodeCp: this.getStateProperty("/_GET").CodeCp,
					StatusCp: this.getStateProperty("/_GET").StatusCp,
					FilterUuid: this.getStateProperty("/applyFilter").FilterUuid,
					Direction: sDirection
				};

				this._executeGetCPInSearchResult(oUrlParam, false);
			},

			onListOfFoundCPPressHandler: function(oEvent) {
				if (this._oListOfFoundCPPopover) {
					this._oListOfFoundCPPopover.destroy();
				}
				this._oListOfFoundCPPopover = new sap.ui.xmlfragment("ZO2C_COM_PROD.ZO2C_COM_PROD.view.dialogs.ListOfFoundCP", this);
				this.getView().addDependent(this._oListOfFoundCPPopover);
				this._oListOfFoundCPPopover.openBy(oEvent.getSource());

				var oTable = this.getControlsByFieldGroupId("FoundCPTable")[0];
				var oBinding = oTable.getBinding("items");
				if (oBinding) {
					var oFilter = new sap.ui.model.Filter("FilterUuid", "EQ", "guid'" + this.getStateProperty("/applyFilter").FilterUuid + "'");
					oBinding.filter([oFilter], "Application");
				}
			},

			acceptListOfFoundCPButton: function(oEvent) {
				this._oListOfFoundCPPopover.close();

				var oTable = this.getControlsByFieldGroupId("FoundCPTable")[0];
				var oSelectedRow = oTable.getSelectedItem();
				var oSelectedRowData = oSelectedRow.getBindingContext().getObject();

				if (!!oSelectedRowData && !!oSelectedRowData.CodeCp && !!oSelectedRowData.StatusCp) {
					this.getRouter().navTo("objectPage", {
						AppMode: "view",
						CodeCp: oSelectedRowData.CodeCp,
						StatusCp: oSelectedRowData.StatusCp,
						Tab: this.getStateProperty("/_GET").Tab
					}, false);
				}
			},

			onChangeHistoryHandler: function() {
				this.getRouter().navTo("changeLog", {
					AppMode: this.getStateProperty("/_GET").AppMode,
					CodeCp: this.getStateProperty("/_GET").CodeCp,
					StatusCp: this.getStateProperty("/_GET").StatusCp,
					Tab: this.getStateProperty("/_GET").Tab,
					bChangeLog: true
				}, false);
			},
			setChainVisFilterCP: function(oEvent){
				var oTable = oEvent.getSource().getParent().getParent().getTable();
				var selectRows = oTable.getSelectedIndices();
				var aRowsCodeCP = [];
				for (var i = 0; i <selectRows.length; i ++) {
					if (oTable.isIndexSelected (selectRows[i])) {
						var cxt = oTable.getContextByIndex (selectRows[i]);
						var obj = oTable.getModel (). getProperty (cxt.sPath);
						aRowsCodeCP.push(obj.CodeCp);
					}
				}
				if (aRowsCodeCP && aRowsCodeCP.length > 0){
					var sFilterUuid = this.getFilterUuidForChainApp();
					var sCPCodes = aRowsCodeCP.join('\t');
					this.showBusy();
					this.getModel().callFunction("/SetChainVisFilterCP",{
							method:"POST",
							urlParameters:{
								FilterUuid: sFilterUuid,
								CodCp: sCPCodes
							},
						success: function(oData, oMessage) {
							this.hideBusy();
							//nav Back
							window.history.back();
							MessageToast.show(this.getResourceBundle().getText("successCreateFilter"));
						
						}.bind(this),
						error: function(oError) {
							this.hideBusy();
							MessageBox.error(this.parseRequestError(oError));
						
						}.bind(this)
					});
				}
			},
			
			cancelListOfFoundCPButton: function(oEvent) {
				this._oListOfFoundCPPopover.close();
			},

			handleListOfFoundCPSearch: function(oEvent) {
				// add filter for search
				var aFilters = [];
				var sQuery = oEvent.getSource().getValue();
				if (sQuery && sQuery.length > 0) {
					var filter = new Filter("CodeCpH", "Contains", sQuery);
					aFilters.push(filter);
				}

				// update table binding
				var oTable = this.getControlsByFieldGroupId("FoundCPTable")[0];
				var oBinding = oTable.getBinding("items");
				oBinding.filter(aFilters, "Application");
			},

			onCancelChangesPressHandler: function() {
				this.saveChanges(false, function() {
					var sWarningText = "";
					if (this.getStateProperty("/_GET").AppMode === "edit") {
						sWarningText = this.getResourceBundle().getText("textCancelChangesOnEdit");
					} else if (this.getStateProperty("/_GET").AppMode === "create") {
						sWarningText = this.getResourceBundle().getText("textCancelChangesOnCreate");
					}
					MessageBox.warning(sWarningText, {
						actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
						onClose: function(sAction) {
							if (sAction === "OK") {
								var oUrlParam = {
									CodeCp: this.getStateProperty("/_GET").CodeCp,
									StatusCp: this.getStateProperty("/_GET").StatusCp
								};

								this._executeCancelChanges(oUrlParam, true);
							}
						}.bind(this)
					});
				}.bind(this));
			},

			onSaveCPPressHandler: function() {
				this.getModel().setWaitingForSave(false);
				this.getOwnerComponent()._oMessageManager.removeAllMessages();
				this.saveChanges(false, function() {
					if (this.getStateProperty("/check").urgency !== "INAC") {
						var oUrlParam = {
							CodeCp: this.getStateProperty("/_GET").CodeCp,
							StatusCp: this.getStateProperty("/_GET").StatusCp
						};
						this._executeSaveCP(oUrlParam, true);
					} else {
						MessageBox.confirm(this.getResourceBundle().getText("textCheckUrgency"), {
							actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
							onClose: function(sAction) {
								if (sAction === "OK") {
									var oUrlParam = {
										CodeCp: this.getStateProperty("/_GET").CodeCp,
										StatusCp: this.getStateProperty("/_GET").StatusCp,
										SaveNotActive: true
									};
									this._executeSaveCP(oUrlParam, true);
								}
							}.bind(this)
						});
					}
				}.bind(this));
			},

			onCheckOnRelationHandler: function(oEvent) {
				this.getOwnerComponent()._oMessageManager.removeAllMessages();
				this.saveChanges(false, function() {
					var oUrlParam = {
						CodeCp: this.getStateProperty("/_GET").CodeCp,
						StatusCp: this.getStateProperty("/_GET").StatusCp,
						LinkVariant: this.getStateProperty("/_GET").LinkVariant
					};
					this._executeCheckOnRelation(oUrlParam, false);
				}.bind(this));
			},

			onSaveRelationHandler: function(oEvent) {
				window.history.go(-1);
				this.getOwnerComponent()._oMessageManager.removeAllMessages();
			},

			onBackToSearch: function(oEvent) {
				this.saveChanges(false, function() {
					this.getRouter().navTo("objectPageSearch", {
						AppMode: "search",
						CodeCp: this.getStateProperty("/applyFilter").FilterUuid,
						Tab: "General"
					}, false);
					this.getOwnerComponent()._oMessageManager.removeAllMessages();
				}.bind(this));
			},

			onApplyViewPressHandler: function(oEvent) {
				this.saveChanges(false, function() {
					var oPanel = this.getControlsByFieldGroupId("OPFoundCPPanel")[0];
					oPanel.setVisible(true);
					var oSmartTable = this.getControlsByFieldGroupId("OPFoundCPSmartTable")[0];
					oSmartTable.getTable().setFirstVisibleRow(0);
					this.setStateProperty("/searchResults/display", true);
					this.setStateProperty("/searchResults/lastAppliedFilterUuid", this.getStateProperty("/_GET").CodeCp);
					this.executeSimpleRefreshSmartTable("OPFoundCPSmartTable", "MainCPSet");
				}.bind(this));
			},

			onClearFilterViewPressHandler: function(oEvent) {
				this.saveChanges(false, function() {
					MessageBox.warning(this.getResourceBundle().getText("textClearFilterViewCofirmation"), {
						actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
						onClose: function(sAction) {
							if (sAction === "OK") {
								if (this.getStateProperty("/_GET").Tab === "ProfileSize") {
									this.setStateProperty("/tabProfileSize/selectedProfileId", null);
								} else if (this.getStateProperty("/_GET").Tab === "RAL") {
									this.setStateProperty("/tabRAL/selectedRALFaceId", null);
								}
								var sViewCp = this.getViewCpByViewName(this.getStateProperty("/_GET").Tab);
								var oUrlParam = {
									ViewCp: sViewCp,
									Uuid: this.getStateProperty("/_GET").CodeCp //Поле Uuid
								};
								this._executeClearFilterView(oUrlParam, false);
							}
						}.bind(this)
					});
				}.bind(this));
			},

			onSaveViewPressHandler: function(oEvent) {
				this.saveChanges(false, function() {
					var sViewCp = this.getViewCpByViewName(this.getStateProperty("/_GET").Tab);
					var oUrlParam = {
						CodeCp: this.getStateProperty("/_GET").CodeCp,
						StatusCp: this.getStateProperty("/_GET").StatusCp,
						ViewCp: sViewCp
					};
					this._executeSaveView(oUrlParam, false);
				}.bind(this));
			},

			onCheckCPPressHandler: function(oEvent) {
				this.getOwnerComponent()._oMessageManager.removeAllMessages();
				this.saveChanges(false, function() {
					var oUrlParam = {
						CodeCp: this.getStateProperty("/_GET").CodeCp,
						StatusCp: this.getStateProperty("/_GET").StatusCp
					};
					this._executeCheckCP(oUrlParam, false);
				}.bind(this));
			},

			onClearCPViewPressHandler: function(oEvent) {
				this.saveChanges(false, function() {
					MessageBox.warning(this.getResourceBundle().getText("textClearCPViewCofirmation"), {
						actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
						onClose: function(sAction) {
							if (sAction === "OK") {
								if (this.getStateProperty("/_GET").Tab === "ProfileSize") {
									this.setStateProperty("/tabProfileSize/selectedProfileId", null);
								} else if (this.getStateProperty("/_GET").Tab === "RAL") {
									this.setStateProperty("/tabRAL/selectedRALFaceId", null);
								}
								var sViewCp = this.getViewCpByViewName(this.getStateProperty("/_GET").Tab);
								var oUrlParam = {
									CodeCp: this.getStateProperty("/_GET").CodeCp,
									StatusCp: this.getStateProperty("/_GET").StatusCp,
									ViewCp: sViewCp
								};
								this._executeClearCPView(oUrlParam, false);
							}
						}.bind(this)
					});
				}.bind(this));
			},

			onActualizeCPRecordsPressHandler: function(oEvent) {
				this.saveChanges(false, function() {
					MessageBox.warning(this.getResourceBundle().getText("textActualizeCPRecordsCofirmation"), {
						actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
						onClose: function(sAction) {
							if (sAction === "OK") {
								var oUrlParam = {
									FilterUuid: this.getStateProperty("/_GET").CodeCp //Поле Uuid
								};
								this._executeActualizeCPRecords(oUrlParam, false);
							}
						}.bind(this)
					});
				}.bind(this));
			},

			onBeforeRebindFoundCP: function(oEvent) {
				var binding = oEvent.getParameter("bindingParams");
				var oFilter = new sap.ui.model.Filter("FilterUuid", "EQ", this.getStateProperty("/applyFilter").FilterUuid);
				binding.filters.push(oFilter);
			},

			onDataReceivedFoundCP: function(oEvent) {
				if (oEvent && oEvent.getParameters() && oEvent.getParameters().getParameters() && oEvent.getParameters().getParameters().data && oEvent.getParameters().getParameters().data.results) {
					var sCount = oEvent.getParameters().getParameters().data.__count;
					var oPanel = this.getControlsByFieldGroupId("OPFoundCPPanel")[0];
					oPanel.setHeaderText(this.getResourceBundle().getText("textOPFoundCP") + " (" + sCount + ")");
				}
			},

			onRowSelectionChange: function(oEvent) {
				var oSelectedRow = oEvent.getParameter("rowContext").getObject();
				if(!(this.getStateProperty("/app/action")==="chain")){
					this.getRouter().navTo("objectPage", {
						AppMode: "view",
						CodeCp: oSelectedRow.CodeCp,
						StatusCp: oSelectedRow.StatusCp,
						Tab: "Chemical"
					}, false);
					this.getControlsByFieldGroupId("OPFoundCPSmartTable")[0].getTable().clearSelection();
				}
			},

			getViewCpByViewName: function(sViewName) {
				var sViewCp = "";
				if (sViewName === "General") {
					sViewCp = "G";
				} else if (sViewName === "Technical") {
					sViewCp = "T";
				} else if (sViewName === "Chemical") {
					sViewCp = "C";
				} else if (sViewName === "Mechanical") {
					sViewCp = "M";
				} else if (sViewName === "Classif") {
					sViewCp = "K";
				} else if (sViewName === "ProfileSize") {
					sViewCp = "P";
				} else if (sViewName === "OtherCharact") {
					sViewCp = "V";
				} else if (sViewName === "RAL") {
					sViewCp = "R";
				} else if (sViewName === "DecorativeTape") {
					sViewCp = "D";
				}
				return sViewCp;
			},

			createActionButtonHandler: function() {
				this.showBusy();
				this.getModel().callFunction("/copyMainFilter", {
					method: "POST",
					urlParameters: {
						CodeCp: "",
						NumberProp: ""
					},
					success: function(oData, oMessage) {
						this.hideBusy();
						if (!!oData && !!oData.CodeCp) {
							this.getRouter().navTo("objectPage", {
								CodeCp: oData.CodeCp,
								Tab: "General"
							}, false);
						}
					}.bind(this),
					error: function(oError) {
						this.hideBusy();
						MessageBox.error(this.parseRequestError(oError));
					}.bind(this)
				});
			},

			//-----------------------------
			//Переход по текущему фильтру к приложению c отчетам
			//-----------------------------
			onReportsOpen: function(oEvent){
				if (!this._oReportsPopover) {
					this._oReportsPopover = sap.ui.xmlfragment("ZO2C_COM_PROD.ZO2C_COM_PROD.view.fragments.ReportsPopover", this);
					this.getView().addDependent(this._oReportsPopover);
				}	
				this._oReportsPopover.openBy(oEvent.getSource());
			},
			
			onOpenAppReports: function(oEvent){
				var sUuid = this.getStateProperty("/_GET").CodeCp;
				var oModel = this.getModel();
				var sPathMdl = oEvent.getParameter("listItem").getBindingContextPath();
				var sKeyRep = oModel.getProperty(sPathMdl + "/KeyRep");

				var oCrossNav = sap.ushell.Container.getService("CrossApplicationNavigation");
				var sHref = oCrossNav.hrefForExternal({
					target : { semanticObject : "zo2c_cp_reports", action : "display" },
					params : { "KeyRep" : sKeyRep, "Uuid" : sUuid }
				});
				sap.m.URLHelper.redirect(window.location.href.split('#')[0] + sHref, true);
			}
		});

	$.extend(true, thisController.prototype);
	return thisController;
});
