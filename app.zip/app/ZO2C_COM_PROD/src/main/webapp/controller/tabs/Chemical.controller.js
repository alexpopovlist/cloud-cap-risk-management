sap.ui.define([
	"ZO2C_COM_PROD/ZO2C_COM_PROD/controller/BaseController",
	"ZO2C_COM_PROD/ZO2C_COM_PROD/custom/class/Common",
	"sap/m/MessageToast",
	"sap/ui/model/Filter",
	"sap/m/MessageBox"

], function(BaseController, Common, MessageToast, Filter, MessageBox) {
	"use strict";

	var thisController = BaseController.extend("ZO2C_COM_PROD.ZO2C_COM_PROD.controller.tabs.Chemical", {

		Common: Common,
		_oAddChemicalFilterItemDialog: null,
		_oInfoPopover: null,
		_bFirstLoad: true, //TODO Заменить на свойство в модели
		_chemicalVBoxContent: null,

		onInit: function() {
			if (this.getStateProperty("/_GET").Tab === "Chemical") {
				this.do(this.processLoad.bind(this), [true]);
			}
		},

		onCheckBoxValueSelectHandler: function(oEvent) {
			var oSource = oEvent.getSource();

			if (!!oSource.data("selectFlag")) {
				this.setStateProperty("/oSearchChemicalValueEnableESelect/" + oSource.data("selectFlag"), oSource.getSelected());
			}
		},

		onSearchTableDataRecieved: function(oEvent) {
			var oItems = oEvent.getSource().getAggregation("items");
			if (!!oItems && oItems.length > 1 && !!oItems[1].getBinding().getContexts() && oItems[1].getBinding().getContexts().length > 5) {
				var oSmartTableItems = oItems[1].getBinding().getContexts()[4].getObject();
				this.setStateProperty("/oSearchChemicalEnableESelect", oSmartTableItems);

				var oSmartTableValueItems = oItems[1].getBinding().getContexts()[5].getObject();
				this.setStateProperty("/oSearchChemicalValueEnableESelect", oSmartTableValueItems);
			}
		},

		addFragmentToChemical: function() {
			var oChemicalVBox = this.getById("idChemicalVBox");

			this.destroyChemicalContent();

			if (!this._chemicalVBoxContent) {
				this._chemicalVBoxContent = new sap.ui.xmlfragment(
					this.createId(this.getStateProperty("/_GET").Tab),
					this._getFragmentPath(),
					this
				);
				this.getView().addDependent(this._chemicalVBoxContent);
			}

			oChemicalVBox.addItem(this._chemicalVBoxContent);
		},

		onInLinkSelectHandler: function(oControlEvent) {
			this.onInLinkSelectRelation(oControlEvent);
		},

		onShowAvailabilityInfo: function(oEvent) {
			var oSource = oEvent.getSource();

			this._availInfoPopover = this._availInfoPopover || new sap.m.Popover({
				showHeader:false,
				content:[
					new sap.m.Text({
						text: this.getText("availabilityRestrictInfo")
					}).addStyleClass("sapUiTinyMargin")
				]
			});

			if(this._availInfoPopover.isOpen()) return;

			this._availInfoPopover.openBy(oSource);

			setTimeout(function() {
				this._availInfoPopover.close();
			}.bind(this),1500);
		},

		destroyChemicalContent: function() {
			var oChemicalVBox = this.getById("idChemicalVBox");
			var aItems = oChemicalVBox.getItems();

			aItems.forEach(function(oItem) {
				oItem.destroy();
			});

			oChemicalVBox.removeAllItems();
			this._chemicalVBoxContent = null;
		},

		_getFragmentPath: function() {
			const sAppMode = this.getStateProperty("/_GET").AppMode;
			var sFragmentPath = "";

			if (sAppMode === "view" || sAppMode === "edit" || sAppMode === "create" || sAppMode === "relation") {
				sFragmentPath = "ZO2C_COM_PROD.ZO2C_COM_PROD.view.tabs.Chemical.ViewEditCreate";
			} else if (sAppMode === "search") {
				sFragmentPath = "ZO2C_COM_PROD.ZO2C_COM_PROD.view.tabs.Chemical.Search";
			}
			return sFragmentPath;
		},

		_getChemiSmTable: function() {
			var sTableId = this.getStateProperty("/_GET").AppMode === "search" ? "smartTableChemicalCompositionSearch" : "smartTableChemicalComposition";
			return this.getControlsByFieldGroupId(sTableId)[0];
		},

		onShowIncorrectEntries: function(oEvent) {
			if (this.getStateProperty("/_GET/AppMode") === "view") {
				this.getControlsByFieldGroupId("smartTableChemicalComposition")[0].rebindTable();
			}
		},

		changeChemItemStatus: function(oEvent) {
			var aCheckBoxes = this.getControlsByFieldGroupId("selectChemicalComposition"),
				aRowContexts = aCheckBoxes.filter(function(oBox) {
					return oBox.getSelected()
				}).map(function(oCorrectRow) {
					return oCorrectRow.getBindingContext();
				});
			if (!!aRowContexts && aRowContexts.length > 0) {
				var oModel = this.getModel();
				this.do(function() {
					aRowContexts.forEach(function(oContext) {
						if (!!oContext.getProperty('Assimilate')) {
							oModel.update(oContext.getPath(), {
								Assimilate: false
							})
						} else if (!!oContext.getProperty('AssimilateFlt')) {
							oModel.update(oContext.getPath(), {
								AssimilateFlt: false
							})
						}
					});
					this.hideBusy();
					this.attachResolveOnBatchComplete();
				}.bind(this));
			}
		},

		addChemItemFromTableDialog: function() {

		},

		deleteChemItem: function() {

		},

		onOpenPopover: function(oEvent) {
			var oIcon = oEvent.getSource();
			// create popover
			if (!this._oInfoPopover) {
				this._oInfoPopover = new sap.ui.xmlfragment("popoverInfo", "ZO2C_COM_PROD.ZO2C_COM_PROD.view.dialogs.ChemInformationPopover", this);
				this.getView().addDependent(this._oInfoPopover);
			}
			var oCtx = oIcon.getBindingContext();
			this._oInfoPopover.bindElement(oCtx.getPath());
			this._oInfoPopover.openBy(oIcon);
		},

		processLoad: function(bTabReload) {
			this.setStateProperty("/app/currentTabId", this.getView().getId());
			this.setStateProperty("/showIncorrectEntries/chemical", false);
			this.setStateProperty("/showIncorrectEntries/chemicalAssim", false);


			this.addFragmentToChemical();

			if (!!this.getStateProperty("/app/currentView")) {
				this.hideBusy();
				this.setStateProperty("/app/refreshObject", true);
				if (bTabReload) {
					if (this.getStateProperty("/_GET/AppMode") === "search") {
						this.executeRefreshSmartTableViaFieldGroupIds("smartTableChemicalCompositionSearch", "toChemicalElem");
					} else {
						this.executeRefreshSmartTableViaFieldGroupIds("smartTableChemicalComposition", "toChemical");
					}

				}
				this.makeElementBinding(!bTabReload);
			} else {
				this.setStateProperty("/prevTabId", this.getPageController().getSelectedTabView().getId());
				this.doResolve();
			}
		},

		addChemicalFilterItem: function() {
			if (this._oAddChemicalFilterItemDialog) {
				this._oAddChemicalFilterItemDialog.destroy();
			}
			this._oAddChemicalFilterItemDialog = new sap.ui.xmlfragment("ZO2C_COM_PROD.ZO2C_COM_PROD.view.dialogs.AddChemicalFilterItem", this);
			this.getView().addDependent(this._oAddChemicalFilterItemDialog);
			this._oAddChemicalFilterItemDialog.open();
		},

		addChemicalFilterItemAccept: function(oEvent) {
			var oSource = oEvent.getSource(),
				sNavProp = '/toChemical';
			var oMainTable = this.getControlsByFieldGroupId("smartTableChemicalComposition")[0];
			var oSmartTable = this.getControlsByFieldGroupId("chemiAreaFilterSmartTable")[0];
			var aListItems = oSmartTable.getTable().getSelectedContexts();
			var sCreatePath = oSource.getBindingContext().getPath() + sNavProp;
			var aItems = aListItems.map(function(oChemItem) {
				return {
					path: sCreatePath,
					properties: {
						ChemiSetCode: oChemItem.getObject().ChemiSetCode
					}
				}
			});
			this.createItems(aItems).then(function(data) {
				oMainTable.rebindTable();
				this.hideBusy();
				if (this._oAddChemicalFilterItemDialog !== null) {
					this._oAddChemicalFilterItemDialog.close();
				}
				if (!!data && !!data[0] && !!data[0].response) {
					try {
					  var sMsg = "";
					  data.forEach(function(oDataItem) {
					  	if (!!oDataItem.response.headers["sap-message"]) {
					  		sMsg += $.sap.parseJS(oDataItem.response.headers["sap-message"]).message + '\n\n';
					 	}
					  }.bind(this));
					
					  MessageToast.show(sMsg);
					
					} catch (err) {
					  MessageToast.show(this.getResourceBundle().getText("textCreateChemicalItemsSuccess"));
					}
				} else {
					MessageToast.show(this.getResourceBundle().getText("textCreateChemicalItemsSuccess"));
				}

			}.bind(this));
		},

		addChemicalFilterItemCancel: function(oEvent) {
			this._oAddChemicalFilterItemDialog.close();
		},

		handleAddChemicalFilterItemSearch: function(oEvent) {
			var aFilters = [];
			var sQuery = oEvent.getSource().getValue();
			if (sQuery && sQuery.length > 0) {
				var oFilterName = new sap.ui.model.Filter("ElemName", sap.ui.model.FilterOperator.Contains, sQuery);
				aFilters.push(oFilterName);
			}
			var oFilter = new sap.ui.model.Filter("CodeCp", sap.ui.model.FilterOperator.EQ, this.getStateProperty("/_GET").CodeCp);
			aFilters.push(oFilter);

			var oList = this.getControlsByFieldGroupId("listOfChemicalFilterItems")[0]
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilters, "Application");
		},

		onDeleteChemicalItemMulti: function (oEvent) {
			var bCheckSelected = false;
			var	aAllItems = this.getControlsByFieldGroupId("selectChemicalComposition");

			for (var i = 0; i < aAllItems.length; i++) {
				if (aAllItems[i].getSelected()) {
					bCheckSelected = true;
					break;
				}
			}

			if (bCheckSelected) {
				MessageBox.warning(this.getResourceBundle().getText("deleteChemiItemsCofirmation"), {
					actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
					onClose: function (sAction) {
						if (sAction === "OK") {
							this.deleteChemicalItem(aAllItems);
						}
					}.bind(this)
				});
			} else {
				MessageBox.error(this.getResourceBundle().getText("textNoSelectedRecordsDelete"), {
					icon: MessageBox.Icon.ERROR,
					title: this.getResourceBundle().getText("titleError")
				});
				this.hideBusy();
			}
		},

		deleteChemicalItem: function(aAllItems) {
			var oSmartTable = this.getControlsByFieldGroupId("smartTableChemicalComposition")[0];
			var aPromises = [];

			aAllItems.forEach(function(oItem) {
				if (oItem.getSelected() && oItem.getBindingContext()) {
					var sPath = oItem.getBindingContext().getPath();
					var oPromise = new Promise(function(resolve, reject) {
						this.getModel().remove(sPath, {
							success: function(oResponse, oMessage) {
								resolve();
							}.bind(this),
							error: function(oError) {
								reject(oError);
							}.bind(this)
						});
					}.bind(this));
					aPromises.push(oPromise);
				}
			}.bind(this));

			Promise.all(aPromises).then(
				function(oData) {
					oSmartTable.getTable().getBinding("rows").refresh(true);
					this.hideBusy();
				}.bind(this),
				function(oError) {
					this.hideBusy();
				}.bind(this)
			);
		},

		deleteChemicaFilterlItem: function() {
			this.showBusy();

			var oSmartTable = this.getControlsByFieldGroupId("smartTableChemicalFilter")[0];
			var aItems = oSmartTable.getTable().getSelectedItems();
			var aPromises = [];
			var oModel = this.getModel();

			if (aItems.length > 0) {
				aItems.forEach(function(oItem) {
					
				}.bind(this));

				Promise.all(aPromises).then(
					function(oData) {
						oSmartTable.getTable().getBinding("items").refresh(true);
						oSmartTable.getTable().removeSelections(true);
						this.hideBusy();
					}.bind(this),
					function(oError) {
						this.hideBusy();
					}.bind(this)
				);
			} else {
				MessageBox.error(this.getResourceBundle().getText("textNoSelectedRecordsChemical"), {
					icon: MessageBox.Icon.ERROR,
					title: this.getResourceBundle().getText("titleErrorChemical")
				});
				this.hideBusy();
			}
		},

		onRefreshChemicalTable: function() {
			var oSmartTable = this.getControlsByFieldGroupId("smartTableChemicalComposition")[0];
			oSmartTable.getTable().getBinding("rows").refresh(true);
		},

		onBeforeRebindChemicalComposition: function(oControlEvent) {
			if (this.getStateProperty("/_GET").AppMode === "view") {
				var oBindingParams = oControlEvent.getParameter("bindingParams");
				var bMechError = this.getStateProperty("/showIncorrectEntries/chemical");
				var bAssim = this.getStateProperty("/showIncorrectEntries/chemicalAssim");
				var aFilters = this._getAssimErrorRowFilters(bAssim, bMechError, oBindingParams.filters);
				oBindingParams.filters = aFilters;
			}
		},

		onDataReceivedChemicalComposition: function () {
			var bMechError = this.getStateProperty("/showIncorrectEntries/chemical");
			var bAssim = this.getStateProperty("/showIncorrectEntries/chemicalAssim");
			var aFilters = this._getAssimErrorRowFilters(bAssim, bMechError);
			
			this.executeCountRequest("smartTableChemicalComposition", "toChemical", "", aFilters);
		},

		onAssimilatePressHandler: function (oControlEvent) {
			this._onAssimilateOnTablePress(oControlEvent, true);
		},

		onErrorRowPressHandler: function (oControlEvent) {
			this._onErrorRowOnTablePress(oControlEvent);
		},

		afterRequest:function(oEvent){
			var oControl = oEvent.getSource();
			console.log("++");
		},

		configureTableRowColor: function() {
			var oSmartTable = {};
			if (this.getStateProperty("/_GET").AppMode === "search") {
				oSmartTable = this.getControlsByFieldGroupId("smartTableChemicalCompositionSearch")[0];
			} else {
				oSmartTable = this.getControlsByFieldGroupId("smartTableChemicalComposition")[0];
			}
			var oTable = oSmartTable.getTable();
			var oModel = this.getModel();
			var colorRows = function() {
				var rowStart = oTable.getFirstVisibleRow();
				var aRows = oTable.getRows();
				
				aRows.forEach(function(oRow, ind) {
					var currentRowContext = oTable.getContextByIndex(rowStart + ind);
					oRow.$().removeClass("sapUiTableRowSel");
					var value = oModel.getProperty("IsHeader", currentRowContext);
					if (value) {
						oRow.$().addClass("sapUiTableRowSel");
					}
				}.bind(this));
			}

			colorRows();

			oTable.addEventDelegate({
				onAfterRendering: function() {
					colorRows();
				}
			});
		},

		onSortChemicalComposition: function() {
			var oSmartTable = this._getSmartTable("smartTableChemicalComposition");
			if (oSmartTable) {
				oSmartTable.openPersonalisationDialog("Sort");
			}
		},

		onFilterChemicalComposition: function() {
			var oSmartTable = this._getSmartTable("smartTableChemicalComposition");
			if (oSmartTable) {
				oSmartTable.openPersonalisationDialog("Filter");
			}
		},

		_getSmartTable: function(sTableId) {
			if (!this._oSmartTable) {
				this._oSmartTable = this.getControlsByFieldGroupId(sTableId)[0];
			}
			return this._oSmartTable;
		},

		chemAreaSetCount: function(oData) {

		}

	});

	$.extend(true, thisController.prototype);
	return thisController;
});
