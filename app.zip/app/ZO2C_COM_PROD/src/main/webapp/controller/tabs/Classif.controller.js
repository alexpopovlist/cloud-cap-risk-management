sap.ui.define([
	"ZO2C_COM_PROD/ZO2C_COM_PROD/controller/BaseController",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/model/Filter"

], function(BaseController, MessageToast, MessageBox, Filter) {
	"use strict";

	const thisController = BaseController.extend("ZO2C_COM_PROD.ZO2C_COM_PROD.controller.tabs.Classif", {

		_customObjectDraftIndicator: null,
		_classifVBoxContent: null,
		_oCopyFromCPDialog: null,
		_bFirstLoad: true, //TODO Заменить на свойство в модели

		onInit: function() {
			this._customObjectDraftIndicator = this.getStateProperty("/app").customObjectDraftIndicator;
			if (this.getStateProperty("/_GET").Tab === "Classif") {
				this.do(this.processLoad.bind(this), [true]);
			}
		},

		processLoad: function(bTabReload) {
			this.setStateProperty("/app/currentTabId", this.getView().getId());
			this.setStateProperty("/showIncorrectEntries/classif", false);
			this.setStateProperty("/showIncorrectEntries/classifAssim", false);

			this.addFragmentToClassif();

			this.setStateProperty("/classif/showSelected", false);
			if (this.getStateProperty("/_GET").AppMode === "view" || this.getStateProperty("/_GET").AppMode === "relation"){
				this.setStateProperty("/classif/showSelected", true);
			}

			if (!!this.getStateProperty("/app/currentView")) {
				this.hideBusy();
				this.setStateProperty("/app/refreshObject", true);
				if (bTabReload) {
					this.executeRefreshSmartTableViaFieldGroupIds("ClassifSmartTable", "toClassifiers");
				}

				this.makeElementBinding(!bTabReload);
			} else {
				this.setStateProperty("/prevTabId", this.getPageController().getSelectedTabView().getId());
				this.doResolve();
			}
		},

		addFragmentToClassif: function() {
			const oClassifVBox = this.getById("idClassifVBox");

			this.destroyClassifContent();

			if (!this._classifVBoxContent) {
				this._classifVBoxContent = new sap.ui.xmlfragment(
					this.createId(this.getStateProperty("/_GET").Tab),
					this._getFragmentPath(),
					this
				);
				this.getView().addDependent(this._classifVBoxContent);
			}

			oClassifVBox.addItem(this._classifVBoxContent);
		},


		destroyClassifContent: function() {
			const oClassifVBox = this.getById("idClassifVBox");
			const aItems = oClassifVBox.getItems();

			aItems.forEach(function(oItem) {
				oItem.destroy();
			});

			oClassifVBox.removeAllItems();
			this._classifVBoxContent = null;
		},

		_getFragmentPath: function() {
			const sAppMode = this.getStateProperty("/_GET").AppMode;
			var sFragmentPath = "";

			if (sAppMode === "view" || sAppMode === "edit" || sAppMode === "create" || sAppMode === "relation") {
				sFragmentPath = "ZO2C_COM_PROD.ZO2C_COM_PROD.view.tabs.Classif.ViewEditCreate";
			} else if (sAppMode === "search") {
				sFragmentPath = "ZO2C_COM_PROD.ZO2C_COM_PROD.view.tabs.Classif.Search";
			}
			return sFragmentPath;
		},

		onInLinkSelectHandler: function (oControlEvent) {
			this.onInLinkSelectRelation(oControlEvent);
		},

		onShowIncorrectEntries: function() {
			if (this.getStateProperty("/_GET/AppMode") === "view") {
				this.getControlsByFieldGroupId("ClassifSmartTable")[0].rebindTable();
			}
		},

		onBeforeRebindClassifItemsTreeTable: function(oControlEvent) {
			const oBindingParams = oControlEvent.getParameter("bindingParams");
			var bIsSelected = this.getStateProperty("/classif/showSelected");
			var bMechError = this.getStateProperty("/showIncorrectEntries/classif");
			var bAssim = this.getStateProperty("/showIncorrectEntries/classifAssim");
			var aFilters = [];
					

			oBindingParams.parameters = oBindingParams.parameters || {};
			oBindingParams.parameters.countMode = 'Inline';
			oBindingParams.parameters.treeAnnotationProperties = {
				hierarchyLevelFor: 'HierarchyLevel',
				hierarchyNodeFor: 'NodeId',
				hierarchyParentNodeFor: 'ParentNodeId',
				hierarchyDrillStateFor: 'DrillState'
			};
			oBindingParams.templateShareable = true;

			if (this.getStateProperty("/_GET").AppMode === "view") {
				aFilters = this._getAssimErrorRowFilters(bAssim, bMechError, oBindingParams.filters);
			}
			
			if (bIsSelected) {
				aFilters.push(new Filter("IsSelect", "EQ", bIsSelected));
			}
				
			oBindingParams.filters = aFilters;
		},

		onDataRecievedClassifCP: function(oEvent){
			var bMechError = this.getStateProperty("/showIncorrectEntries/classif");
			var bAssim = this.getStateProperty("/showIncorrectEntries/classifAssim");
			var bIsSelected = this.getStateProperty("/classif/showSelected");
			var aFilters = [];
			if (this.getStateProperty("/_GET").AppMode === "view") {
				aFilters = this._getAssimErrorRowFilters(bAssim, bMechError);
			}

			if (bIsSelected) {
				aFilters.push(new Filter("IsSelect", "EQ", bIsSelected));
			}	
			
			this.executeCountRequest("ClassifSmartTable", "toClassifiers", "", aFilters);
		},

		onShowSelectedEntries: function(oEvent) {
			this.getControlsByFieldGroupId("ClassifSmartTable")[0].rebindTable();
		},

		onSearchClassifHandler: function(oControlEvent) {
			var oSmartTable = this.getControlsByFieldGroupId("ClassifSmartTable")[0];
			var sValue = oControlEvent.getSource().getValue();
			var aFilters = [];
			if (this.getStateProperty("/_GET").AppMode === "view") {
				var oFilter = new sap.ui.model.Filter("IsSelect", sap.ui.model.FilterOperator.EQ, true);
				aFilters.push(oFilter);
			}

			if (sValue.trim() !== "") {
				oSmartTable.getTable().bindRows({
					path: this.getView().getBindingContext().getPath() + "/toClassifiers",
					filters: aFilters,
					parameters: {
						countMode: "Inline",
						operationMode: "Server",
						treeAnnotationProperties: {
							hierarchyLevelFor: 'HierarchyLevel',
							hierarchyNodeFor: 'NodeId',
							hierarchyParentNodeFor: 'ParentNodeId',
							hierarchyDrillStateFor: 'DrillState'
						},
						custom: {
							search: sValue.trim()
						}
					}
				});
			} else {
				oSmartTable.rebindTable(true);
			}
		},

		onCopyFromCP: function(oEvent) {
			if (this._oCopyFromCPDialog) {
				this._oCopyFromCPDialog.destroy();
			}
			this._oCopyFromCPDialog = new sap.ui.xmlfragment("ZO2C_COM_PROD.ZO2C_COM_PROD.view.dialogs.CopyFromCP", this);
			this.getView().addDependent(this._oCopyFromCPDialog);
			this._oCopyFromCPDialog.open();

			this.executeSimpleRefreshSmartTable("CommercProductSmartTable", "CommercProductVHSet");
		},

		onBeforeRebindCopyFromCPSmartTable: function(oControlEvent) {
			var oBinding = oControlEvent.getParameter("bindingParams");
			var oFilter = this.prepareCopyFromCPFilters();
			oBinding.filters.push(oFilter[0]);
		},

		onFilterApply: function(oEvent) {
			var oFilter = this.prepareCopyFromCPFilters();

			// update table binding
			var oFragmentSmartTable = this.getControlsByFieldGroupId("CommercProductSmartTable")[0];
			var oBinding = oFragmentSmartTable.getTable().getBinding("items");
			oBinding.filter(oFilter, "Application");
		},

		prepareCopyFromCPFilters: function() {
			var aFilters = [];
			if (this.getStateProperty("/copyFromCP").CodeCpH.trim() !== "") {
				aFilters.push(new Filter("CodeCpH", sap.ui.model.FilterOperator.Contains, this.getStateProperty("/copyFromCP").CodeCpH.trim()));
			}
			if (this.getStateProperty("/copyFromCP").ProdType !== "") {
				aFilters.push(new Filter("ProdType", sap.ui.model.FilterOperator.EQ, this.getStateProperty("/copyFromCP").ProdType));
			}
			if (this.getStateProperty("/copyFromCP").SteelMark !== "") {
				aFilters.push(new Filter("SteelMark", sap.ui.model.FilterOperator.EQ, this.getStateProperty("/copyFromCP").SteelMark));
			}
			if (this.getStateProperty("/copyFromCP").ProductStd !== "") {
				aFilters.push(new Filter("ProductStdCode", sap.ui.model.FilterOperator.EQ, this.getStateProperty("/copyFromCP").ProductStd));
			}
			if (this.getStateProperty("/copyFromCP").MarkStd !== "") {
				aFilters.push(new Filter("MarkStdCode", sap.ui.model.FilterOperator.EQ, this.getStateProperty("/copyFromCP").MarkStd));
			}
			if (this.getStateProperty("/copyFromCP").TolStd !== "") {
				aFilters.push(new Filter("TolStdCode", sap.ui.model.FilterOperator.EQ, this.getStateProperty("/copyFromCP").TolStd));
			}
			if (this.getStateProperty("/copyFromCP").HeightMin !== "") {
				aFilters.push(new Filter("HeightMin", sap.ui.model.FilterOperator.EQ, parseFloat(this.getStateProperty("/copyFromCP").HeightMin)));
			}
			if (this.getStateProperty("/copyFromCP").HeightMax !== "") {
				aFilters.push(new Filter("HeightMax", sap.ui.model.FilterOperator.EQ, parseFloat(this.getStateProperty("/copyFromCP").HeightMax)));
			}
			if (this.getStateProperty("/copyFromCP").WidthMin !== "") {
				aFilters.push(new Filter("WidthMin", sap.ui.model.FilterOperator.EQ, parseFloat(this.getStateProperty("/copyFromCP").WidthMin)));
			}
			if (this.getStateProperty("/copyFromCP").WidthMax !== "") {
				aFilters.push(new Filter("WidthMax", sap.ui.model.FilterOperator.EQ, parseFloat(this.getStateProperty("/copyFromCP").WidthMax)));
			}
			if (this.getStateProperty("/copyFromCP").LongMin !== "") {
				aFilters.push(new Filter("LongMin", sap.ui.model.FilterOperator.EQ, parseFloat(this.getStateProperty("/copyFromCP").LongMin)));
			}
			if (this.getStateProperty("/copyFromCP").LongMax !== "") {
				aFilters.push(new Filter("LongMax", sap.ui.model.FilterOperator.EQ, parseFloat(this.getStateProperty("/copyFromCP").LongMax)));
			}
			var oFilter = [new Filter(aFilters, true)];
			return oFilter;
		},

		copyFromCPDialogAccept: function() {
			var oSmartTable = this.getControlsByFieldGroupId("ClassifSmartTable")[0];
			var oFragmentSmartTable = this.getControlsByFieldGroupId("CommercProductSmartTable")[0];
			var oSelectedRow = oFragmentSmartTable.getTable().getSelectedItem();
			var oItem = oSelectedRow.getBindingContext().getObject();
			this.showBusy();
			this.getModel().callFunction("/CopyClassifFromCP", {
				method: "POST",
				urlParameters: {
					CodeCp: this.getStateProperty("/_GET").CodeCp,
					StatusCp: this.getStateProperty("/_GET").StatusCp,
					CodeCPList: oItem.CodeCp
				},
				success: function(oData, oMessage) {
					oSmartTable.getTable().getBinding("rows").refresh(true);
					this.hideBusy();
					this._oCopyFromCPDialog.close();
					MessageToast.show(this.getResourceBundle().getText("textCopyFromCPSuccess"));
				}.bind(this),
				error: function(oError) {
					this.hideBusy();
					this._oCopyFromCPDialog.close();
					MessageBox.error(this.parseRequestError(oError));
				}.bind(this)
			});
		},

		copyFromCPDialogClose: function(oControlEvent) {
			this._oCopyFromCPDialog.close();
		},

		onClearOldValues: function(oEvent) {
			for (var property in this.getStateProperty("/copyFromCP")) {
				if (this.getStateProperty("/copyFromCP").hasOwnProperty(property)) {
					if (property !== "") {
						this.getStateProperty("/copyFromCP")[property] = "";
					} else {
						this.getStateProperty("/copyFromCP")[property] = false;
					}
				}
			}
		},

		onAssimilatePressHandler: function (oControlEvent) {
			this._onAssimilateOnTablePress(oControlEvent, this.onDataChange.bind(this), false);
		},

		onErrorRowPressHandler: function (oControlEvent) {
			this._onErrorRowOnTablePress(oControlEvent, this.onDataChange.bind(this), false);
		},

		onDataChange: function(oControlEvent) {
			var oSmartTable = this.getControlsByFieldGroupId("ClassifSmartTable")[0];
			this.saveChanges(false, function() {
				oSmartTable.getTable().getBinding("rows").refresh(true);
			}.bind(this));
		}

	});

	$.extend(true, thisController.prototype);
	return thisController;
});
