sap.ui.define([
	"ZO2C_COM_PROD/ZO2C_COM_PROD/controller/BaseController",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/model/Filter"

], function(BaseController, MessageToast, MessageBox, Filter) {
	"use strict";

	const thisController = BaseController.extend("ZO2C_COM_PROD.ZO2C_COM_PROD.controller.tabs.DecorativeTape", {

		_customObjectDraftIndicator: null,
		_oAddDecorativeTapeItemFromTableDialog: null,
		_DecorativeTapeVBoxContent: null,
		_bFirstLoad: true, //TODO Заменить на свойство в модели

		onInit: function() {
			this._customObjectDraftIndicator = this.getStateProperty("/app").customObjectDraftIndicator;
			if (this.getStateProperty("/_GET").Tab === "DecorativeTape") {
				this.do(this.processLoad.bind(this), [true]);
			}
		},

		processLoad: function(bTabReload) {
			this.setStateProperty("/app/currentTabId", this.getView().getId());
			this.setStateProperty("/showIncorrectEntries/decorType", false);
			this.setStateProperty("/showIncorrectEntries/decorTypeAssim", false);

			this.addFragmentToDecorativeTape();

			if (!!this.getStateProperty("/app/currentView")) {
				this.hideBusy();
				this.setStateProperty("/app/refreshObject", true);
				if (bTabReload) {
					var oSmartTable = {};
					if (this.getStateProperty("/_GET/AppMode") === "search") {
						this.executeRefreshSmartTableViaFieldGroupIds("DecorativeTapeSearchSmartTable", "toDecorativeTape");
						oSmartTable = this.getControlsByFieldGroupId("DecorativeTapeSearchSmartTable")[0];
					} else {
						this.executeRefreshSmartTableViaFieldGroupIds("DecorativeTapeSmartTable", "toDecorativeTape");
						oSmartTable = this.getControlsByFieldGroupId("DecorativeTapeSmartTable")[0];
					}
					oSmartTable.getTable().clearSelection();
				}
				this.makeElementBinding(!bTabReload);
			} else {
				this.setStateProperty("/prevTabId", this.getPageController().getSelectedTabView().getId());
				this.doResolve();
			}
		},

		addFragmentToDecorativeTape: function() {
			const oDecorativeTapeVBox = this.getById("idDecorativeTapeVBox");

			this.destroyDecorativeTapeContent();

			if (!this._DecorativeTapeVBoxContent) {
				this._DecorativeTapeVBoxContent = new sap.ui.xmlfragment(
					this.createId(this.getStateProperty("/_GET").Tab),
					this._getFragmentPath(),
					this
				);
				this.getView().addDependent(this._DecorativeTapeVBoxContent);
			}

			oDecorativeTapeVBox.addItem(this._DecorativeTapeVBoxContent);
		},

		onInLinkSelectHandler: function(oControlEvent) {
			this.onInLinkSelectRelation(oControlEvent);
		},

		onRestrictionOnNullInput:function(oEvent){
			var oControl= oEvent.getSource();
			if(oControl.getValue()=="" && oControl.getType()=="Number"){
				oControl.setValue(0);
			}
		},

		destroyDecorativeTapeContent: function() {
			const oDecorativeTapeVBox = this.getById("idDecorativeTapeVBox");
			const aItems = oDecorativeTapeVBox.getItems();

			aItems.forEach(function(oItem) {
				oItem.destroy();
			});

			oDecorativeTapeVBox.removeAllItems();
			this._DecorativeTapeVBoxContent = null;
		},

		_getFragmentPath: function() {
			const sAppMode = this.getStateProperty("/_GET").AppMode;
			var sFragmentPath = "";

			if (sAppMode === "view" || sAppMode === "edit" || sAppMode === "create" || sAppMode === "relation") {
				sFragmentPath = "ZO2C_COM_PROD.ZO2C_COM_PROD.view.tabs.DecorativeTape.ViewEditCreate";
			} else if (sAppMode === "search") {
				sFragmentPath = "ZO2C_COM_PROD.ZO2C_COM_PROD.view.tabs.DecorativeTape.Search";
			}
			return sFragmentPath;
		},

		onBeforeRebindDecorativeTape: function(oControlEvent) {
			if (this.getStateProperty("/_GET").AppMode === "view") {
				var oBindingParams = oControlEvent.getParameter("bindingParams");
				var bMechError = this.getStateProperty("/showIncorrectEntries/decorType");
				var bAssim = this.getStateProperty("/showIncorrectEntries/decorTypeAssim");
				var aFilters = this._getAssimErrorRowFilters(bAssim, bMechError, oBindingParams.filters);
				oBindingParams.filters = aFilters;
			}
		},

		onDecorativeTapeFilterCheckBoxSelect: function() {
			var oSmartTable = {};
			if (this.getStateProperty("/_GET/AppMode") === "search") {
				oSmartTable = this.getControlsByFieldGroupId("DecorativeTapeSearchSmartTable")[0];
			} else {
				oSmartTable = this.getControlsByFieldGroupId("DecorativeTapeSmartTable")[0];
			}
			oSmartTable.rebindTable(true);
		},

		onAssimilatePressHandler: function (oControlEvent) {
			this._onAssimilateOnTablePress(oControlEvent);
		},

		onErrorRowPressHandler: function (oControlEvent) {
			this._onErrorRowOnTablePress(oControlEvent);
		},

		onAddFilterDecorativeTapeItem: function(oEvent) {
			this.addEmptyRecord(oEvent);
		},

		onAddDecorativeTapeItemFromTable: function(oEvent) {
			if (this._oAddDecorativeTapeItemFromTableDialog) {
				this._oAddDecorativeTapeItemFromTableDialog.destroy();
			}
			this._oAddDecorativeTapeItemFromTableDialog = new sap.ui.xmlfragment("ZO2C_COM_PROD.ZO2C_COM_PROD.view.dialogs.AddDecorativeTapeItemFromTable", this);
			this.getView().addDependent(this._oAddDecorativeTapeItemFromTableDialog);
			this._oAddDecorativeTapeItemFromTableDialog.open();

			this.executeSimpleRefreshSmartTable("AddDecorativeTapeItemSmartTable", "DecorEnamelVHSet");
		},

		onAddDecorativeTapeDialogSelectionChange: function(oEvent) {
			var oSmartTable = {};
			if (this.getStateProperty("/_GET/AppMode") === "search") {
				oSmartTable = this.getControlsByFieldGroupId("DecorativeTapeSearchSmartTable")[0];
			} else {
				oSmartTable = this.getControlsByFieldGroupId("DecorativeTapeSmartTable")[0];
			}
			var oAddDecorativeTapeItemSmartTable = this.getControlsByFieldGroupId("AddDecorativeTapeItemSmartTable")[0];
			var iIndex = oAddDecorativeTapeItemSmartTable.getTable().getSelectedIndex();
			var oItem = oAddDecorativeTapeItemSmartTable.getTable().getContextByIndex(iIndex).getObject();
			var oNewItem = {
				DecorEnamelRefId: oItem.DecorEnamelRefId
			};

			this.getModel().create("/" + this.createCurrentKey() + "/toDecorativeTape", oNewItem, {
				success: function(oResponse, oMessage) {
					oSmartTable.rebindTable();
					this.hideBusy();
					this._oAddDecorativeTapeItemFromTableDialog.close();
				}.bind(this),
				error: function(oError) {
					this.hideBusy();
					this._oAddDecorativeTapeItemFromTableDialog.close();
				}.bind(this)
			});
		},

		createEntry:function(oEvent){
			var oControl= oEvent.getSource()
			this.onAddSelectRowsToEntity(oEvent);
			switch(oControl.data("dialogName")){
				case'DecorativeTapeItem':
					this._oAddDecorativeTapeItemFromTableDialog.close();
					break;
			};
		},

		onAddDecorativeTapeDialogCancel: function(oEvent) {
			this._oAddDecorativeTapeItemFromTableDialog.close();
		},

		handleAddDecorativeTapeItemFromTableSearch: function(oEvent) {
			var oSmartTable = this.getControlsByFieldGroupId("AddDecorativeTapeItemSmartTable")[0];
			var sValue = oEvent.getSource().getValue();
			if (sValue.trim() !== "") {
				oSmartTable.getTable().bindRows({
					path: "/DecorEnamelVHSet",
					parameters: {
						countMode: "Inline",
						operationMode: "Server",
						custom: {
							search: sValue.trim()
						}
					}
				});
			} else {
				oSmartTable.rebindTable(true);
			}
		},

		onDeleteDecorativeTapeItem: function(oEvent) {
			var oSmartTable = {};
			if (this.getStateProperty("/_GET/AppMode") === "search") {
				oSmartTable = this.getControlsByFieldGroupId("DecorativeTapeSearchSmartTable")[0];
			} else {
				oSmartTable = this.getControlsByFieldGroupId("DecorativeTapeSmartTable")[0];
			}
			var aItems = oSmartTable.getTable().getSelectedIndices();
			var aPromises = [];
			if (aItems.length > 0) {
				aItems.forEach(function(oItem) {
					var sPath = oSmartTable.getTable().getContextByIndex(oItem).getPath();
					var oPromise = new Promise(function(resolve, reject) {
						this.getModel().remove(sPath, {
							success: function(oResponse, oMessage) {
								resolve();
							}.bind(this),
							error: function(oError) {
								reject(oError);
							}.bind(this)
						});
					}.bind(this));
					aPromises.push(oPromise);
				}.bind(this));

				Promise.all(aPromises).then(
					function(oData) {
						oSmartTable.getTable().getBinding("rows").refresh(true);
						oSmartTable.getTable().clearSelection();
						this.hideBusy();
					}.bind(this),
					function(oError) {
						this.hideBusy();
					}.bind(this)
				);
			} else {
				MessageBox.error(this.getResourceBundle().getText("textNoSelectedRecordsDelete"), {
					icon: MessageBox.Icon.ERROR,
					title: this.getResourceBundle().getText("titleError")
				});
				this.hideBusy();
			}
		}

	});

	$.extend(true, thisController.prototype);
	return thisController;
});
