sap.ui.define([
	"ZO2C_COM_PROD/ZO2C_COM_PROD/controller/BaseController",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/model/Filter"

], function(BaseController, MessageToast, MessageBox, Filter) {
	"use strict";

	const thisController = BaseController.extend("ZO2C_COM_PROD.ZO2C_COM_PROD.controller.tabs.Relation", {

		_oAddTechnicalItemFromTableDialog: null,
		_technicalVBoxContent: null,
		_bFirstLoad: true, //TODO Заменить на свойство в модели

		onInit: function() {
			if (this.getStateProperty("/_GET").Tab === "Relation") {
				this.do(this.processLoad.bind(this), [true]);
			}
		},

		processLoad: function(bTabReload) {
			this.setStateProperty("/app/currentTabId", this.getView().getId());
			this.setStateProperty("/showIncorrectEntries/relation", false);
			this.setStateProperty("/showIncorrectEntries/relationAssim", false);
			
			if (!!this.getStateProperty("/app/currentView")) {
				this.hideBusy();
				this.setStateProperty("/app/refreshObject", true);
				if (bTabReload) {
					this.executeRefreshSmartTableViaFieldGroupIds("RelationCPSmartTable", "toLinks");
				}
				this.makeElementBinding(!bTabReload);
			} else {
				this.setStateProperty("/prevTabId", this.getPageController().getSelectedTabView().getId());
				this.doResolve();
			}
		},

		onAssimilatePressHandler: function (oControlEvent) {
			this._onAssimilateOnTablePress(oControlEvent);
		},

		onErrorRowPressHandler: function (oControlEvent) {
			this._onErrorRowOnTablePress(oControlEvent);
		},

		onShowIncorrectEntries: function(oEvent) {
			if (this.getStateProperty("/_GET/AppMode") === "view") {
				this.getControlsByFieldGroupId("RelationCPSmartTable")[0].rebindTable();
			}
		},

		onBeforeRebindRelationComposition: function(oControlEvent) {
			if (this.getStateProperty("/_GET").AppMode === "view") {
				var oBindingParams = oControlEvent.getParameter("bindingParams");
				var bError = this.getStateProperty("/showIncorrectEntries/relation");
				var bAssim = this.getStateProperty("/showIncorrectEntries/relationAssim");
				var aFilters = this._getAssimErrorRowFilters(bAssim, bError, oBindingParams.filters);
				oBindingParams.filters = aFilters;
			}
		},

		deleteRelationHandler: function () {
			var oSmartTable = this.getControlsByFieldGroupId("RelationCPSmartTable")[0];
			var aItems = oSmartTable.getTable().getSelectedIndices();
			var aPromises = [];

			if (aItems.length > 0) {
				aItems.forEach(function(oItem) {
					var sPath = oSmartTable.getTable().getContextByIndex(oItem).getPath();
					var oPromise = new Promise(function(resolve, reject) {
						this.getModel().remove(sPath, {
							success: function(oResponse, oMessage) {
								resolve();
							}.bind(this),
							error: function(oError) {
								reject(oError);
							}.bind(this)
						});
					}.bind(this));
					aPromises.push(oPromise);
				}.bind(this));

				Promise.all(aPromises).then(
					function(oData) {
						oSmartTable.getTable().getBinding("rows").refresh(true);
						oSmartTable.getTable().clearSelection();
						this.hideBusy();
					}.bind(this),
					function(oError) {
						this.hideBusy();
					}.bind(this)
				);
			} else {
				MessageBox.error(this.getResourceBundle().getText("textNoSelectedRecordsDelete"), {
					icon: MessageBox.Icon.ERROR,
					title: this.getResourceBundle().getText("titleError")
				});
				this.hideBusy();
			}
		},

		onLinkNumHandler: function (oControlEvent) {
			var oLink = oControlEvent.getSource().getBindingContext().getObject();

			this.getRouter().navTo("link", {
				AppMode: "relation",
				CodeCp: oLink.CodeCp,
				StatusCp: oLink.StatusCp,
				Tab: "Technical",
				bChangeLog: false,
				LinkVariant: oLink.LinkVariant
			}, false);
		},

		createNewRelationHandler: function () {
			var mSettings = {
				success: function (oData) {
					if (!!oData) {
						this.getRouter().navTo("link", {
							AppMode: "relation",
							CodeCp: oData.CodeCp,
							StatusCp: oData.StatusCp,
							Tab: "Technical",
							bChangeLog: false,
							LinkVariant: oData.LinkVariant
						}, false);
					}
				}.bind(this),
 				error: function(oError) {
					this.hideBusy();
				}.bind(this),
				properties: {
					CodeCp:this.getStateProperty("/_GET").CodeCp,
					LinkVariant:"",
					StatusCp: this.getStateProperty("/_GET").StatusCp
				},
				preventRefreshAfterUpdate: true
			};

			this._createNewItem(this.createCurrentKey("/") + "/toLinks", mSettings);
		}

	});

	$.extend(true, thisController.prototype);
	return thisController;
});
