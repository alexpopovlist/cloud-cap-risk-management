sap.ui.define([
	"ZO2C_COM_PROD/ZO2C_COM_PROD/controller/BaseController",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/model/Filter"

], function(BaseController, MessageToast, MessageBox, Filter) {
	"use strict";

	const thisController = BaseController.extend("ZO2C_COM_PROD.ZO2C_COM_PROD.controller.tabs.Technical", {

		_oAddTechnicalItemFromTableDialog: null,
		_technicalVBoxContent: null,
		_bFirstLoad: true, //TODO Заменить на свойство в модели

		onInit: function() {
			if (this.getStateProperty("/_GET").Tab === "Technical") {
				this.do(this.processLoad.bind(this), [true]);
			}
		},

		processLoad: function(bTabReload) {
			this.setStateProperty("/app/currentTabId", this.getView().getId());
			this.setStateProperty("/showIncorrectEntries/technical", false);
			this.setStateProperty("/showIncorrectEntries/technicalAssim", false);

			this.addFragmentToTechnical();

			if (!!this.getStateProperty("/app/currentView")) {
				this.hideBusy();
				this.setStateProperty("/app/refreshObject", true);
				if (bTabReload) {
					var oSmartTable = {};
					if (this.getStateProperty("/_GET/AppMode") === "search") {
						this.executeRefreshSmartTableViaFieldGroupIds("TechnicalSearchCPSmartTable", "toTechnical");
						oSmartTable = this.getControlsByFieldGroupId("TechnicalSearchCPSmartTable")[0];
					} else {
						this.executeRefreshSmartTableViaFieldGroupIds("TechnicalCPSmartTable", "toTechnical");
						oSmartTable = this.getControlsByFieldGroupId("TechnicalCPSmartTable")[0];
					}
					oSmartTable.getTable().clearSelection();
				}
				this.makeElementBinding(!bTabReload);
			} else {
				this.setStateProperty("/prevTabId", this.getPageController().getSelectedTabView().getId());
				this.doResolve();
			}
		},

		addFragmentToTechnical: function() {
			const oTechVBox = this.getById("idTechnicalVBox");

			this.destroyTechnicalContent();

			if (!this._technicalVBoxContent) {
				this._technicalVBoxContent = new sap.ui.xmlfragment(
					this.createId(this.getStateProperty("/_GET").Tab),
					this._getFragmentPath(),
					this
				);
				this.getView().addDependent(this._technicalVBoxContent);
			}

			oTechVBox.addItem(this._technicalVBoxContent);
		},

		onInLinkSelectHandler: function(oControlEvent) {
			this.onInLinkSelectRelation(oControlEvent);
		},

		onAssimilatePressHandler: function (oControlEvent) {
			this._onAssimilateOnTablePress(oControlEvent);
		},

		onErrorRowPressHandler: function (oControlEvent) {
			this._onErrorRowOnTablePress(oControlEvent);
		},

		destroyTechnicalContent: function() {
			const oTechVBox = this.getById("idTechnicalVBox");
			const aItems = oTechVBox.getItems();

			aItems.forEach(function(oItem) {
				oItem.destroy();
			});

			oTechVBox.removeAllItems();
			this._technicalVBoxContent = null;
		},

		_getFragmentPath: function() {
			const sAppMode = this.getStateProperty("/_GET").AppMode;
			var sFragmentPath = "";

			if (sAppMode === "view" || sAppMode === "edit" || sAppMode === "create" || sAppMode === "relation") {
				sFragmentPath = "ZO2C_COM_PROD.ZO2C_COM_PROD.view.tabs.Technical.ViewEditCreate";
			} else if (sAppMode === "search") {
				sFragmentPath = "ZO2C_COM_PROD.ZO2C_COM_PROD.view.tabs.Technical.Search";
			}
			return sFragmentPath;
		},

		onBeforeRebindTechnicalCP: function(oControlEvent) {
			if (this.getStateProperty("/_GET").AppMode === "view") {
				var oBindingParams = oControlEvent.getParameter("bindingParams");		
				var bMechError = this.getStateProperty("/showIncorrectEntries/technical");
				var bAssim = this.getStateProperty("/showIncorrectEntries/technicalAssim");
				var aFilters = this._getAssimErrorRowFilters(bAssim, bMechError, oBindingParams.filters);
				oBindingParams.filters = aFilters;
			}
		},

		onShowIncorrectEntries: function(oEvent) {
			var oSmartTable = {};
			if (this.getStateProperty("/_GET/AppMode") === "search") {
				oSmartTable = this.getControlsByFieldGroupId("TechnicalSearchCPSmartTable")[0];
			} else {
				oSmartTable = this.getControlsByFieldGroupId("TechnicalCPSmartTable")[0];
			}
			oSmartTable.rebindTable();
		},

		onAddTechnicalItemFromTable: function(oEvent) {
			this.setStateProperty("/technical/NonStd", false);

			if (this._oAddTechnicalItemFromTableDialog) {
				this._oAddTechnicalItemFromTableDialog.destroy();
			}
			this._oAddTechnicalItemFromTableDialog = new sap.ui.xmlfragment("ZO2C_COM_PROD.ZO2C_COM_PROD.view.dialogs.AddTechnicalItemFromTable", this);
			this.getView().addDependent(this._oAddTechnicalItemFromTableDialog);
			this._oAddTechnicalItemFromTableDialog.open();
		},

		onBeforeAddTechnicalItemHandler: function (oControlEvent) {
			var oBindingParams = oControlEvent.getParameter("bindingParams");
			var bNonStd = this.getStateProperty("/technical/NonStd");
			oBindingParams.filters.push(new Filter("NonStd", "EQ", bNonStd));
		},

		onSelectAddTechnicalItemHandler: function (oControlEvent) {
			var oSmartTable = this.getControlsByFieldGroupId("AddTechnicalItemSmartTable")[0];
			oSmartTable.rebindTable();
		},

		onAddTechnicalDialogSelectionChange: function(oEvent) {
			var oSmartTable = {};
			if (this.getStateProperty("/_GET/AppMode") === "search") {
				oSmartTable = this.getControlsByFieldGroupId("TechnicalSearchCPSmartTable")[0];
			} else {
				oSmartTable = this.getControlsByFieldGroupId("TechnicalCPSmartTable")[0];
			}
			var oAddTechnicalItemSmartTable = this.getControlsByFieldGroupId("AddTechnicalItemSmartTable")[0];
			var iIndex = oAddTechnicalItemSmartTable.getTable().getSelectedIndex();
			var oItem = oAddTechnicalItemSmartTable.getTable().getContextByIndex(iIndex).getObject();
			var oNewItem = {
				TechValue: oItem.TechValue,
				GsCode:oItem.GsCode,
				GsCodeInterpr:oItem.GsCodeInterpr
			};

			this.getModel().create("/" + this.createCurrentKey() + "/toTechnical", oNewItem, {
				success: function(oResponse, oMessage) {
					oSmartTable.getTable().getBinding("rows").refresh(true);
					this.hideBusy();
					this._oAddTechnicalItemFromTableDialog.close();
				}.bind(this),
				error: function(oError) {
					this.hideBusy();
					this._oAddTechnicalItemFromTableDialog.close();
				}.bind(this)
			});
		},

		createEntry:function(oEvent){
			var oControl= oEvent.getSource()
			this.onAddSelectRowsToEntity(oEvent);
			switch(oControl.data("dialogName")){
				case'TechnicallItem':
					this._oAddTechnicalItemFromTableDialog.close();
					break;
			};
		},

		onRestrictionOnNullInput:function(oEvent){
			var oControl= oEvent.getSource();
			if(oControl.getValue()=="" && oControl.getType()=="Number"){
				oControl.setValue(0);
			}
		},

		onAddTechnicalDialogCancel: function(oEvent) {
			this._oAddTechnicalItemFromTableDialog.close();
		},

		handleAddTechnicalItemFromTableSearch: function(oEvent) {
			var oSmartTable = this.getControlsByFieldGroupId("AddTechnicalItemSmartTable")[0];
			var sValue = oEvent.getSource().getValue();
			if (sValue.trim() !== "") {
				oSmartTable.getTable().bindRows({
					path: "/TechValueVHSet",
					parameters: {
						countMode: "Inline",
						operationMode: "Server",
						custom: {
							search: sValue.trim()
						}
					}
				});
			} else {
				oSmartTable.rebindTable(true);
			}
		},

		onCopyTechnicalItem: function(oEvent) {
			this.showBusy();
			var oSmartTable = {};
			if (this.getStateProperty("/_GET/AppMode") === "search") {
				oSmartTable = this.getControlsByFieldGroupId("TechnicalSearchCPSmartTable")[0];
			} else {
				oSmartTable = this.getControlsByFieldGroupId("TechnicalCPSmartTable")[0];
			}
			var aItems = oSmartTable.getTable().getSelectedIndices();
			var aPromises = [];

			if (aItems.length > 0) {
				aItems.forEach(function(oItem) {
					var oTechItem = oSmartTable.getTable().getContextByIndex(oItem).getObject();
					var sFunctionImport = "";
					var oNewItem = {};
					if (this.getStateProperty("/_GET").AppMode === "search") {
						sFunctionImport = "CopyFilterTechnical";
						oNewItem = {
							Uuid: oTechItem.Uuid,
							RVariant: oTechItem.RVariant
						};
					} else {
						sFunctionImport = "CopyTechnicalCP";
						oNewItem = {
							StatusCp: oTechItem.StatusCp,
							CodeCp: oTechItem.CodeCp,
							RVariant: oTechItem.RVariant
						};
					}
					var oPromise = new Promise(function(resolve, reject) {
						this.getModel().callFunction("/" + sFunctionImport, {
							method: "POST",
							urlParameters: oNewItem,
							success: function(oResponse, oMessage) {
								resolve();
							}.bind(this),
							error: function(oError) {
								reject(oError);
							}.bind(this)
						});
					}.bind(this));
					aPromises.push(oPromise);
				}.bind(this));

				Promise.all(aPromises).then(
					function(oData) {
						oSmartTable.getTable().getBinding("rows").refresh(true);
						oSmartTable.getTable().clearSelection();
						this.hideBusy();
					}.bind(this),
					function(oError) {
						this.hideBusy();
					}.bind(this)
				);
			} else {
				MessageBox.error(this.getResourceBundle().getText("textNoSelectedRecordsCopy"), {
					icon: MessageBox.Icon.ERROR,
					title: this.getResourceBundle().getText("titleError")
				});
				this.hideBusy();
			}
		},

		onAddFilterTechnicalItem: function(oEvent) {
			this.addEmptyRecord(oEvent);
		},

		onDeleteTechnicalItem: function(oEvent) {
			var oSmartTable = {};
			if (this.getStateProperty("/_GET/AppMode") === "search") {
				oSmartTable = this.getControlsByFieldGroupId("TechnicalSearchCPSmartTable")[0];
			} else {
				oSmartTable = this.getControlsByFieldGroupId("TechnicalCPSmartTable")[0];
			}
			var aItems = oSmartTable.getTable().getSelectedIndices();
			var aPromises = [];

			if (aItems.length > 0) {
				aItems.forEach(function(oItem) {
					var sPath = oSmartTable.getTable().getContextByIndex(oItem).getPath();
					var oPromise = new Promise(function(resolve, reject) {
						this.getModel().remove(sPath, {
							success: function(oResponse, oMessage) {
								resolve();
							}.bind(this),
							error: function(oError) {
								reject(oError);
							}.bind(this)
						});
					}.bind(this));
					aPromises.push(oPromise);
				}.bind(this));

				Promise.all(aPromises).then(
					function(oData) {
						oSmartTable.getTable().getBinding("rows").refresh(true);
						oSmartTable.getTable().clearSelection();
						this.hideBusy();
					}.bind(this),
					function(oError) {
						this.hideBusy();
					}.bind(this)
				);
			} else {
				MessageBox.error(this.getResourceBundle().getText("textNoSelectedRecordsDelete"), {
					icon: MessageBox.Icon.ERROR,
					title: this.getResourceBundle().getText("titleError")
				});
				this.hideBusy();
			}
		},

		onTechValueChange: function(oEvent) {
			if (this.getStateProperty("/_GET/AppMode") === "search") {
				this.executeRefreshSmartTableViaFieldGroupIds("TechnicalSearchCPSmartTable", "toTechnical");
			} else {
				this.executeRefreshSmartTableViaFieldGroupIds("TechnicalCPSmartTable", "toTechnical");
			}
		},

	});

	$.extend(true, thisController.prototype);
	return thisController;
});
