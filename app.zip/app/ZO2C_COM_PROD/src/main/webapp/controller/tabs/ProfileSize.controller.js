sap.ui.define([
	"ZO2C_COM_PROD/ZO2C_COM_PROD/controller/BaseController",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/model/Filter"

], function(BaseController, MessageToast, MessageBox, Filter) {
	"use strict";

	const thisController = BaseController.extend("ZO2C_COM_PROD.ZO2C_COM_PROD.controller.tabs.ProfileSize", {

		_customObjectDraftIndicator: null,
		_oProfileSelectedRow: null,
		_oAddProfileItemFromTableDialog: null,
		_oAddProfileSizeItemFromTableDialog: null,
		_ProfileSizeVBoxContent: null,
		_bFirstLoad: true, //TODO Заменить на свойство в модели

		onInit: function() {
			this._customObjectDraftIndicator = this.getStateProperty("/app").customObjectDraftIndicator;
			if (this.getStateProperty("/_GET").Tab === "ProfileSize") {
				this.do(this.processLoad.bind(this), [true]);
			}
		},

		processLoad: function(bTabReload) {

			this.setStateProperty("/app/currentTabId", this.getView().getId());
			this.setStateProperty("/showIncorrectEntries/checkBoxProfileErrorRow", true);
			this.setStateProperty("/showIncorrectEntries/checkBoxProfileAssimilate", true);
			this.setStateProperty("/showIncorrectEntries/checkBoxProfileSizeErrorRow", false);
			this.setStateProperty("/showIncorrectEntries/checkBoxProfileSizeAssimilate", false);

			this.addFragmentToProfileSize();

			if (!!this.getStateProperty("/app/currentView")) {
				this.hideBusy();
				this.setStateProperty("/app/refreshObject", true);
				if (bTabReload) {
					var oSmartTable = {};
					if (this.getStateProperty("/_GET/AppMode") === "search") {
						this.setStateProperty("/tabProfileSize/selectedProfileId", null);
						this.setStateProperty("/tabProfileSize/selectedBindingPath", "");
				
						this.executeRefreshSmartTableViaFieldGroupIds("ProfileSearchSmartTable", "toProfile");
						oSmartTable = this.getControlsByFieldGroupId("ProfileSearchSmartTable")[0];
					} else if (this.getStateProperty("/_GET/AppMode") === "relation") {
						this.setStateProperty("/tabProfileSize/selectedProfileId", null);
						this.setStateProperty("/tabProfileSize/selectedBindingPath", "");
				
						this.executeRefreshSmartTableViaFieldGroupIds("ProfileSizeSmartTable", "toProfileSize");
						oSmartTable = this.getControlsByFieldGroupId("ProfileSizeSmartTable")[0];
					} else {
						this.setStateProperty("/tabProfileSize/selectedProfileId", null);
						this.setStateProperty("/tabProfileSize/selectedBindingPath", "");
				
						this.executeRefreshSmartTableViaFieldGroupIds("ProfileSmartTable", "toProfile");
						oSmartTable = this.getControlsByFieldGroupId("ProfileSmartTable")[0];
					}
					oSmartTable.getTable().removeSelections();
				}
				this.makeElementBinding(!bTabReload);
			} else {
				this.setStateProperty("/prevTabId", this.getPageController().getSelectedTabView().getId());
				this.doResolve();
			}
		},

		addFragmentToProfileSize: function() {
			const oProfileSizeVBox = this.getById("idProfileSizeVBox");

			if (!this._ProfileSizeVBoxContent) {
				this._ProfileSizeVBoxContent = new sap.ui.xmlfragment(
					this.createId(this.getStateProperty("/_GET").Tab),
					this._getFragmentPath(),
					this
				);
				this.getView().addDependent(this._ProfileSizeVBoxContent);
				oProfileSizeVBox.addItem(this._ProfileSizeVBoxContent);
			}
			this.getModel().refresh();
			oProfileSizeVBox.updateBindings();
			oProfileSizeVBox.rerender();
		},

		onInLinkSelectHandler: function(oControlEvent) {
			this.onInLinkSelectRelation(oControlEvent);
		},

		destroyProfileSizeContent: function() {
			const oProfileSizeVBox = this.getById("idProfileSizeVBox");
			const aItems = oProfileSizeVBox.getItems();

			aItems.forEach(function(oItem) {
				oItem.destroy();
			});

			oProfileSizeVBox.removeAllItems();
			this._ProfileSizeVBoxContent = null;
		},

		_getFragmentPath: function() {
			const sAppMode = this.getStateProperty("/_GET").AppMode;
			var sFragmentPath = "";

			if (sAppMode === "view" || sAppMode === "edit" || sAppMode === "create" || sAppMode === "relation") {
				sFragmentPath = "ZO2C_COM_PROD.ZO2C_COM_PROD.view.tabs.ProfileSize.ViewEditCreate";
			} else if (sAppMode === "search") {
				sFragmentPath = "ZO2C_COM_PROD.ZO2C_COM_PROD.view.tabs.ProfileSize.Search";
			}
			return sFragmentPath;
		},

		onBeforeRebindProfileCP: function(oEvent) {
			if (this.getStateProperty("/_GET").AppMode !== "search") {
				var oBindingParams = oEvent.getParameter("bindingParams");
				var aFilters = [];
				var bErrorRow = this.getStateProperty("/showIncorrectEntries/checkBoxProfileErrorRow");
				var bAssimilate = this.getStateProperty("/showIncorrectEntries/checkBoxProfileAssimilate");
			
				if (this.getStateProperty("/_GET").AppMode !== "search") {
					aFilters = this._getAssimErrorRowFilters(bAssimilate, bErrorRow);
				}
				oBindingParams.filters = aFilters;
			}
		},

		onBeforeRebindProfileSizeCP: function(oEvent) {
			if (this.getStateProperty("/_GET").AppMode !== "search") {
				var oBindingParams = oEvent.getParameter("bindingParams");
				var aFilters = [];
				var bErrorRow = this.getStateProperty("/showIncorrectEntries/checkBoxProfileSizeErrorRow");
				var bAssimilate = this.getStateProperty("/showIncorrectEntries/checkBoxProfileSizeAssimilate");
				
				if (this.getStateProperty("/_GET").AppMode !== "search") {
					aFilters = this._getAssimErrorRowFilters(bAssimilate, bErrorRow);
				}
				if (this.getStateProperty("/_GET").AppMode !== "relation") {
					var oFilterProfileId = new Filter("ProfileId", "EQ", this.getStateProperty("/tabProfileSize/selectedProfileId"));
					aFilters.push(oFilterProfileId);
				}
				oBindingParams.filters.push(new Filter(aFilters, true));
			}
		},

		onProfileFilterCheckBoxSelect: function(oEvent) {
			var oSmartTable = {};
			if (this.getStateProperty("/_GET/AppMode") === "search") {
				oSmartTable = this.getControlsByFieldGroupId("ProfileSearchSmartTable")[0];
			} else {
				oSmartTable = this.getControlsByFieldGroupId("ProfileSmartTable")[0];
			}
			oSmartTable.rebindTable();
		},

		onProfileSizeFilterCheckBoxSelect: function(oEvent) {
			var oSmartTable = {};
			if (this.getStateProperty("/_GET/AppMode") === "search") {
				oSmartTable = this.getControlsByFieldGroupId("ProfileSizeSearchSmartTable")[0];
			} else {
				oSmartTable = this.getControlsByFieldGroupId("ProfileSizeSmartTable")[0];
			}
			oSmartTable.rebindTable();
		},

		onProfileTableCheckBoxSelect: function(oEvent) {
			var oSource = oEvent.getSource();
			
			if (oSource.data('checkBox') === "Assimilate") {
				this._onAssimilateOnTablePress(oEvent, this._onProfileTableSuccess.bind(this));
			} else if (oSource.data('checkBox') === "ErrorRow"){
				this._onErrorRowOnTablePress(oEvent, this._onProfileTableSuccess.bind(this));
			} 
		},

		_onProfileTableSuccess: function() {			
			var oSmartTable = {};
				if (this.getStateProperty("/_GET/AppMode") === "search") {
					oSmartTable = this.getControlsByFieldGroupId("ProfileSearchSmartTable")[0];
				} else {
					oSmartTable = this.getControlsByFieldGroupId("ProfileSmartTable")[0];
				}
			oSmartTable.rebindTable();
		},

		onProfileSizeTableCheckBoxSelect: function(oEvent) {
			var oSource = oEvent.getSource();
			
			if (oSource.data('checkBox') === "Assimilate") {
				this._onAssimilateOnTablePress(oEvent, this._onProfileSizeTableSuccess.bind(this));
			} else if (oSource.data('checkBox') === "ErrorRow"){
				this._onErrorRowOnTablePress(oEvent, this._onProfileSizeTableSuccess.bind(this));
			}
		},

		_onProfileSizeTableSuccess: function(oEvent) {
			var oSmartTable = {};
				if (this.getStateProperty("/_GET/AppMode") === "search") {
					oSmartTable = this.getControlsByFieldGroupId("ProfileSizeSearchSmartTable")[0];
				} else {
					oSmartTable = this.getControlsByFieldGroupId("ProfileSizeSmartTable")[0];
				}
			oSmartTable.rebindTable();
		},

		onAddProfileItemFromTable: function(oEvent) {
			if (this._oAddProfileItemFromTableDialog) {
				this._oAddProfileItemFromTableDialog.destroy();
			}
			this._oAddProfileItemFromTableDialog = new sap.ui.xmlfragment("ZO2C_COM_PROD.ZO2C_COM_PROD.view.dialogs.AddProfileItemFromTable", this);
			this.getView().addDependent(this._oAddProfileItemFromTableDialog);
			this._oAddProfileItemFromTableDialog.open();
		},

		createEntry: function(oEvent){
			var oControl= oEvent.getSource()
			this.onAddSelectRowsToEntityPromise(oEvent);
			switch(oControl.data("dialogName")){
				case'ProfileItem':
					this._oAddProfileItemFromTableDialog.close();
					break;
				case'ProfileSizeItem':
					this._oAddProfileSizeItemFromTableDialog.close();
					break;
			};
		},

		onRestrictionOnNullInput:function(oEvent){
			var oControl= oEvent.getSource();
			if(oControl.getValue()=="" && oControl.getType()=="Number"){
				oControl.setValue(0);
			}
		},

		onAddProfileDialogCancel: function(oEvent) {
			this._oAddProfileItemFromTableDialog.close();
		},

		handleAddProfileItemFromTableSearch: function(oEvent) {
			var oSmartTable = this.getControlsByFieldGroupId("AddProfileItemSmartTable")[0];
			var sValue = oEvent.getSource().getValue();
			if (sValue.trim() !== "") {
				oSmartTable.getTable().bindRows({
					path: "/ProfileVHSet",
					parameters: {
						countMode: "Inline",
						operationMode: "Server",
						custom: {
							search: sValue.trim()
						}
					}
				});
			} else {
				oSmartTable.rebindTable();
			}
		},

		onDeleteProfileItem: function(oEvent) {
			var bCheck = false;
			var oSmartTable = {};
			var oSmartTableProfileSize = {};
			if (this.getStateProperty("/_GET/AppMode") === "search") {
				oSmartTable = this.getControlsByFieldGroupId("ProfileSearchSmartTable")[0];
				oSmartTableProfileSize = this.getControlsByFieldGroupId("ProfileSizeSearchSmartTable")[0];
			} else {
				oSmartTable = this.getControlsByFieldGroupId("ProfileSmartTable")[0];
				oSmartTableProfileSize = this.getControlsByFieldGroupId("ProfileSizeSmartTable")[0];
			}
			var aItems = oSmartTable.getTable().getSelectedItems();
			var aPromises = [];
			if (aItems.length > 0) {
				aItems.forEach(function(oItem) {
					if (oItem === this._oProfileSelectedRow) {
						bCheck = true;
					}
					var sPath = oItem.getBindingContext().getPath();
					var oPromise = new Promise(function(resolve, reject) {
						this.getModel().remove(sPath, {
							success: function(oResponse, oMessage) {
								resolve();
							}.bind(this),
							error: function(oError) {
								reject(oError);
							}.bind(this)
						});
					}.bind(this));
					aPromises.push(oPromise);
				}.bind(this));

				Promise.all(aPromises).then(
					function(oData) {
						oSmartTable.getTable().getBinding("items").refresh(true);
						oSmartTable.getTable().removeSelections();
						this.hideBusy();

						if (bCheck) {
							this.setStateProperty("/tabProfileSize/selectedProfileId", null);
							this.setStateProperty("/tabProfileSize/selectedBindingPath", "");
				
							oSmartTableProfileSize.rebindTable();
						}
					}.bind(this),
					function(oError) {
						this.hideBusy();
					}.bind(this)
				);
			} else {
				MessageBox.error(this.getResourceBundle().getText("textNoSelectedRecordsDelete"), {
					icon: MessageBox.Icon.ERROR,
					title: this.getResourceBundle().getText("titleError")
				});
				this.hideBusy();
			}
		},

		onAddProfileSizeItemFromTable: function(oEvent) {
			var sCurrentProfilePath = this.getStateProperty("/tabProfileSize/selectedBindingPath").replace("/","") + "/toProfileSizeVH";

			if (this._oAddProfileSizeItemFromTableDialog) {
				this._oAddProfileSizeItemFromTableDialog.destroy();
			}
			this._oAddProfileSizeItemFromTableDialog = new sap.ui.xmlfragment("ZO2C_COM_PROD.ZO2C_COM_PROD.view.dialogs.AddProfileSizeItemFromTable", this);
			this.getView().addDependent(this._oAddProfileSizeItemFromTableDialog);
			this._oAddProfileSizeItemFromTableDialog.open();
			this.executeSimpleRefreshSmartTable("AddProfileSizeItemSmartTable", sCurrentProfilePath);
		},

		onBeforeRebindAddProfileSize: function(oEvent) {
			var oBindingParams = oEvent.getParameter("bindingParams");
			var oFilter = new sap.ui.model.Filter("ProfileId", "EQ", this.getStateProperty("/tabProfileSize/selectedProfileId"));
			oBindingParams.filters.push(oFilter);
		},

		onAddProfileSizeDialogSelectionChange: function(oEvent) {
			var oSmartTable = {};
			if (this.getStateProperty("/_GET/AppMode") === "search") {
				oSmartTable = this.getControlsByFieldGroupId("ProfileSizeSearchSmartTable")[0];
			} else {
				oSmartTable = this.getControlsByFieldGroupId("ProfileSizeSmartTable")[0];
			}
			var oAddProfileSizeItemSmartTable = this.getControlsByFieldGroupId("AddProfileSizeItemSmartTable")[0];
			var iIndex = oAddProfileSizeItemSmartTable.getTable().getSelectedIndex();
			var oItem = oAddProfileSizeItemSmartTable.getTable().getContextByIndex(iIndex).getObject();
			var oNewItem = {
				ProfileSizeId: oItem.ProfileSizeId,
				ProfileSizeName: oItem.ProfileSizeName,
				ProfileId: oItem.ProfileId
			};

			this.getModel().create("/" + this.createCurrentKey() + "/toProfileSize", oNewItem, {
				success: function(oResponse, oMessage) {
					oSmartTable.getTable().getBinding("items").refresh(true);
					this.hideBusy();
					this._oAddProfileSizeItemFromTableDialog.close();
				}.bind(this),
				error: function(oError) {
					this.hideBusy();
					this._oAddProfileSizeItemFromTableDialog.close();
				}.bind(this)
			});
		},

		onAddProfileSizeDialogCancel: function(oEvent) {
			this._oAddProfileSizeItemFromTableDialog.close();
		},

		handleAddProfileSizeItemFromTableSearch: function(oEvent) {
			var oSmartTable = this.getControlsByFieldGroupId("AddProfileSizeItemSmartTable")[0];
			var sValue = oEvent.getSource().getValue();
			if (sValue.trim() !== "") {
				oSmartTable.getTable().bindRows({
					path: "/ProfileSizeVHSet",
					filters: [new sap.ui.model.Filter("ProfileId", "EQ", this.getStateProperty("/tabProfileSize/selectedProfileId"))],
					parameters: {
						countMode: "Inline",
						operationMode: "Server",
						custom: {
							search: sValue.trim()
						}
					}
				});
			} else {
				oSmartTable.rebindTable();
			}
		},

		onDeleteProfileSizeItem: function(oEvent) {
			var oSmartTable = {};
			if (this.getStateProperty("/_GET/AppMode") === "search") {
				oSmartTable = this.getControlsByFieldGroupId("ProfileSizeSearchSmartTable")[0];
			} else {
				oSmartTable = this.getControlsByFieldGroupId("ProfileSizeSmartTable")[0];
			}
			var aItems = oSmartTable.getTable().getSelectedItems();
			var aPromises = [];
			if (aItems.length > 0) {
				aItems.forEach(function(oItem) {
					var sPath = oItem.getBindingContext().getPath();
					var oPromise = new Promise(function(resolve, reject) {
						this.getModel().remove(sPath, {
							success: function(oResponse, oMessage) {
								resolve();
							}.bind(this),
							error: function(oError) {
								reject(oError);
							}.bind(this)
						});
					}.bind(this));
					aPromises.push(oPromise);
				}.bind(this));

				Promise.all(aPromises).then(
					function(oData) {
						oSmartTable.getTable().getBinding("items").refresh(true);
						oSmartTable.getTable().removeSelections();
						this.hideBusy();
					}.bind(this),
					function(oError) {
						this.hideBusy();
					}.bind(this)
				);
			} else {
				MessageBox.error(this.getResourceBundle().getText("textNoSelectedRecordsDelete"), {
					icon: MessageBox.Icon.ERROR,
					title: this.getResourceBundle().getText("titleError")
				});
				this.hideBusy();
			}
		},

		onProfileListItemPress: function(oEvent) {
			var oSelectedItem = oEvent.getParameter("listItem");
			var oProfileTable = oEvent.getSource();
			var aItems = oProfileTable.getItems();
			this._oProfileSelectedRow = oSelectedItem;

			$.each(aItems, function(i, oItem) {
				oItem.removeAllCustomData();
			});

			oSelectedItem.addCustomData(new sap.ui.core.CustomData({
					key: "current",
					value: "use",
					writeToDom: true
				})
			);

			var oSelectedProfile = oSelectedItem.getBindingContext().getObject();
			var sSelectedProfileId = oSelectedProfile.ProfileId;
			var oSmartTable = {};
			if (!!this.getStateProperty("/tabProfileSize/selectedProfileId")) {
				this.setStateProperty("/tabProfileSize/selectedProfileId", sSelectedProfileId);
				this.setStateProperty("/tabProfileSize/selectedBindingPath", oSelectedItem.getBindingContext().getPath());
				
				if (this.getStateProperty("/_GET/AppMode") === "search") {
					oSmartTable = this.getControlsByFieldGroupId("ProfileSizeSearchSmartTable")[0];
				} else {
					oSmartTable = this.getControlsByFieldGroupId("ProfileSizeSmartTable")[0];
				}
				oSmartTable.rebindTable();
			} else {
				this.setStateProperty("/tabProfileSize/selectedProfileId", sSelectedProfileId);
				this.setStateProperty("/tabProfileSize/selectedBindingPath", oSelectedItem.getBindingContext().getPath());
				
				if (this.getStateProperty("/_GET/AppMode") === "search") {
					this.executeRefreshSmartTableViaFieldGroupIds("ProfileSizeSearchSmartTable", "toProfileSize");
					oSmartTable = this.getControlsByFieldGroupId("ProfileSizeSearchSmartTable")[0];
				} else {
					this.executeRefreshSmartTableViaFieldGroupIds("ProfileSizeSmartTable", "toProfileSize");
					oSmartTable = this.getControlsByFieldGroupId("ProfileSizeSmartTable")[0];
				}
				oSmartTable.rebindTable();
				oSmartTable.getTable().removeSelections();
			}
		}

	});

	$.extend(true, thisController.prototype);
	return thisController;
});
