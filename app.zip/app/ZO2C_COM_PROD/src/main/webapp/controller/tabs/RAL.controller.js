sap.ui.define([
	"ZO2C_COM_PROD/ZO2C_COM_PROD/controller/BaseController",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/model/Filter"

], function(BaseController, MessageToast, MessageBox, Filter) {
	"use strict";

	const thisController = BaseController.extend("ZO2C_COM_PROD.ZO2C_COM_PROD.controller.tabs.RAL", {

		_customObjectDraftIndicator: null,
		_oRALFaceSelectedRow: null,
		_oAddRALFaceItemFromTableDialog: null,
		_oAddRALBackItemFromTableDialog: null,
		_RALVBoxContent: null,
		_bFirstLoad: true, //TODO Заменить на свойство в модели

		onInit: function() {
			this._customObjectDraftIndicator = this.getStateProperty("/app").customObjectDraftIndicator;
			if (this.getStateProperty("/_GET").Tab === "RAL") {
				this.do(this.processLoad.bind(this), [true]);
			}
		},

		processLoad: function(bTabReload) {

			this.setStateProperty("/app/currentTabId", this.getView().getId());
			this.setStateProperty("/showIncorrectEntries/checkBoxRALBackErrorRow", false);
			this.setStateProperty("/showIncorrectEntries/checkBoxRALBackAssimilate", false);
			this.setStateProperty("/showIncorrectEntries/checkBoxRALFaceErrorRow", false);
			this.setStateProperty("/showIncorrectEntries/checkBoxRALFaceAssimilate", false);
			
					

			this.addFragmentToRAL();

			if (!!this.getStateProperty("/app/currentView")) {
				this.hideBusy();
				this.setStateProperty("/app/refreshObject", true);
				if (bTabReload) {
					var oSmartTable = {};
					if (this.getStateProperty("/_GET/AppMode") === "search") {
						this.setStateProperty("/tabRAL/selectedRALFaceId", null);
						this.executeRefreshSmartTableViaFieldGroupIds("RALFaceSearchSmartTable", "toRALFace");
						oSmartTable = this.getControlsByFieldGroupId("RALFaceSearchSmartTable")[0];
					} else {
						this.setStateProperty("/tabRAL/selectedRALFaceId", null);
						this.executeRefreshSmartTableViaFieldGroupIds("RALFaceSmartTable", "toRALFace");
						oSmartTable = this.getControlsByFieldGroupId("RALFaceSmartTable")[0];
					}
					oSmartTable.getTable().removeSelections();
				}
				this.makeElementBinding(!bTabReload);
			} else {
				this.setStateProperty("/prevTabId", this.getPageController().getSelectedTabView().getId());
				this.doResolve();
			}
		},

		addFragmentToRAL: function() {
			const oRALVBox = this.getById("idRALVBox");

			this.destroyRALContent();

			if (!this._RALVBoxContent) {
				this._RALVBoxContent = new sap.ui.xmlfragment(
					this.createId(this.getStateProperty("/_GET").Tab),
					this._getFragmentPath(),
					this
				);
				this.getView().addDependent(this._RALVBoxContent);
			}

			oRALVBox.addItem(this._RALVBoxContent);
		},

		onInLinkSelectHandler: function(oControlEvent) {
			this.onInLinkSelectRelation(oControlEvent);
		},

		destroyRALContent: function() {
			const oRALVBox = this.getById("idRALVBox");
			const aItems = oRALVBox.getItems();

			aItems.forEach(function(oItem) {
				oItem.destroy();
			});

			oRALVBox.removeAllItems();
			this._RALVBoxContent = null;
		},

		_getFragmentPath: function() {
			const sAppMode = this.getStateProperty("/_GET").AppMode;
			var sFragmentPath = "";

			if (sAppMode === "view" || sAppMode === "edit" || sAppMode === "create" || sAppMode === "relation") {
				sFragmentPath = "ZO2C_COM_PROD.ZO2C_COM_PROD.view.tabs.RAL.ViewEditCreate";
			} else if (sAppMode === "search") {
				sFragmentPath = "ZO2C_COM_PROD.ZO2C_COM_PROD.view.tabs.RAL.Search";
			}
			return sFragmentPath;
		},

		onBeforeRebindRALFace: function(oEvent) {
			if (this.getStateProperty("/_GET").AppMode !== "search") {
				var oBindingParams = oEvent.getParameter("bindingParams");
				var aFilters = [];
				var bErrorRow = this.getStateProperty("/showIncorrectEntries/checkBoxRALFaceErrorRow");
				var bAssimilate = this.getStateProperty("/showIncorrectEntries/checkBoxRALFaceAssimilate");
			
				if (this.getStateProperty("/_GET").AppMode !== "search") {
					aFilters = this._getAssimErrorRowFilters(bAssimilate, bErrorRow);
				}
				oBindingParams.filters = aFilters;
			}
		},

		onBeforeRebindRALBack: function(oEvent) {
			if (this.getStateProperty("/_GET").AppMode !== "search") {
				var oBindingParams = oEvent.getParameter("bindingParams");
				var aFilters = [];
				var bErrorRow = this.getStateProperty("/showIncorrectEntries/checkBoxRALBackErrorRow");
				var bAssimilate = this.getStateProperty("/showIncorrectEntries/checkBoxRALBackAssimilate");
				
				if (this.getStateProperty("/_GET").AppMode !== "search") {
					aFilters = this._getAssimErrorRowFilters(bAssimilate, bErrorRow);
				}
				if (this.getStateProperty("/_GET").AppMode !== "relation") {
					var oFaceRVariantId = new Filter("FaceRVariant", "EQ", this.getStateProperty("/tabRAL/selectedRALFaceId"));
					aFilters.push(oFaceRVariantId);
				}
				oBindingParams.filters.push(new Filter(aFilters, true));
			}
		},

		onRALFaceFilterCheckBoxSelect: function(oEvent) {
			var oSmartTable = {};
			if (this.getStateProperty("/_GET/AppMode") === "search") {
				oSmartTable = this.getControlsByFieldGroupId("RALFaceSearchSmartTable")[0];
			} else {
				oSmartTable = this.getControlsByFieldGroupId("RALFaceSmartTable")[0];
			}
			oSmartTable.rebindTable();
		},

		onRALBackFilterCheckBoxSelect: function(oEvent) {
			var oSmartTable = {};
			if (this.getStateProperty("/_GET/AppMode") === "search") {
				oSmartTable = this.getControlsByFieldGroupId("RALBackSearchSmartTable")[0];
			} else {
				oSmartTable = this.getControlsByFieldGroupId("RALBackSmartTable")[0];
			}
			oSmartTable.rebindTable();
		},

		onRALFaceTableCheckBoxSelect: function(oEvent) {
			var oSource = oEvent.getSource();
			
			if (oSource.data('checkBox') === "Assimilate") {
				this._onAssimilateOnTablePress(oEvent, this._onRALFaceTableCheckBoxSelectSuccess.bind(this));
			} else if (oSource.data('checkBox') === "ErrorRow"){
				this._onErrorRowOnTablePress(oEvent, this._onRALFaceTableCheckBoxSelectSuccess.bind(this));
			} 
		},

		_onRALFaceTableCheckBoxSelectSuccess: function() {			
			var oSmartTable = {};
				if (this.getStateProperty("/_GET/AppMode") === "search") {
					oSmartTable = this.getControlsByFieldGroupId("RALFaceSearchSmartTable")[0];
				} else {
					oSmartTable = this.getControlsByFieldGroupId("RALFaceSmartTable")[0];
				}
			oSmartTable.rebindTable();
		},

		onRALBackTableCheckBoxSelect: function(oEvent) {
			var oSource = oEvent.getSource();
			
			if (oSource.data('checkBox') === "Assimilate") {
				this._onAssimilateOnTablePress(oEvent, this._onRALBackTableCheckBoxSelectSuccess.bind(this));
			} else if (oSource.data('checkBox') === "ErrorRow"){
				this._onErrorRowOnTablePress(oEvent, this._onRALBackTableCheckBoxSelectSuccess.bind(this));
			} 
		},

		_onRALBackTableCheckBoxSelectSuccess: function() {			
			var oSmartTable = {};
				if (this.getStateProperty("/_GET/AppMode") === "search") {
					oSmartTable = this.getControlsByFieldGroupId("RALBackSearchSmartTable")[0];
				} else {
					oSmartTable = this.getControlsByFieldGroupId("RALBackSmartTable")[0];
				}
			oSmartTable.rebindTable();
		},

		onAddRALFaceItemFromTable: function(oEvent) {
			if (this._oAddRALFaceItemFromTableDialog) {
				this._oAddRALFaceItemFromTableDialog.destroy();
			}
			this._oAddRALFaceItemFromTableDialog = new sap.ui.xmlfragment("ZO2C_COM_PROD.ZO2C_COM_PROD.view.dialogs.AddRALFaceItemFromTable", this);
			this.getView().addDependent(this._oAddRALFaceItemFromTableDialog);
			this._oAddRALFaceItemFromTableDialog.open();

			this.executeSimpleRefreshSmartTable("AddRALFaceItemSmartTable", "ColorVHSet");
		},

		onAddRALFaceDialogSelectionChange: function(oEvent) {
			var oSmartTable = {};
			if (this.getStateProperty("/_GET/AppMode") === "search") {
				oSmartTable = this.getControlsByFieldGroupId("RALFaceSearchSmartTable")[0];
			} else {
				oSmartTable = this.getControlsByFieldGroupId("RALFaceSmartTable")[0];
			}
			var oAddRALFaceItemSmartTable = this.getControlsByFieldGroupId("AddRALFaceItemSmartTable")[0];
			var iIndex = oAddRALFaceItemSmartTable.getTable().getSelectedIndex();
			var oItem = oAddRALFaceItemSmartTable.getTable().getContextByIndex(iIndex).getObject();
			var oNewItem = {
				ColorId: oItem.ColorId
			};

			this.getModel().create("/" + this.createCurrentKey() + "/toRALFace", oNewItem, {
				success: function(oResponse, oMessage) {
					oSmartTable.getTable().getBinding("items").refresh(true);
					this.hideBusy();
					this._oAddRALFaceItemFromTableDialog.close();
				}.bind(this),
				error: function(oError) {
					this.hideBusy();
					this._oAddRALFaceItemFromTableDialog.close();
				}.bind(this)
			});
		},

		createEntry:function(oEvent){
			var oControl= oEvent.getSource()
			this.onAddSelectRowsToEntityPromise(oEvent);
			switch(oControl.data("dialogName")){
				case'FaceItem':
					this._oAddRALFaceItemFromTableDialog.close();
					break;
				case'BackItem':
					this._oAddRALBackItemFromTableDialog.close();
					break;
			};
		},

		onAddRALFaceDialogCancel: function(oEvent) {
			this._oAddRALFaceItemFromTableDialog.close();
		},

		handleAddRALFaceItemFromTableSearch: function(oEvent) {
			var oSmartTable = this.getControlsByFieldGroupId("AddRALFaceItemSmartTable")[0];
			var sValue = oEvent.getSource().getValue();
			if (sValue.trim() !== "") {
				oSmartTable.getTable().bindRows({
					path: "/ColorVHSet",
					parameters: {
						countMode: "Inline",
						operationMode: "Server",
						custom: {
							search: sValue.trim()
						}
					}
				});
			} else {
				oSmartTable.rebindTable();
			}
		},

		onDeleteRALFaceItem: function(oEvent) {
			var bCheck = false;
			var oSmartTable = {};
			var oSmartTableBack = {};
			if (this.getStateProperty("/_GET/AppMode") === "search") {
				oSmartTable = this.getControlsByFieldGroupId("RALFaceSearchSmartTable")[0];
				oSmartTableBack = this.getControlsByFieldGroupId("RALBackSearchSmartTable")[0];
			} else {
				oSmartTable = this.getControlsByFieldGroupId("RALFaceSmartTable")[0];
				oSmartTableBack = this.getControlsByFieldGroupId("RALBackSearchSmartTable")[0];
			}
			var aItems = oSmartTable.getTable().getSelectedItems();
			var aPromises = [];
			if (aItems.length > 0) {
				aItems.forEach(function(oItem) {
					if (oItem === this._oRALFaceSelectedRow) {
						bCheck = true;
					}
					var sPath = oItem.getBindingContext().getPath();
					var oPromise = new Promise(function(resolve, reject) {
						this.getModel().remove(sPath, {
							success: function(oResponse, oMessage) {
								resolve();
							}.bind(this),
							error: function(oError) {
								reject(oError);
							}.bind(this)
						});
					}.bind(this));
					aPromises.push(oPromise);
				}.bind(this));

				Promise.all(aPromises).then(
					function(oData) {
						oSmartTable.getTable().getBinding("items").refresh(true);
						oSmartTable.getTable().removeSelections();
						this.hideBusy();

						if (bCheck) {
							this.setStateProperty("/tabRAL/selectedRALFaceId", null);
							oSmartTableBack.rebindTable();
						}
					}.bind(this),
					function(oError) {
						this.hideBusy();
					}.bind(this)
				);
			} else {
				MessageBox.error(this.getResourceBundle().getText("textNoSelectedRecordsDelete"), {
					icon: MessageBox.Icon.ERROR,
					title: this.getResourceBundle().getText("titleError")
				});
				this.hideBusy();
			}
		},

		onAddRALBackItemFromTable: function(oEvent) {
			if (this._oAddRALBackItemFromTableDialog) {
				this._oAddRALBackItemFromTableDialog.destroy();
			}
			this._oAddRALBackItemFromTableDialog = new sap.ui.xmlfragment("ZO2C_COM_PROD.ZO2C_COM_PROD.view.dialogs.AddRALBackItemFromTable", this);
			this.getView().addDependent(this._oAddRALBackItemFromTableDialog);
			this._oAddRALBackItemFromTableDialog.open();

			this.executeSimpleRefreshSmartTable("AddRALBackItemSmartTable", "ColorVHSet");
		},

		onAddRALBackDialogSelectionChange: function(oEvent) {
			var oSmartTable = {};
			if (this.getStateProperty("/_GET/AppMode") === "search") {
				oSmartTable = this.getControlsByFieldGroupId("RALBackSearchSmartTable")[0];
			} else {
				oSmartTable = this.getControlsByFieldGroupId("RALBackSmartTable")[0];
			}
			var oAddRALBackItemSmartTable = this.getControlsByFieldGroupId("AddRALBackItemSmartTable")[0];
			var iIndex = oAddRALBackItemSmartTable.getTable().getSelectedIndex();
			var oItem = oAddRALBackItemSmartTable.getTable().getContextByIndex(iIndex).getObject();
			var oNewItem = {
				ColorId: oItem.ColorId,
				FaceRVariant: this.getStateProperty("/tabRAL/selectedRALFaceId")
			};

			this.getModel().create("/" + this.createCurrentKey() + "/toRALBack", oNewItem, {
				success: function(oResponse, oMessage) {
					oSmartTable.getTable().getBinding("items").refresh(true);
					this.hideBusy();
					this._oAddRALBackItemFromTableDialog.close();
				}.bind(this),
				error: function(oError) {
					this.hideBusy();
					this._oAddRALBackItemFromTableDialog.close();
				}.bind(this)
			});
		},

		onAddRALBackDialogCancel: function(oEvent) {
			this._oAddRALBackItemFromTableDialog.close();
		},

		handleAddRALBackItemFromTableSearch: function(oEvent) {
			var oSmartTable = this.getControlsByFieldGroupId("AddRALBackItemSmartTable")[0];
			var sValue = oEvent.getSource().getValue();
			if (sValue.trim() !== "") {
				oSmartTable.getTable().bindRows({
					path: "/ColorVHSet",
					parameters: {
						countMode: "Inline",
						operationMode: "Server",
						custom: {
							search: sValue.trim()
						}
					}
				});
			} else {
				oSmartTable.rebindTable();
			}
		},

		onDeleteRALBackItem: function(oEvent) {
			var oSmartTable = {};
			if (this.getStateProperty("/_GET/AppMode") === "search") {
				oSmartTable = this.getControlsByFieldGroupId("RALBackSearchSmartTable")[0];
			} else {
				oSmartTable = this.getControlsByFieldGroupId("RALBackSmartTable")[0];
			}
			var aItems = oSmartTable.getTable().getSelectedItems();
			var aPromises = [];
			if (aItems.length > 0) {
				aItems.forEach(function(oItem) {
					var sPath = oItem.getBindingContext().getPath();
					var oPromise = new Promise(function(resolve, reject) {
						this.getModel().remove(sPath, {
							success: function(oResponse, oMessage) {
								resolve();
							}.bind(this),
							error: function(oError) {
								reject(oError);
							}.bind(this)
						});
					}.bind(this));
					aPromises.push(oPromise);
				}.bind(this));

				Promise.all(aPromises).then(
					function(oData) {
						oSmartTable.getTable().getBinding("items").refresh(true);
						oSmartTable.getTable().removeSelections();
						this.hideBusy();
					}.bind(this),
					function(oError) {
						this.hideBusy();
					}.bind(this)
				);
			} else {
				MessageBox.error(this.getResourceBundle().getText("textNoSelectedRecordsDelete"), {
					icon: MessageBox.Icon.ERROR,
					title: this.getResourceBundle().getText("titleError")
				});
				this.hideBusy();
			}
		},

		onRALFaceListItemPress: function(oEvent) {
			var oSelectedItem = oEvent.getParameter("listItem");
			var oProfileTable = oEvent.getSource();
			var aItems = oProfileTable.getItems();
			this._oRALFaceSelectedRow = oSelectedItem;

			$.each(aItems, function(i, oItem) {
				oItem.removeAllCustomData();
			});

			oSelectedItem.addCustomData(new sap.ui.core.CustomData({
					key: "current",
					value: "use",
					writeToDom: true
				})
			);

			var oSelectedRALFace = oSelectedItem.getBindingContext().getObject();
			var sSelectedRALFaceId = oSelectedRALFace.RVariant;
			var oSmartTable = {};
			if (!!this.getStateProperty("/tabRAL/selectedRALFaceId")) {
				this.setStateProperty("/tabRAL/selectedRALFaceId", sSelectedRALFaceId);
				if (this.getStateProperty("/_GET/AppMode") === "search") {
					oSmartTable = this.getControlsByFieldGroupId("RALBackSearchSmartTable")[0];
				} else {
					oSmartTable = this.getControlsByFieldGroupId("RALBackSmartTable")[0];
				}
				oSmartTable.rebindTable();
			} else {
				this.setStateProperty("/tabRAL/selectedRALFaceId", sSelectedRALFaceId);
				if (this.getStateProperty("/_GET/AppMode") === "search") {
					this.executeRefreshSmartTableViaFieldGroupIds("RALBackSearchSmartTable", "toRALBack");
					oSmartTable = this.getControlsByFieldGroupId("RALBackSearchSmartTable")[0];
				} else {
					this.executeRefreshSmartTableViaFieldGroupIds("RALBackSmartTable", "toRALBack");
					oSmartTable = this.getControlsByFieldGroupId("RALBackSmartTable")[0];
				}
				oSmartTable.rebindTable();
				oSmartTable.getTable().removeSelections();
			}
		}

	});

	$.extend(true, thisController.prototype);
	return thisController;
});
