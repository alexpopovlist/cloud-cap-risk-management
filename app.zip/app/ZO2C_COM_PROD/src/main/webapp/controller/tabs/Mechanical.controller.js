sap.ui.define([
	"ZO2C_COM_PROD/ZO2C_COM_PROD/controller/BaseController",
	"ZO2C_COM_PROD/ZO2C_COM_PROD/custom/class/Common",
	"sap/m/MessageToast",
	"sap/ui/model/Filter",
	"sap/m/MessageBox"

], function(BaseController, Common, MessageToast, Filter, MessageBox) {
	"use strict";

	var thisController = BaseController.extend("ZO2C_COM_PROD.ZO2C_COM_PROD.controller.tabs.Mechanical", {

		Common: Common,
		_oAddMechanicalItemFromTableDialog: null,
		_mechanicalVBoxContent: null,
		_oCopyFromCPDialog: null,
		_bFirstLoad: true, //TODO Заменить на свойство в модели

		onInit: function() {
			if (this.getStateProperty("/_GET").Tab === "Mechanical") {
				this.do(this.processLoad.bind(this), [true]);
			}
		},

		processLoad: function(bTabReload) {
			this.setStateProperty("/app/currentTabId", this.getView().getId());
			this.setStateProperty("/showIncorrectEntries/mechanical", false);
			this.setStateProperty("/showIncorrectEntries/mechanicalAssim", false);

			this.addFragmentToMechanical();

			if (!!this.getStateProperty("/app/currentView")) {
				this.hideBusy();
				this.setStateProperty("/app/refreshObject", true);
				if (bTabReload) {
					this.executeRefreshSmartTableViaFieldGroupIds("MechanicalCPSmartTable", "toMechanical");
				}

				this.makeElementBinding(!bTabReload);
			} else {
				this.setStateProperty("/prevTabId", this.getPageController().getSelectedTabView().getId());
				this.doResolve();
			}
		},

		addFragmentToMechanical: function() {
			const oMechVBox = this.getById("idMechanicalVBox");

			this.destroyMechanicalContent();

			if (!this._mechanicalVBoxContent) {
				this._mechanicalVBoxContent = new sap.ui.xmlfragment(
					this.createId(this.getStateProperty("/_GET").Tab),
					this._getFragmentPath(),
					this
				);
				this.getView().addDependent(this._mechanicalVBoxContent);
			}

			oMechVBox.addItem(this._mechanicalVBoxContent);
		},

		onInLinkSelectHandler: function (oControlEvent) {
			this.onInLinkSelectRelation(oControlEvent);
		},

		destroyMechanicalContent: function() {
			const oMechVBox = this.getById("idMechanicalVBox");
			const aItems = oMechVBox.getItems();

			aItems.forEach(function(oItem) {
				oItem.destroy();
			});

			oMechVBox.removeAllItems();
			this._mechanicalVBoxContent = null;
		},

		_getFragmentPath: function() {
			const sAppMode = this.getStateProperty("/_GET").AppMode;
			var sFragmentPath = "";

			if (sAppMode === "view" || sAppMode === "edit" || sAppMode === "create" || sAppMode === "relation") {
				sFragmentPath = "ZO2C_COM_PROD.ZO2C_COM_PROD.view.tabs.Mechanical.ViewEditCreate";
			} else if (sAppMode === "search") {
				sFragmentPath = "ZO2C_COM_PROD.ZO2C_COM_PROD.view.tabs.Mechanical.Search";
			}
			return sFragmentPath;
		},

		onBeforeRebindMechanicalCP: function(oControlEvent) {
			if (this.getStateProperty("/_GET").AppMode === "view") {
				var oBindingParams = oControlEvent.getParameter("bindingParams");
				var bMechError = this.getStateProperty("/showIncorrectEntries/mechanical");
				var bAssim = this.getStateProperty("/showIncorrectEntries/mechanicalAssim");
				var aFilters = this._getAssimErrorRowFilters(bAssim, bMechError, oBindingParams.filters);
				oBindingParams.filters = aFilters;
			}
		},

		onAssimilatePressHandler: function (oControlEvent) {
			this._onAssimilateOnTablePress(oControlEvent);
		},

		onErrorRowPressHandler: function (oControlEvent) {
			this._onErrorRowOnTablePress(oControlEvent);
		},

		afterChageMechTypeHandler: function(oControlEvent) {
			this.getControlsByFieldGroupId("MechanicalCPSmartTable")[0].rebindTable();
		},

		onShowIncorrectEntries: function(oEvent) {
			if (this.getStateProperty("/_GET/AppMode") === "view") {
				this.getControlsByFieldGroupId("MechanicalCPSmartTable")[0].rebindTable();
			}
		},

		onAddMechanicalItemFromTable: function(oEvent) {
			if (this._oAddMechanicalItemFromTableDialog) {
				this._oAddMechanicalItemFromTableDialog.destroy();
			}
			this._oAddMechanicalItemFromTableDialog = new sap.ui.xmlfragment("ZO2C_COM_PROD.ZO2C_COM_PROD.view.dialogs.AddMechanicalItemFromTable", this);
			this.getView().addDependent(this._oAddMechanicalItemFromTableDialog);
			this._oAddMechanicalItemFromTableDialog.open();

			this.executeRefreshSmartTableViaFieldGroupIds("AddMechanicalItemSmartTable", "toMechTestVH");
		},

		onAddMechanicalDialogSelectionChange: function(oEvent) {
			var oSmartTable = this.getControlsByFieldGroupId("MechanicalCPSmartTable")[0];
			var oAddMechanicalItemSmartTable = this.getControlsByFieldGroupId("AddMechanicalItemSmartTable")[0];
			var iIndex = oAddMechanicalItemSmartTable.getTable().getSelectedIndex();
			var oItem = oAddMechanicalItemSmartTable.getTable().getContextByIndex(iIndex).getObject();
			var oNewItem = {
				MechTest: oItem.MechTest,
				CodeGsg: oItem.CodeGsg
			};

			this.getModel().create("/" + this.createCurrentKey() + "/toMechanical", oNewItem, {
				success: function(oResponse, oMessage) {
					oSmartTable.getTable().getBinding("rows").refresh(true);
					this.hideBusy();
					this._oAddMechanicalItemFromTableDialog.close();
				}.bind(this),
				error: function(oError) {
					this.hideBusy();
					this._oAddMechanicalItemFromTableDialog.close();
				}.bind(this)
			});
		},

		createEntry:function(oEvent){
			var oControl= oEvent.getSource()
			this.onAddSelectRowsToEntity(oEvent);
			switch(oControl.data("dialogName")){
				case'MechanicalItem':
					this._oAddMechanicalItemFromTableDialog.close();
					break;
				case'dialogCP':
					this._oCopyFromCPDialog.close();
					break;
			};
		},

		onRestrictionOnNullInput:function(oEvent){
			var oControl= oEvent.getSource();
			if(oControl.getValue()=="" && oControl.getType()=="Number"){
				oControl.setValue(0);
			}
		},

		onAddMechanicalDialogCancel: function(oEvent) {
			this._oAddMechanicalItemFromTableDialog.close();
		},

		handleAddMechanicalItemFromTableSearch: function(oEvent) {
			var oSmartTable = this.getControlsByFieldGroupId("AddMechanicalItemSmartTable")[0];
			var sValue = oEvent.getSource().getValue();
			if (sValue.trim() !== "") {
				oSmartTable.getTable().bindRows({
					path: "/MechTypeVHSet",
					parameters: {
						countMode: "Inline",
						operationMode: "Server",
						custom: {
							search: sValue.trim()
						}
					}
				});
			} else {
				oSmartTable.rebindTable(true);
			}
		},

		onCopyMechanicalItem: function(oEvent) {
			this.showBusy();
			var oSmartTable = this.getControlsByFieldGroupId("MechanicalCPSmartTable")[0];
			var aItems = oSmartTable.getTable().getSelectedIndices();
			var aPromises = [];

			if (aItems.length > 0) {
				aItems.forEach(function(oItem) {
					var oMechItem = oSmartTable.getTable().getContextByIndex(oItem).getObject();
					var sFunctionImport = "";
					var oNewItem = {};
					if (this.getStateProperty("/_GET").AppMode === "search") {
						sFunctionImport = "CopyFilterMechanical";
						oNewItem = {
							Uuid: oMechItem.Uuid,
							RVariant: oMechItem.RVariant
						};
					} else {
						sFunctionImport = "CopyMechanicalCP";
						oNewItem = {
							StatusCp: oMechItem.StatusCp,
							CodeCp: oMechItem.CodeCp,
							RVariant: oMechItem.RVariant
						};
					}
					var oPromise = new Promise(function(resolve, reject) {
						this.getModel().callFunction("/" + sFunctionImport, {
							method: "POST",
							urlParameters: oNewItem,
							success: function(oResponse, oMessage) {
								resolve();
							}.bind(this),
							error: function(oError) {
								reject(oError);
							}.bind(this)
						});
					}.bind(this));
					aPromises.push(oPromise);
				}.bind(this));

				Promise.all(aPromises).then(
					function(oData) {
						oSmartTable.getTable().getBinding("rows").refresh(true);
						oSmartTable.getTable().clearSelection();
						this.hideBusy();
					}.bind(this),
					function(oError) {
						this.hideBusy();
					}.bind(this)
				);
			} else {
				MessageBox.error(this.getResourceBundle().getText("textNoSelectedRecordsCopy"), {
					icon: MessageBox.Icon.ERROR,
					title: this.getResourceBundle().getText("titleError")
				});
				this.hideBusy();
			}
		},

		onAddFilterMechanicalItem: function(oEvent) {
			this.addEmptyRecord(oEvent);
		},

		onDeleteMechanicalItem: function(oEvent) {
			var oSmartTable = this.getControlsByFieldGroupId("MechanicalCPSmartTable")[0];
			var aItems = oSmartTable.getTable().getSelectedIndices();
			var aPromises = [];

			if (aItems.length > 0) {
				aItems.forEach(function(oItem) {
					var sPath = oSmartTable.getTable().getContextByIndex(oItem).getPath();
					var oPromise = new Promise(function(resolve, reject) {
						this.getModel().remove(sPath, {
							success: function(oResponse, oMessage) {
								resolve();
							}.bind(this),
							error: function(oError) {
								reject(oError);
							}.bind(this)
						});
					}.bind(this));
					aPromises.push(oPromise);
				}.bind(this));

				Promise.all(aPromises).then(
					function(oData) {
						oSmartTable.getTable().getBinding("rows").refresh(true);
						oSmartTable.getTable().clearSelection();
						this.hideBusy();
					}.bind(this),
					function(oError) {
						this.hideBusy();
					}.bind(this)
				);
			} else {
				MessageBox.error(this.getResourceBundle().getText("textNoSelectedRecordsDelete"), {
					icon: MessageBox.Icon.ERROR,
					title: this.getResourceBundle().getText("titleError")
				});
				this.hideBusy();
			}
		},

		onCopyFromCP: function(oEvent) {
			if (this._oCopyFromCPDialog) {
				this._oCopyFromCPDialog.destroy();
			}
			this._oCopyFromCPDialog = new sap.ui.xmlfragment("ZO2C_COM_PROD.ZO2C_COM_PROD.view.dialogs.CopyFromCP", this);
			this.getView().addDependent(this._oCopyFromCPDialog);
			this._oCopyFromCPDialog.open();

			this.executeSimpleRefreshSmartTable("CommercProductSmartTable", "CommercProductVHSet");
		},

		onBeforeRebindCopyFromCPSmartTable: function(oControlEvent) {
			var oBinding = oControlEvent.getParameter("bindingParams");
			var oFilter = this.prepareCopyFromCPFilters();
			oBinding.filters.push(oFilter[0]);
		},

		onFilterApply: function(oEvent) {
			var oFilter = this.prepareCopyFromCPFilters();

			// update table binding
			var oFragmentSmartTable = this.getControlsByFieldGroupId("CommercProductSmartTable")[0];
			var oBinding = oFragmentSmartTable.getTable().getBinding("items");
			oBinding.filter(oFilter, "Application");
		},

		prepareCopyFromCPFilters: function() {
			var aFilters = [];
			if (this.getStateProperty("/copyFromCP").CodeCpH.trim() !== "") {
				aFilters.push(new Filter("CodeCpH", sap.ui.model.FilterOperator.Contains, this.getStateProperty("/copyFromCP").CodeCpH.trim()));
			}
			if (this.getStateProperty("/copyFromCP").ProdType !== "") {
				aFilters.push(new Filter("ProdType", sap.ui.model.FilterOperator.EQ, this.getStateProperty("/copyFromCP").ProdType));
			}
			if (this.getStateProperty("/copyFromCP").SteelMark !== "") {
				aFilters.push(new Filter("SteelMark", sap.ui.model.FilterOperator.EQ, this.getStateProperty("/copyFromCP").SteelMark));
			}
			if (this.getStateProperty("/copyFromCP").ProductStd !== "") {
				aFilters.push(new Filter("ProductStdCode", sap.ui.model.FilterOperator.EQ, this.getStateProperty("/copyFromCP").ProductStd));
			}
			if (this.getStateProperty("/copyFromCP").MarkStd !== "") {
				aFilters.push(new Filter("MarkStdCode", sap.ui.model.FilterOperator.EQ, this.getStateProperty("/copyFromCP").MarkStd));
			}
			if (this.getStateProperty("/copyFromCP").TolStd !== "") {
				aFilters.push(new Filter("TolStdCode", sap.ui.model.FilterOperator.EQ, this.getStateProperty("/copyFromCP").TolStd));
			}
			if (this.getStateProperty("/copyFromCP").HeightMin !== "") {
				aFilters.push(new Filter("HeightMin", sap.ui.model.FilterOperator.EQ, parseFloat(this.getStateProperty("/copyFromCP").HeightMin)));
			}
			if (this.getStateProperty("/copyFromCP").HeightMax !== "") {
				aFilters.push(new Filter("HeightMax", sap.ui.model.FilterOperator.EQ, parseFloat(this.getStateProperty("/copyFromCP").HeightMax)));
			}
			if (this.getStateProperty("/copyFromCP").WidthMin !== "") {
				aFilters.push(new Filter("WidthMin", sap.ui.model.FilterOperator.EQ, parseFloat(this.getStateProperty("/copyFromCP").WidthMin)));
			}
			if (this.getStateProperty("/copyFromCP").WidthMax !== "") {
				aFilters.push(new Filter("WidthMax", sap.ui.model.FilterOperator.EQ, parseFloat(this.getStateProperty("/copyFromCP").WidthMax)));
			}
			if (this.getStateProperty("/copyFromCP").LongMin !== "") {
				aFilters.push(new Filter("LongMin", sap.ui.model.FilterOperator.EQ, parseFloat(this.getStateProperty("/copyFromCP").LongMin)));
			}
			if (this.getStateProperty("/copyFromCP").LongMax !== "") {
				aFilters.push(new Filter("LongMax", sap.ui.model.FilterOperator.EQ, parseFloat(this.getStateProperty("/copyFromCP").LongMax)));
			}
			var oFilter = [new Filter(aFilters, true)];
			return oFilter;
		},

		copyFromCPDialogAccept: function() {
			var oSmartTable = this.getControlsByFieldGroupId("MechanicalCPSmartTable")[0];
			var oFragmentSmartTable = this.getControlsByFieldGroupId("CommercProductSmartTable")[0];
			var oSelectedRow = oFragmentSmartTable.getTable().getSelectedItem();
			var oItem = oSelectedRow.getBindingContext().getObject();
			this.showBusy();
			this.getModel().callFunction("/CopyMechFromCP", {
				method: "POST",
				urlParameters: {
					CodeCp: this.getStateProperty("/_GET").CodeCp,
					StatusCp: this.getStateProperty("/_GET").Statuscp,
					ReplaceHeight: this.getStateProperty("/copyFromCP").ReplaceHeight,
					CodeCPList: oItem.CodeCp
				},
				success: function(oData, oMessage) {
					oSmartTable.getTable().getBinding("rows").refresh(true);
					this.hideBusy();
					this._oCopyFromCPDialog.close();
					MessageToast.show(this.getResourceBundle().getText("textCopyFromCPSuccess"));
				}.bind(this),
				error: function(oError) {
					this.hideBusy();
					this._oCopyFromCPDialog.close();
					MessageBox.error(this.parseRequestError(oError));
				}.bind(this)
			});
		},

		copyFromCPDialogClose: function(oControlEvent) {
			this._oCopyFromCPDialog.close();
		},

		onClearOldValues: function(oEvent) {
			for (var property in this.getStateProperty("/copyFromCP")) {
				if (this.getStateProperty("/copyFromCP").hasOwnProperty(property)) {
					if (property !== "ReplaceHeight") {
						this.getStateProperty("/copyFromCP")[property] = "";
					} else {
						this.getStateProperty("/copyFromCP")[property] = false;
					}
				}
			}
		}
	});

	$.extend(true, thisController.prototype);
	return thisController;
});
