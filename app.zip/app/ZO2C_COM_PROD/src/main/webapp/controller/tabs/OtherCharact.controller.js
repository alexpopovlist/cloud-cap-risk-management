sap.ui.define([
	"ZO2C_COM_PROD/ZO2C_COM_PROD/controller/BaseController",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/model/Filter"

], function (BaseController, MessageToast, MessageBox, Filter) {
	"use strict";

	const thisController = BaseController.extend("ZO2C_COM_PROD.ZO2C_COM_PROD.controller.tabs.OtherCharact", {

		_customObjectDraftIndicator: null,
		_oAddOtherCharactItemFromTableDialog: null,
		_OtherCharactVBoxContent: null,
		_bFirstLoad: true, //TODO Заменить на свойство в модели

		onInit: function () {
			this._customObjectDraftIndicator = this.getStateProperty("/app").customObjectDraftIndicator;
			if (this.getStateProperty("/_GET").Tab === "OtherCharact") {
				this.do(this.processLoad.bind(this), [true]);
			}
		},

		processLoad: function (bTabReload) {

			this.setStateProperty("/app/currentTabId", this.getView().getId());
			this.setStateProperty("/showIncorrectEntries/other", false);
			this.setStateProperty("/showIncorrectEntries/otherAssim", false);


			this.addFragmentToOtherCharact();

			if (!!this.getStateProperty("/app/currentView")) {
				this.hideBusy();
				this.setStateProperty("/app/refreshObject", true);
				if (bTabReload) {
					var oSmartTable = {};
					if (this.getStateProperty("/_GET/AppMode") === "search") {
						this.executeRefreshSmartTableViaFieldGroupIds("OtherCharactSearchSmartTable", "toOtherCharact");
						oSmartTable = this.getControlsByFieldGroupId("OtherCharactSearchSmartTable")[0];
					} else {
						this.executeRefreshSmartTableViaFieldGroupIds("OtherCharactSmartTable", "toOtherCharact");
						oSmartTable = this.getControlsByFieldGroupId("OtherCharactSmartTable")[0];
					}
					oSmartTable.getTable().clearSelection();
				}
				this.makeElementBinding(!bTabReload);
			} else {
				this.setStateProperty("/prevTabId", this.getPageController().getSelectedTabView().getId());
				this.doResolve();
			}
		},

		onRestrictionOnNullInput: function (oEvent) {
			var oControl = oEvent.getSource();
			if (oControl.getValue() == "" && oControl.getType() == "Number") {
				oControl.setValue(0);
			}
		},

		addFragmentToOtherCharact: function () {
			const oOtherCharactVBox = this.getById("idOtherCharactVBox");

			this.destroyOtherCharactContent();

			if (!this._OtherCharactVBoxContent) {
				this._OtherCharactVBoxContent = new sap.ui.xmlfragment(
					this.createId(this.getStateProperty("/_GET").Tab),
					this._getFragmentPath(),
					this
				);
				this.getView().addDependent(this._OtherCharactVBoxContent);
			}

			oOtherCharactVBox.addItem(this._OtherCharactVBoxContent);
		},


		destroyOtherCharactContent: function () {
			const oOtherCharactVBox = this.getById("idOtherCharactVBox");
			const aItems = oOtherCharactVBox.getItems();

			aItems.forEach(function (oItem) {
				oItem.destroy();
			});

			oOtherCharactVBox.removeAllItems();
			this._OtherCharactVBoxContent = null;
		},

		_getFragmentPath: function () {
			const sAppMode = this.getStateProperty("/_GET").AppMode;
			var sFragmentPath = "";

			if (sAppMode === "view" || sAppMode === "edit" || sAppMode === "create" || sAppMode === "relation") {
				sFragmentPath = "ZO2C_COM_PROD.ZO2C_COM_PROD.view.tabs.OtherCharact.ViewEditCreate";
			} else if (sAppMode === "search") {
				sFragmentPath = "ZO2C_COM_PROD.ZO2C_COM_PROD.view.tabs.OtherCharact.Search";
			}
			return sFragmentPath;
		},

		onInLinkSelectHandler: function (oControlEvent) {
			this.onInLinkSelectRelation(oControlEvent);
		},

		onBeforeRebindOtherCharact: function (oControlEvent) {
			if (this.getStateProperty("/_GET").AppMode === "view") {
				var oBindingParams = oControlEvent.getParameter("bindingParams");
				var bMechError = this.getStateProperty("/showIncorrectEntries/other");
				var bAssim = this.getStateProperty("/showIncorrectEntries/otherAssim");
				var oBindingParamsFilters = $.extend(true, [], oBindingParams.filters);
				var aFilters = this._getAssimErrorRowFilters(bAssim, bMechError, oBindingParams.filters);
				oBindingParams.filters = aFilters;
			}
		},

		onOtherCharactFilterCheckBoxSelect: function (oEvent) {
			var oSmartTable = {};
			if (this.getStateProperty("/_GET/AppMode") === "search") {
				oSmartTable = this.getControlsByFieldGroupId("OtherCharactSearchSmartTable")[0];
			} else {
				oSmartTable = this.getControlsByFieldGroupId("OtherCharactSmartTable")[0];
			}
			oSmartTable.rebindTable();
		},

		_onOtherCharactTableCheckBoxSelectSuccess: function (oEvent) {
			var oSmartTable = {};
			if (this.getStateProperty("/_GET/AppMode") === "search") {
				oSmartTable = this.getControlsByFieldGroupId("OtherCharactSearchSmartTable")[0];
			} else {
				oSmartTable = this.getControlsByFieldGroupId("OtherCharactSmartTable")[0];
			}
			oSmartTable.rebindTable();
		},

		onOtherCharactTableCheckBoxSelect: function (oEvent) {
			var oSource = oEvent.getSource();

			if (oSource.data('checkBox') === "Assimilate") {
				this._onAssimilateOnTablePress(oEvent, this._onOtherCharactTableCheckBoxSelectSuccess.bind(this));
			} else if (oSource.data('checkBox') === "ErrorRow") {
				this._onErrorRowOnTablePress(oEvent, this._onOtherCharactTableCheckBoxSelectSuccess.bind(this));
			}
		},

		onAddFilterOtherCharactItem: function (oEvent) {
			this.addEmptyRecord(oEvent);
		},

		onAddOtherCharactItemFromTable: function (oEvent) {
			if (this._oAddOtherCharactItemFromTableDialog) {
				this._oAddOtherCharactItemFromTableDialog.destroy();
			}
			this._oAddOtherCharactItemFromTableDialog = new sap.ui.xmlfragment("ZO2C_COM_PROD.ZO2C_COM_PROD.view.dialogs.AddOtherCharactItemFromTable", this);
			this.getView().addDependent(this._oAddOtherCharactItemFromTableDialog);
			this._oAddOtherCharactItemFromTableDialog.open();

			this.executeSimpleRefreshSmartTable("AddOtherCharactItemSmartTable", "OtherCharactVHSet");
		},

		onAddOtherCharactDialogSelectionChange: function (oEvent) {
			var oSmartTable = {};
			if (this.getStateProperty("/_GET/AppMode") === "search") {
				oSmartTable = this.getControlsByFieldGroupId("OtherCharactSearchSmartTable")[0];
			} else {
				oSmartTable = this.getControlsByFieldGroupId("OtherCharactSmartTable")[0];
			}
			var oAddSmartTable = this.getControlsByFieldGroupId("AddOtherCharactItemSmartTable")[0];
			var iIndex = oAddSmartTable.getTable().getSelectedIndex();
			var oItem = oAddSmartTable.getTable().getContextByIndex(iIndex).getObject();
			var oNewItem = {
				CharactId: oItem.CharactId
			};

			this.getModel().create("/" + this.createCurrentKey() + "/toOtherCharact", oNewItem, {
				success: function (oResponse, oMessage) {
					oSmartTable.getTable().getBinding("rows").refresh(true);
					this.hideBusy();
					this._oAddOtherCharactItemFromTableDialog.close();
				}.bind(this),
				error: function (oError) {
					this.hideBusy();
					this._oAddOtherCharactItemFromTableDialog.close();
				}.bind(this)
			});
		},

		createEntry: function (oEvent) {
			var oControl = oEvent.getSource()
			this.onAddSelectRowsToEntity(oEvent);
			switch (oControl.data("dialogName")) {
				case 'OtherCharactItem':
					this._oAddOtherCharactItemFromTableDialog.close();
					break;
			};
		},

		onAddOtherCharactDialogCancel: function (oEvent) {
			this._oAddOtherCharactItemFromTableDialog.close();
		},

		handleAddOtherCharactItemFromTableSearch: function (oEvent) {
			var sPath = "/OtherCharactVHSet";
			var oSmartTable = this.getControlsByFieldGroupId("AddOtherCharactItemSmartTable")[0];
			var sValue = oEvent.getSource().getValue();
			if (sValue.trim() !== "") {
				oSmartTable.getTable().bindRows({
					path: sPath,
					parameters: {
						countMode: "Inline",
						operationMode: "Server",
						custom: {
							search: sValue.trim()
						}
					}
				});
			} else {
				oSmartTable.rebindTable(true);
			}
		},

		onDeleteOtherCharactItem: function (oEvent) {
			var oSmartTable = {};
			if (this.getStateProperty("/_GET/AppMode") === "search") {
				oSmartTable = this.getControlsByFieldGroupId("OtherCharactSearchSmartTable")[0];
			} else {
				oSmartTable = this.getControlsByFieldGroupId("OtherCharactSmartTable")[0];
			}
			var aItems = oSmartTable.getTable().getSelectedIndices();
			var aPromises = [];
			if (aItems.length > 0) {
				aItems.forEach(function (oItem) {
					var oOtherCharactItem = oSmartTable.getTable().getContextByIndex(oItem).getObject();
					var sPath = oSmartTable.getTable().getContextByIndex(oItem).getPath();
					var oPromise = new Promise(function (resolve, reject) {
						this.getModel().remove(sPath, {
							success: function (oResponse, oMessage) {
								resolve();
							}.bind(this),
							error: function (oError) {
								reject(oError);
							}.bind(this)
						});
					}.bind(this));
					aPromises.push(oPromise);
				}.bind(this));

				Promise.all(aPromises).then(
					function (oData) {
						oSmartTable.getTable().getBinding("rows").refresh(true);
						oSmartTable.getTable().clearSelection();
						this.hideBusy();
					}.bind(this),
					function (oError) {
						this.hideBusy();
					}.bind(this)
				);
			} else {
				MessageBox.error(this.getResourceBundle().getText("textNoSelectedRecordsDelete"), {
					icon: MessageBox.Icon.ERROR,
					title: this.getResourceBundle().getText("titleError")
				});
				this.hideBusy();
			}
		},
		onCopyOtherCharactItem: function (oEvent) {
			this.showBusy();
			var oSmartTable = this.getControlsByFieldGroupId("OtherCharactSmartTable")[0];
			var aItems = oSmartTable.getTable().getSelectedIndices();
			var aPromises = [];

			if (aItems.length > 0) {
				aItems.forEach(function (oItem) {
					var oOtherCharactItem = oSmartTable.getTable().getContextByIndex(oItem).getObject();
					var sFunctionImport = "";
					var oNewItem = {};
					if (this.getStateProperty("/_GET").AppMode !== "search") {
						sFunctionImport = "CopyOtherCharactCP";
						oNewItem = {
							StatusCp: oOtherCharactItem.StatusCp,
							CodeCp: oOtherCharactItem.CodeCp,
							RVariant: oOtherCharactItem.RVariant
						};

						var oPromise = new Promise(function (resolve, reject) {
							this.getModel().callFunction("/" + sFunctionImport, {
								method: "POST",
								urlParameters: oNewItem,
								success: function (oResponse, oMessage) {
									resolve();
								}.bind(this),
								error: function (oError) {
									reject(oError);
								}.bind(this)
							});
						}.bind(this));
					}
					aPromises.push(oPromise);

				}.bind(this));

				Promise.all(aPromises).then(
					function (oData) {
						oSmartTable.getTable().getBinding("rows").refresh(true);
						oSmartTable.getTable().clearSelection();
						this.hideBusy();
					}.bind(this),
					function (oError) {
						this.hideBusy();
					}.bind(this));
			} else {
				MessageBox.error(this.getResourceBundle().getText("textNoSelectedRecordsCopy"), {
					icon: MessageBox.Icon.ERROR,
					title: this.getResourceBundle().getText("titleError")
				});
				this.hideBusy();
			}
		}

	});

	$.extend(true, thisController.prototype);
	return thisController;
});
