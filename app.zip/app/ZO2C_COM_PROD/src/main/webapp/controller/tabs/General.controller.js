sap.ui.define([
	"ZO2C_COM_PROD/ZO2C_COM_PROD/controller/BaseController",
	"ZO2C_COM_PROD/ZO2C_COM_PROD/custom/class/Common",
	"sap/m/MessageBox"

], function(BaseController, Common, MessageBox) {
	"use strict";

	/**
	 * @class
	 * @extends sap.ui.core.mvc.BaseController
	 *
	 * @constructor
	 * @public
	 * @alias zgagarin.zsupplyproc.controller.tabs.General
	 */
	const thisController = BaseController.extend("ZO2C_COM_PROD.ZO2C_COM_PROD.controller.tabs.General",
		/** @lends zgagarin.zsupplyproc.controller.tabs.General.prototype */
		{
			Common: Common,
			_textAreaDialog: null,
			_generalVBoxContent: null,

			/**
			 * Инициализирует вкладку Основная Информация.
			 */
			onInit: function() {
				if (this.getStateProperty("/_GET").Tab === "General") {
					this.do(this.processLoad.bind(this), [true]);
				}
			},
			onChangeEInputDocExists: function(oEvent){
				this.getPageController().loadObject();
			},
			/**
			 * Загружает данные для вкладки Основная Информация.
			 * @param {boolean} [bTabReload] Если true, то обновляет/задает биндинг таблицы участников рабочей группы.
			 * Если первый заход на вкладку и значение bTabReload равно true, то происходит принудительное обновление аггрегаций всех элементов со справочниками.
			 * !bTabReload передается в makeElementBinding.
			 */
			processLoad: function(bTabReload) {
				var bSearch = this.getStateProperty("/_GET").AppMode === "search";
				var bCreate = this.getStateProperty("/_GET").AppMode === "create";
				var bIsReloaded = this.getStateProperty("/prevTabId") === this.getPageController().getSelectedTabView(true).getId();

				// TODO
				this.addFragmentToGeneral();

				this.setSearchEInputVisibleByFieldGruop("EInputVisibleSearch", bSearch);
				this.setSearchEInputVisibleByFieldGruop("EInputVisibleCreate", bCreate);

				this.setStateProperty("/app/currentTabId", this.getView().getId());

				if (!!this.getStateProperty("/app/currentView")) {
					this.setStateProperty("/app/refreshObject", true);

					this.makeElementBinding(!bTabReload || !!bIsReloaded);

					var sBindingPath = "";
					if (bSearch) {
						sBindingPath = "/" + this.createCurrentKey() + "/toAssimilate4VH";
					} else {
						sBindingPath = "/Assimilate4VHSet";
					}
					var oAssimilateSelect = this.getControlsByFieldGroupId("UrgencySelect")[0];
					var oItemSelectTemplate = new sap.ui.core.Item({
						key: "{Assimilate}",
						text: "{AssimilateName}"
					});
					oAssimilateSelect.bindItems(sBindingPath, oItemSelectTemplate);
				} else {
					this.setStateProperty("/prevTabId", this.getPageController().getSelectedTabView().getId());
					this.doResolve();
				}
			},

			onRestrictionOnNullInput:function(oEvent){
				var oControl= oEvent.getSource();
				if(oControl.getValue()=="" && oControl.getType()=="Number"){
					oControl.setValue(0);
				}
			},

			setSearchEInputVisibleByFieldGruop: function (sFieldGroupName, bValue) {
				var aItems = this.getControlsByFieldGroupId(sFieldGroupName);
				aItems.forEach(function(oItem) {
					if (oItem.getMetadata().getName().indexOf("EInput") > 0){
						oItem.setVisible(bValue);
					}
				}.bind(this));
			},

			rerenderEInput: function (sFieldGroupName) {
				var aItems = this.getControlsByFieldGroupId(sFieldGroupName);
				aItems.forEach(function(oItem) {
					if (oItem.getMetadata().getName().indexOf("EInput") > 0){
						oItem.rerender();
					}
				}.bind(this));
			},

			addFragmentToGeneral: function() {
				var oGeneralVBox = this.getById("idGeneralVBox");

				this.destroyGeneralContent();

				if (!this._generalVBoxContent) {
					this._generalVBoxContent = new sap.ui.xmlfragment(
						this.createId(this.getStateProperty("/_GET").Tab),
						this._getFragmentPath(),
						this
					);
					this.getView().addDependent(this._generalVBoxContent);
				}

				oGeneralVBox.addItem(this._generalVBoxContent);
			},

			destroyGeneralContent: function() {
				var oGeneralVBox = this.getById("idGeneralVBox");
				var aItems = oGeneralVBox.getItems();

				aItems.forEach(function(oItem) {
					oItem.destroy();
				});

				oGeneralVBox.removeAllItems();
				this._generalVBoxContent = null;
			},

			_getFragmentPath: function(sType) {
				const sAppMode = this.getStateProperty("/_GET").AppMode;
				var sFragmentPath = "";

				if (sAppMode === "view" || sAppMode === "edit" || sAppMode === "create") {
					sFragmentPath = "ZO2C_COM_PROD.ZO2C_COM_PROD.view.tabs.General.ViewEditCreate";
				} else if (sAppMode === "search") {
					sFragmentPath = "ZO2C_COM_PROD.ZO2C_COM_PROD.view.tabs.General.Search";
				}
				return sFragmentPath;
			},

			onAttachButtonPressHandler: function (oControlEvent) {
				var sNavigationProperty = oControlEvent.getSource().data("fileUrl");
				var sBindingContextPath = this.getView().getBindingContext().getPath();
			 	var sDownloadPath = this.getOwnerComponent().getModel().sServiceUrl + sBindingContextPath + "/" + sNavigationProperty + "/$value";
			 	
			 	window.open(sDownloadPath);
			},

			onEInputRefreshBindingHandler: function () {
				this.getPageController().loadObject();
			},

			onUrgencySelect: function(oEvent) {
				var sSelect = oEvent.getSource().getSelectedKey();
				this.setStateProperty("/check/urgency", sSelect);
				if (this.getStateProperty("/_GET").AppMode === "search") {
					this.saveChanges();
				} else if (this.getStateProperty("/_GET").AppMode === "edit" || this.getStateProperty("/_GET").AppMode === "create") {
					this.onDataRefresh(oEvent);
				}
			},
			saveAssimilateChange: function(oControlEvent) {
				this.showBusy();
				const oControl = this.getView().byId("selectAssimilate"),
					sDomIdControl=oControl.getId(),
					oModel = this.getModel(),
					aContextPath = oControl.getBindingContext().getPath();
				var newValue,
					sProperty,
					oData = {};
				var oldValue=oModel.getObject(aContextPath).Assimilate;
				newValue = oControl.getSelectedKey();
				sProperty= oControl.getBindingInfo("selectedKey").parts[0].path;
				oData[sProperty] = newValue;
				oModel.update(aContextPath, oData, {
					success: function(oResponse, oMessage) {
						oModel.refresh();
						this.hideBusy();
					}.bind(this),
					error: function(oError) {
						this.setUndefinedKey(sDomIdControl,oldValue);
						this.hideBusy();
						this.showRequestError(oError);
					}.bind(this)
				});
			},
			setUndefinedKey:function(sId,Value){
				var oControl=sap.ui.getCore().byId(sId);
				oControl.setSelectedKey(undefined);
				oControl.setSelectedKey(Value);
			},
			onDataRefresh: function(oEvent) {
				if (this.getStateProperty("/_GET").AppMode === "edit" || this.getStateProperty("/_GET").AppMode === "create") {
					this.calculatedFieldChange(oEvent);
				}
			}

		});

	$.extend(true, thisController.prototype);
	return thisController;
});
