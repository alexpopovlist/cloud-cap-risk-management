sap.ui.define([
	"sap/ui/model/json/JSONModel"
], function(JSONModel) {
	"use strict";

	return {
		createJSONModel: function(oContext) {
			const oModel = new JSONModel({
				_GET: {},
				// for test relation
				idRelationList: {
					"test": [{
							text: "test1"
						},
						{
							text: "test1"
						},
						{
							text: "test1"
						},
						{
							text: "test1"
						},
						{
							text: "test1"
						}
					]
				},

				app: {
					appState: "",
					busy: false,
					delay: 10,
					fcModel: {},
					languages: [{
							caption: "RU",
							key: "ru",
							description: "Русский"
						},
						{
							caption: "EN",
							key: "en",
							description: "English"
						}
					],
					GeneralMode: "",
					tabs: [
						"General",
						"Technical",
						"Chemical",
						"Mechanical",
						"Classif",
						"ProfileSize",
						"OtherCharact",
						"RAL",
						"DecorativeTape"
					],
					statuses: {
						view: "A",
						edit: "E",
						create: "N"
					},
					assimilate: [{
							key: "",
							text: oContext.getModel("i18n").getResourceBundle().getText("assimilateAll")
						},
						{
							key: "1",
							text: oContext.getModel("i18n").getResourceBundle().getText("assimilateTrue")
						},
						{
							key: "2",
							text: oContext.getModel("i18n").getResourceBundle().getText("assimilateFalse")
						}
					],
					errorRow: [{
							key: "",
							text: oContext.getModel("i18n").getResourceBundle().getText("errorRowAll")
						},
						{
							key: "1",
							text: oContext.getModel("i18n").getResourceBundle().getText("errorRowFalse")
						},
						{
							key: "2",
							text: oContext.getModel("i18n").getResourceBundle().getText("errorRowTrue")
						}
					],
					filterErrorRow: [{
							key: "",
							text: oContext.getModel("i18n").getResourceBundle().getText("filterErrorRowAll")
						},
						{
							key: "1",
							text: oContext.getModel("i18n").getResourceBundle().getText("filterErrorRowFalse")
						},
						{
							key: "2",
							text: oContext.getModel("i18n").getResourceBundle().getText("filterErrorRowTrue")
						}
					],
					GeneralInfo: {
						"OPFoundCPPanel": false,
						"ObjectPageLayout": false,
						"expandedObjectPageTitle": "",
						"snappedObjectPageTitle": ""
					},
					rerenderEInput: {
						"General": false
					},
					customObjectDraftIndicator: null,
					selectedLanguage: null,
					mode: "view",
					tab: null,
					saveActiveVersionRequired: false,
					lastMode: false,
					currentView: null,
					currentTabId: "",
					lastBindingTabView: null,
					action: "create",
					name: "zo2c_com_prod",
					showErrorPopover: false,
					navError: {},
					linkServiceName: "LinksCPSet"
				},

				technical: {
					NonStd: false
				},

				changeLog: {
					startDate: null,
					endDate: null,
					UserId: "",
					FieldKey: "",
					selectViewId: ""
				},

				showIncorrectEntries: {
					technical: false,
					technicalAssim: false,
					mechanical: false,
					mechanicalAssim: false,
					classif: false,
					classifAssim: false,
					chemical: false,
					chemicalAssim:false,
					checkBoxProfileSizeAssimilate: false,
					checkBoxProfileSizeErrorRow: false,
					checkBoxProfileErrorRow: false,
					checkBoxProfileAssimilate: false,
					checkBoxRALFaceErrorRow:false,
					checkBoxRALFaceAssimilate:false,
					checkBoxRALBackErrorRow: false,
					checkBoxRALBackAssimilate: false,
					other: false,
					otherAssim: false,
					relation: false,
					relationAssim: false,
					decorType:false,
					decorTypeAssim: false
				},

				applyFilter: {
					FilterUuid: null
				},

				oSearchChemicalValueEnableESelect: {},

				searchResults: {
					display: false,
					apply: false,
					lastAppliedFilterUuid: null
				},

				classif: {
					showSelected: false,
				},

				check: {
					// urgency: "INAC"
					urgency: null
				},

				count: {
					Classif: 0,
					Chemical: 0
				},

				tabProfileSize: {
					selectedProfileId: null,
					selectedBindingPath: ""
				},

				tabRAL: {
					selectedRALFaceId: null
				},

				addFromChemicalElem: {
					checkBox: false
				},

				copyFromCP: {
					CodeCpH: "",
					ProdType: "",
					SteelMark: "",
					ProductStd: "",
					MarkStd: "",
					TolStd: "",
					HeightMin: "",
					HeightMax: "",
					WidthMin: "",
					WidthMax: "",
					LongMin: "",
					LongMax: "",
					ReplaceHeight: false
				},

				addNewItemsDialog: {
					mechanical: true,
					technical: true,
					classif: true
				},

				manuallyDataDialog: {
					"mechanical": {
						VidM: "",
						NmMin: 0,
						NmMax: 0,
						TTest: "",
						CodIsp: "",
						LayKoeff: 0,
						LayHeight: 0,
						HeightMin: 0,
						HeightMax: 0,
						OrderProbInt: "",
						TypeSimple: "",
						UgolZag: "",
						UgolRaz: "",
						CountPeregMin: 0,
						CountPeregAvg: 0
					}
				},

				selectDialogData: {
					"copy": [{
							key: "1",
							text: oContext.getModel("i18n").getResourceBundle().getText("generalTab"),
							selected: true,
							visible: true
						},
						{
							key: "2",
							text: oContext.getModel("i18n").getResourceBundle().getText("chemicalTab"),
							selected: true,
							visible: true
						},
						{
							key: "3",
							text: oContext.getModel("i18n").getResourceBundle().getText("mechanicalTab"),
							selected: true,
							visible: true
						},
						{
							key: "4",
							text: oContext.getModel("i18n").getResourceBundle().getText("technicalTab"),
							selected: true,
							visible: true
						},
						{
							key: "5",
							text: oContext.getModel("i18n").getResourceBundle().getText("classificationTab"),
							selected: true,
							visible: true
						},
						{
							key: "6",
							text: oContext.getModel("i18n").getResourceBundle().getText("profilesizeTab"),
							selected: true,
							visible: true
						},
						{
							key: "7",
							text: oContext.getModel("i18n").getResourceBundle().getText("othercharactTab"),
							selected: true,
							visible: true
						},
						{
							key: "8",
							text: oContext.getModel("i18n").getResourceBundle().getText("ralTab"),
							selected: true,
							visible: true
						},
						{
							key: "9",
							text: oContext.getModel("i18n").getResourceBundle().getText("decorativetapeTab"),
							selected: true,
							visible: true
						}
					]
				},

				createTechnicalItemFromTable: [],
				testMultiInput: [],
				chemiMultiInput: [],
				tabReload: {
					"General": {
						value: true
					}
				},
				refs: {}
			});
			oModel.setDefaultBindingMode("TwoWay");
			return oModel;
		}
	};
})
