sap.ui.define([
	"sap/ui/model/odata/v2/ODataModel"
], function(ODataModel) {
	"use strict";

	/**
	 * @class
	 *
	 * @constructor
	 * @public
	 * @alias zgagarin.zsupplyproc.custom.class.EODataModel
	 */
	var oEODataModel = ODataModel.extend("ZO2C_COM_PROD.ZO2C_COM_PROD.custom.class.EODataModel",
		/** @lends zgagarin.zsupplyproc.custom.class.EODataModel.prototype */
		{

			_delayBeforeSave: null,
			_lastSave: null,
			_waitingForSave: null,
			_do: null,
			_doFn: null,
			_doResolve: null,
			_doReject: null,

			/**
			 * Getter Использование задержки сохранения
			 * @return {boolean} задержка
			 */

			getWaitingForSave: function() {
				return this._waitingForSave;
			},

			/**
			 * Setter Использование задержки сохранения
			 * @param {boolean} bWaitingForSave задержка
			 */

			setWaitingForSave: function(bWaitingForSave) {
				this._waitingForSave = (bWaitingForSave) ? true : false;
			},

			/**
			 * Getter Задержка сохранения
			 * @return {number} задержка
			 */

			getDelayBeforeSave: function() {
				return this._delayBeforeSave;
			},

			/**
			 * Getter Время последнего сохранения
			 * @return {Date} Время
			 */

			getLastSave: function() {
				return this._lastSave;
			},

			/**
			 * Setter Время последнего сохранения
			 * @param {Date} iTime Время
			 */

			setLastSave: function(iTime) {
				this._lastSave = iTime;
			},

			/**
			 * Setter времени последнего сохранения
			 */

			setLastSaveNow: function() {
				const oNow = new Date();
				this.setLastSave(oNow.getTime());
			},

			/**
			 * Добавление CallBack функции исполняемой после метода SubmitChanges
			 * @param {function} fnCallback Функция.
			 */

			addSubmitChangesCallback: function(fnCallback) {
				if (!this._changesCallbacks) {
					this._changesCallbacks = [];
				}

				if ($.isFunction(fnCallback)) {
					this._changesCallbacks.push(fnCallback);
				}
			},

			/**
			 * Getter обновления сущности после изменения свойства
			 * @return {boolean} обновление после изменения.
			 */

			getRefreshAfterChange: function() {
				return this.bRefreshAfterChange;
			},

			/**
			 * constructor
			 */

			constructor: function() {
				ODataModel.prototype.constructor.apply(this, arguments);
				this.setLastSaveNow();
				const argNumb = arguments.length - 1;
				this._delayBeforeSave = (arguments[argNumb].delayBeforeSave) ? arguments[argNumb].delayBeforeSave : 5000;
				this._do = Promise.resolve();
			},

			metadata: {
				properties: {},
				events: {}
			}
		});
	return oEODataModel;
});
