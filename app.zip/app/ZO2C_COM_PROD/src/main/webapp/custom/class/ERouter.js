sap.ui.define([
	"sap/m/routing/Router",
	"sap/ui/core/routing/HashChanger"
], function(Router, HashChanger) {
	"use strict";

	/**
	 * @class
	 *
	 * @constructor
	 * @public
	 * @alias zgagarin.zsupplyproc.custom.class.ERouter
	 */
	var oERouter = Router.extend("ZO2C_COM_PROD.ZO2C_COM_PROD.custom.class.ERouter",
		/** @lends zgagarin.zsupplyproc.custom.class.ERouter.prototype */
		{
			_HashChanger: null,

			/**
			 * constructor
			 */

			constructor: function() {
				Router.prototype.constructor.apply(this, arguments);
				this._HashChanger = new HashChanger();
			},

			/**
			 * Setter хэша
			 */

			setHash: function(sHash) {
				this._HashChanger.setHash(sHash);
			},

			/**
			 * Фнкция замены последнего хэша
			 * @param {string} sHash Хэш
			 */

			replaceHash: function(sHash) {
				this._HashChanger.replaceHash(sHash);
			}
		});
	return oERouter;
});
