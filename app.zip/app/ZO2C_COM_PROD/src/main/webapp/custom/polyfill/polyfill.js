var g = (typeof global !== 'undefined') ? global :
	((typeof window !== 'undefined') ? window :
		((typeof self !== 'undefined') ? self : this));

g.xmlToJson = function(xml) {

	// Create the return object
	var obj = {};

	if (xml.nodeType == 1) { // element
		// do attributes
		if (xml.attributes.length > 0) {
			obj["@attributes"] = {};
			for (var j = 0; j < xml.attributes.length; j++) {
				var attribute = xml.attributes.item(j);
				obj["@attributes"][attribute.nodeName] = attribute.nodeValue;
			}
		}
	} else if (xml.nodeType == 3) { // text
		obj = xml.nodeValue;
	}

	// do children
	if (xml.hasChildNodes()) {
		for (var i = 0; i < xml.childNodes.length; i++) {
			var item = xml.childNodes.item(i);
			var nodeName = item.nodeName;
			if (typeof(obj[nodeName]) == "undefined") {
				obj[nodeName] = xmlToJson(item);
			} else {
				if (typeof(obj[nodeName].push) == "undefined") {
					var old = obj[nodeName];
					obj[nodeName] = [];
					obj[nodeName].push(old);
				}
				obj[nodeName].push(xmlToJson(item));
			}
		}
	}
	return obj;
};

if (!Array.from) {
	Array.from = (function() {
		var toStr = Object.prototype.toString;
		var isCallable = function(fn) {
			return typeof fn === 'function' || toStr.call(fn) === '[object Function]';
		};
		var toInteger = function(value) {
			var number = Number(value);
			if (isNaN(number)) {
				return 0;
			}
			if (number === 0 || !isFinite(number)) {
				return number;
			}
			return (number > 0 ? 1 : -1) * Math.floor(Math.abs(number));
		};
		var maxSafeInteger = Math.pow(2, 53) - 1;
		var toLength = function(value) {
			var len = toInteger(value);
			return Math.min(Math.max(len, 0), maxSafeInteger);
		};

		return function from(arrayLike /*, mapFn, thisArg */ ) {
			var C = this;

			var items = Object(arrayLike);

			if (arrayLike == null) {
				throw new TypeError('Array.from requires an array-like object - not null or undefined');
			}

			var mapFn = arguments[1];
			if (typeof mapFn !== 'undefined') {
				mapFn = arguments.length > 1 ? arguments[1] : void undefined;
				if (!isCallable(mapFn)) {
					throw new TypeError('Array.from: when provided, the second argument must be a function');
				}

				if (arguments.length > 2) {
					T = arguments[2];
				}
			}

			var len = toLength(items.length);

			var A = isCallable(C) ? Object(new C(len)) : new Array(len);

			var k = 0;
			var kValue;
			while (k < len) {
				kValue = items[k];
				if (mapFn) {
					A[k] = typeof T === 'undefined' ? mapFn(kValue, k) : mapFn.call(T, kValue, k);
				} else {
					A[k] = kValue;
				}
				k += 1;
			}
			A.length = len;
			return A;
		};
	}());
}

//Polyfill for partial function binding
Function.prototype.curry = function() {
	var argumentsArray = Array.prototype.slice.call(arguments);
	var context = argumentsArray[0];
	var args = argumentsArray.slice(1);
	return function() {
		var mergedArgs = [];
		var max = Math.max(args.length, arguments.length);
		for (var i = 0; i < max; i++) {
			mergedArgs.push(args[i] ? args[i] : arguments[i]);
		}
		var listner = context ? context : this;
		return this.apply(listner, mergedArgs);
	}.bind(this);
};


//Polyfill for URL object
(function(global) {

	var checkIfIteratorIsSupported = function() {
		try {
			return !!Symbol.iterator;
		} catch (error) {
			return false;
		}
	};


	var iteratorSupported = checkIfIteratorIsSupported();

	var createIterator = function(items) {
		var iterator = {
			next: function() {
				var value = items.shift();
				return {
					done: value === void 0,
					value: value
				};
			}
		};

		if (iteratorSupported) {
			iterator[Symbol.iterator] = function() {
				return iterator;
			};
		}

		return iterator;
	};

	var polyfillURLSearchParams = function() {

		var URLSearchParams = function(searchString) {
			Object.defineProperty(this, '_entries', {
				value: {}
			});

			if (typeof searchString === 'string') {
				if (searchString !== '') {
					searchString = searchString.replace(/^\?/, '');
					var attributes = searchString.split('&');
					var attribute;
					for (var i = 0; i < attributes.length; i++) {
						attribute = attributes[i].split('=');
						this.append(
							decodeURIComponent(attribute[0]),
							(attribute.length > 1) ? decodeURIComponent(attribute[1]) : ''
						);
					}
				}
			} else if (searchString instanceof URLSearchParams) {
				var _this = this;
				searchString.forEach(function(value, name) {
					_this.append(value, name);
				});
			}
		};

		var proto = URLSearchParams.prototype;

		proto.append = function(name, value) {
			if (name in this._entries) {
				this._entries[name].push(value.toString());
			} else {
				this._entries[name] = [value.toString()];
			}
		};

		proto.delete = function(name) {
			delete this._entries[name];
		};

		proto.get = function(name) {
			return (name in this._entries) ? this._entries[name][0] : null;
		};

		proto.getAll = function(name) {
			return (name in this._entries) ? this._entries[name].slice(0) : [];
		};

		proto.has = function(name) {
			return (name in this._entries);
		};

		proto.set = function(name, value) {
			this._entries[name] = [value.toString()];
		};

		proto.forEach = function(callback, thisArg) {
			var entries;
			for (var name in this._entries) {
				if (this._entries.hasOwnProperty(name)) {
					entries = this._entries[name];
					for (var i = 0; i < entries.length; i++) {
						callback.call(thisArg, entries[i], name, this);
					}
				}
			}
		};

		proto.keys = function() {
			var items = [];
			this.forEach(function(value, name) {
				items.push(name);
			});
			return createIterator(items);
		};

		proto.values = function() {
			var items = [];
			this.forEach(function(value) {
				items.push(value);
			});
			return createIterator(items);
		};

		proto.entries = function() {
			var items = [];
			this.forEach(function(value, name) {
				items.push([name, value]);
			});
			return createIterator(items);
		};

		if (iteratorSupported) {
			proto[Symbol.iterator] = proto.entries;
		}

		proto.toString = function() {
			var searchString = '';
			this.forEach(function(value, name) {
				if (searchString.length > 0) searchString += '&';
				searchString += encodeURIComponent(name) + '=' + encodeURIComponent(value);
			});
			return searchString;
		};

		global.URLSearchParams = URLSearchParams;
	};

	if (!('URLSearchParams' in global) || (new URLSearchParams('?a=1').toString() !== 'a=1')) {
		polyfillURLSearchParams();
	}

	// HTMLAnchorElement

})(g);

(function(global) {
	/**
	 * Polyfill URL
	 *
	 * Inspired from : https://github.com/arv/DOM-URL-Polyfill/blob/master/src/url.js
	 */

	var checkIfURLIsSupported = function() {
		try {
			var u = new URL('b', 'http://a');
			u.pathname = 'c%20d';
			return (u.href === 'http://a/c%20d') && u.searchParams;
		} catch (e) {
			return false;
		}
	};


	var polyfillURL = function() {
		var _URL = global.URL;

		var URL = function(url, base) {
			if (typeof url !== 'string') url = String(url);

			var doc = document.implementation.createHTMLDocument('');
			window.doc = doc;
			if (base) {
				var baseElement = doc.createElement('base');
				baseElement.href = base;
				doc.head.appendChild(baseElement);
			}

			var anchorElement = doc.createElement('a');
			anchorElement.href = url;
			doc.body.appendChild(anchorElement);
			anchorElement.href = anchorElement.href; // force href to refresh

			if (anchorElement.protocol === ':' || !/:/.test(anchorElement.href)) {
				throw new TypeError('Invalid URL');
			}

			Object.defineProperty(this, '_anchorElement', {
				value: anchorElement
			});
		};

		var proto = URL.prototype;

		var linkURLWithAnchorAttribute = function(attributeName) {
			Object.defineProperty(proto, attributeName, {
				get: function() {
					return this._anchorElement[attributeName];
				},
				set: function(value) {
					this._anchorElement[attributeName] = value;
				},
				enumerable: true
			});
		};

		['hash', 'host', 'hostname', 'port', 'protocol', 'search']
		.forEach(function(attributeName) {
			linkURLWithAnchorAttribute(attributeName);
		});

		Object.defineProperties(proto, {

			'toString': {
				get: function() {
					var _this = this;
					return function() {
						return _this.href;
					};
				}
			},

			'href': {
				get: function() {
					return this._anchorElement.href.replace(/\?$/, '');
				},
				set: function(value) {
					this._anchorElement.href = value;
				},
				enumerable: true
			},

			'pathname': {
				get: function() {
					return this._anchorElement.pathname.replace(/(^\/?)/, '/');
				},
				set: function(value) {
					this._anchorElement.pathname = value;
				},
				enumerable: true
			},

			'origin': {
				get: function() {
					return this._anchorElement.protocol + '//' + this._anchorElement.hostname + (this._anchorElement.port ? (':' + this._anchorElement.port) : '');
				},
				enumerable: true
			},

			'password': { // TODO
				get: function() {
					return '';
				},
				set: function(value) {},
				enumerable: true
			},

			'username': { // TODO
				get: function() {
					return '';
				},
				set: function(value) {},
				enumerable: true
			},

			'searchParams': {
				get: function() {
					var searchParams = new URLSearchParams(this.search);
					var _this = this;
					['append', 'delete', 'set'].forEach(function(methodName) {
						var method = searchParams[methodName];
						searchParams[methodName] = function() {
							method.apply(searchParams, arguments);
							_this.search = searchParams.toString();
						};
					});
					return searchParams;
				},
				enumerable: true
			}
		});

		URL.createObjectURL = function(blob) {
			return _URL.createObjectURL.apply(_URL, arguments);
		};

		URL.revokeObjectURL = function(url) {
			return _URL.revokeObjectURL.apply(_URL, arguments);
		};

		global.URL = URL;

	};

	if (!checkIfURLIsSupported()) {
		polyfillURL();
	}

	if ((global.location !== void 0) && !('origin' in global.location)) {
		var getOrigin = function() {
			return global.location.protocol + '//' + global.location.hostname + (global.location.port ? (':' + global.location.port) : '');
		};

		try {
			Object.defineProperty(global.location, 'origin', {
				get: getOrigin,
				enumerable: true
			});
		} catch (e) {
			setInterval(function() {
				global.location.origin = getOrigin();
			}, 100);
		}
	}

})(g);

//Includes polyfill

if (!String.prototype.includes) {
	(function() {
		'use strict'; // needed to support `apply`/`call` with `undefined`/`null`
		var toString = {}.toString;
		var defineProperty = (function() {
			// IE 8 only supports `Object.defineProperty` on DOM elements
			try {
				var object = {};
				var $defineProperty = Object.defineProperty;
				var result = $defineProperty(object, object, object) && $defineProperty;
			} catch (error) {}
			return result;
		}());
		var indexOf = ''.indexOf;
		var includes = function(search) {
			if (this == null) {
				throw TypeError();
			}
			var string = String(this);
			if (search && toString.call(search) == '[object RegExp]') {
				throw TypeError();
			}
			var stringLength = string.length;
			var searchString = String(search);
			var searchLength = searchString.length;
			var position = arguments.length > 1 ? arguments[1] : undefined;
			// `ToInteger`
			var pos = position ? Number(position) : 0;
			if (pos != pos) { // better `isNaN`
				pos = 0;
			}
			var start = Math.min(Math.max(pos, 0), stringLength);
			// Avoid the `indexOf` call if no match is possible
			if (searchLength + start > stringLength) {
				return false;
			}
			return indexOf.call(string, searchString, pos) != -1;
		};
		if (defineProperty) {
			defineProperty(String.prototype, 'includes', {
				'value': includes,
				'configurable': true,
				'writable': true
			});
		} else {
			String.prototype.includes = includes;
		}
	}());
}

/*new*/
/* FileSaver.js
 * A saveAs() FileSaver implementation.
 * 1.3.8
 * 2018-03-22 14:03:47
 *
 * By Eli Grey, https://eligrey.com
 * License: MIT
 *   See https://github.com/eligrey/FileSaver.js/blob/master/LICENSE.md
 */

/*global self */
/*jslint bitwise: true, indent: 4, laxbreak: true, laxcomma: true, smarttabs: true, plusplus: true */

/*! @source http://purl.eligrey.com/github/FileSaver.js/blob/master/src/FileSaver.js */

var saveAs = saveAs || (function(view) {
	"use strict";
	// IE <10 is explicitly unsupported
	if (typeof view === "undefined" || typeof navigator !== "undefined" && /MSIE [1-9]\./.test(navigator.userAgent)) {
		return;
	}
	var
		doc = view.document
		// only get URL when necessary in case Blob.js hasn't overridden it yet
		,
		get_URL = function() {
			return view.URL || view.webkitURL || view;
		},
		save_link = doc.createElementNS("http://www.w3.org/1999/xhtml", "a"),
		can_use_save_link = "download" in save_link,
		click = function(node) {
			var event = new MouseEvent("click");
			node.dispatchEvent(event);
		},
		is_safari = /constructor/i.test(view.HTMLElement) || view.safari,
		is_chrome_ios = /CriOS\/[\d]+/.test(navigator.userAgent),
		setImmediate = view.setImmediate || view.setTimeout,
		throw_outside = function(ex) {
			setImmediate(function() {
				throw ex;
			}, 0);
		},
		force_saveable_type = "application/octet-stream"
		// the Blob API is fundamentally broken as there is no "downloadfinished" event to subscribe to
		,
		arbitrary_revoke_timeout = 1000 * 40 // in ms
		,
		revoke = function(file) {
			var revoker = function() {
				if (typeof file === "string") { // file is an object URL
					get_URL().revokeObjectURL(file);
				} else { // file is a File
					file.remove();
				}
			};
			setTimeout(revoker, arbitrary_revoke_timeout);
		},
		dispatch = function(filesaver, event_types, event) {
			event_types = [].concat(event_types);
			var i = event_types.length;
			while (i--) {
				var listener = filesaver["on" + event_types[i]];
				if (typeof listener === "function") {
					try {
						listener.call(filesaver, event || filesaver);
					} catch (ex) {
						throw_outside(ex);
					}
				}
			}
		},
		auto_bom = function(blob) {
			// prepend BOM for UTF-8 XML and text/* types (including HTML)
			// note: your browser will automatically convert UTF-16 U+FEFF to EF BB BF
			if (/^\s*(?:text\/\S*|application\/xml|\S*\/\S*\+xml)\s*;.*charset\s*=\s*utf-8/i.test(blob.type)) {
				return new Blob([String.fromCharCode(0xFEFF), blob], {
					type: blob.type
				});
			}
			return blob;
		},
		FileSaver = function(blob, name, no_auto_bom) {
			if (!no_auto_bom) {
				blob = auto_bom(blob);
			}
			// First try a.download, then web filesystem, then object URLs
			var
				filesaver = this,
				type = blob.type,
				force = type === force_saveable_type,
				object_url, dispatch_all = function() {
					dispatch(filesaver, "writestart progress write writeend".split(" "));
				}
				// on any filesys errors revert to saving with object URLs
				,
				fs_error = function() {
					if ((is_chrome_ios || (force && is_safari)) && view.FileReader) {
						// Safari doesn't allow downloading of blob urls
						var reader = new FileReader();
						reader.onloadend = function() {
							var url = is_chrome_ios ? reader.result : reader.result.replace(/^data:[^;]*;/, 'data:attachment/file;');
							var popup = view.open(url, '_blank');
							if (!popup) view.location.href = url;
							url = undefined; // release reference before dispatching
							filesaver.readyState = filesaver.DONE;
							dispatch_all();
						};
						reader.readAsDataURL(blob);
						filesaver.readyState = filesaver.INIT;
						return;
					}
					// don't create more object URLs than needed
					if (!object_url) {
						object_url = get_URL().createObjectURL(blob);
					}
					if (force) {
						view.location.href = object_url;
					} else {
						var opened = view.open(object_url, "_blank");
						if (!opened) {
							// Apple does not allow window.open, see https://developer.apple.com/library/safari/documentation/Tools/Conceptual/SafariExtensionGuide/WorkingwithWindowsandTabs/WorkingwithWindowsandTabs.html
							view.location.href = object_url;
						}
					}
					filesaver.readyState = filesaver.DONE;
					dispatch_all();
					revoke(object_url);
				};
			filesaver.readyState = filesaver.INIT;

			if (can_use_save_link) {
				object_url = get_URL().createObjectURL(blob);
				setImmediate(function() {
					save_link.href = object_url;
					save_link.download = name;
					click(save_link);
					dispatch_all();
					revoke(object_url);
					filesaver.readyState = filesaver.DONE;
				}, 0);
				return;
			}

			fs_error();
		},
		FS_proto = FileSaver.prototype,
		saveAs = function(blob, name, no_auto_bom) {
			return new FileSaver(blob, name || blob.name || "download", no_auto_bom);
		};

	// IE 10+ (native saveAs)
	if (typeof navigator !== "undefined" && navigator.msSaveOrOpenBlob) {
		return function(blob, name, no_auto_bom) {
			name = name || blob.name || "download";

			if (!no_auto_bom) {
				blob = auto_bom(blob);
			}
			return navigator.msSaveOrOpenBlob(blob, name);
		};
	}

	// todo: detect chrome extensions & packaged apps
	//save_link.target = "_blank";

	FS_proto.abort = function() {};
	FS_proto.readyState = FS_proto.INIT = 0;
	FS_proto.WRITING = 1;
	FS_proto.DONE = 2;

	FS_proto.error =
		FS_proto.onwritestart =
		FS_proto.onprogress =
		FS_proto.onwrite =
		FS_proto.onabort =
		FS_proto.onerror =
		FS_proto.onwriteend =
		null;

	return saveAs;
}(
	typeof self !== "undefined" && self ||
	typeof window !== "undefined" && window ||
	this
));
