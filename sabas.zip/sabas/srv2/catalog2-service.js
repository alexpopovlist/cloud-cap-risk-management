const cds = require('@sap/cds');
const debug = require('debug')('srv2:catalog2-service');

module.exports = cds.service.impl(async function () {

    const {
            Address
          } = this.entities;

    this.after('READ', Address, (each) => {
        debug('READ ID:', each.ID);
    });

});