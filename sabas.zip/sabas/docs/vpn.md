# VPN Info

For using VPN on your personal laptop/PC needs to write mail to 55555@suek.ru
and send the following information:

VPN-pool: **10.72.129.96/28**  
Group name in active directory: **un_ctxnag-VPN-Corp-SAP_BTP** 

## List of available resources

* [https://desk.eurochem.ru](https://desk.eurochem.ru)
* [https://confluence.eurochem.ru](https://confluence.eurochem.ru)
* [https://github.aimdt.com](https://github.aimdt.com)
* [https://structurizr.amholding.com](https://structurizr.amholding.com)
* [https://kube-api-infra.csp.aimdt.com/](https://kube-api-infra.csp.aimdt.com/)
* [https://ingress-infra.csp.aimdt.com/](https://ingress-infra.csp.aimdt.com/)
* [https://dev.tadas.amholding.com](https://dev.tadas.amholding.com)