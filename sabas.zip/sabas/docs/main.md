# SABAS

Welcome to SABAS(SAP based solutions) team space!

## Arhitecture

Lnks for Arhitecture documents

## Front-end development

Lnks for front-end development documents

## Back-end development

Lnks for back-end development documents

## Knowlege base

* [VPN for remote access from non-corp PC](vpn.md)