# Welcome

Welcome to this tutorial for application development on SAP Business Technology Platform (SAP BTP). We provide information and examples on how to develop and deploy an application based on [SAP Cloud Application Programming Model (CAP)](https://cap.cloud.sap/) on SAP BTP using different tools and services step by step.

## Installation & Run

* install node.js: https://nodejs.org/en/
* cd sabas & npm install apply command
* Install the SAPUI5 command line interface (npm install --global @ui5/cli)
* Add CAP tooling (npm install --global @sap/cds-dk)
* Install Yeoman (npm install --global yo)
* Install VS Code: https://code.visualstudio.com/
* Install VS Code extensions (First run project sabas in visual studio)
* Install SAP Fiori tools Extension Pack (First run project sabas in visual studio)

For run application use command 
  **cds watch**
  
## Login & Password
  
  risk.manager@tester.sap.com
  initial

## Run unit test
  
  Unit tests localed in project_folder / webapp /test / unit / unitTests.qunit.html - file to run
  
  * All unit tests are placed in the webapp/test/unit folder of the app.
  * Files in the test suite end with *.qunit.html.
  * The unitTests.qunit.html file triggers all unit tests of the app.
  * A unit test should be written for formatters, controller logic, and other individual functionality.
  
## Known Issues

You can find the known issues [here](https://github.com/SAP-samples/cloud-cap-risk-management/issues).

## Documentation
Check out the documentation for:

* [CAP aka "capire"](https://cap.cloud.sap/docs/advanced/troubleshooting)
* [SAP BTP](https://help.sap.com/viewer/product/CP/Cloud/)

In case you have a question, find a bug, or otherwise need support to use SAP products, use:

* [CAP Community](https://answers.sap.com/tags/9f13aee1-834c-4105-8e43-ee442775e5ce)
* [SAP Community](https://community.sap.com/)
* [SAP BTP Support Components](https://help.sap.com/viewer/65de2977205c403bbc107264b8eccf4b/Cloud/en-US/08d1103928fb42f3a73b3f425e00e13c.html)

If you face a problem with the example application or the description, feel free to create an [issue](https://github.com/SAP-samples/cloud-cap-risk-management/issues).

## Information

* [Link to main page](docs/main.md)
