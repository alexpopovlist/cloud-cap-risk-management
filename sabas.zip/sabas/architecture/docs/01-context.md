## Context

Baseline Architecture of Sales Force solution

![](embed:sl1)