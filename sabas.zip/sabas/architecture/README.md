# Architecture documentation

This folder contains source code files of architecture diagrams and schemes.

The diagrams created using C4 Model.

See here for details <https://c4model.com/>.

## Usage

For local development [structurizr-lite](https://structurizr.com/help/lite) could be used.

For that, execute docker-compose:

```sh
docker-compose up
```

Do not forget to hit "Save Workspace" button in the interface and commit `workspace.json` file into the repository.

Optionally it's possible to use [online DSL editor](https://structurizr.com/dsl), but in this case `workspace.json` file must be generated manually using [structurizr-cli](https://github.com/structurizr/cli).

For pushing workspaces manually refer to a guideline by Structurizr <https://github.com/structurizr/cli/blob/master/README.md>

There is a [GitHub Action](../.github/workflows/structurizr.yml) that watches for push events with changes in this folder and pushes these changes to structurizr service.

## Adding documentation

In order to add documentation to the workspace in markdown format put your files in `docs` subfolder.
See [this article](https://structurizr.com/help/documentation/headings) on how to arrange headings.
You can [include digrams](https://structurizr.com/help/documentation/diagrams) and [images](https://structurizr.com/help/documentation/images) in markdown files.

## Adding ADRs

In order to add Architecture Decision Records (ADRs) to the workspace format put your files in `adrs` subfolder.
See [additional information](https://structurizr.com/help/decision-log)

>!NB Updated JSON data in `workspace.json` must be pushed along with new files.

## Structurizr on-premise

Link to on-premise instance

<https://structurizr.amholding.com/>

## Troubleshooting

If you changes didn't appear in the interface after pushing workspace to [Structurizr on-premise](https://structurizr.amholding.com), check that you included updated `workspace.json` file.

If not, hit "Save Workspace" button in the interface of [structurizr-lite](https://structurizr.com/help/lite) and add `workspace.json` file to your commit.

## Basic vocabulary

 *from Simon's Brown ["Software Architecture for Developers" Volume II](https://leanpub.com/visualising-software-architecture)*

### Software systems

These are the other software systems that your software system interacts with. Typically
these software systems sit outside the scope or boundary of your own software system, and
**you don’t have responsibility or ownership of them.** The Internet Banking example is very
clear in this respect. As a team building the Internet Banking System, we don’t own or have
any responsibility over the bank’s existing Mainframe Banking System, or the E-mail System.
For this reason, they are included on the diagram to illustrate that **they are dependencies of**
the Internet Banking System, and not something we are building ourselves.

### Containers

A container typically represents an application or data store.

#### File systems and log files vs data storage

If I’m describing a software system where an application stores business critical data on a
file system, I will include a “File System” container on the diagram, to make this explicit. In
contrast, although many types of containers will write log files to a file system (and this is
undoubtedly important), I typically omit this detail for brevity.

#### Data storage as a service

A frequently asked question is whether services like Amazon S3, Amazon RDS, or Azure
SQL Database should be shown on a container diagram. After all, these are external services
that we don’t own or run ourselves.
If you’re building a software system that is using Amazon S3 for storing data, it’s true that
you don’t run S3 yourself, but you do have ownership and responsbility for the buckets you
are using. Similarly with Amazon RDS, you have (more or less) complete control over any
database schemas that you create. For this reason, I will usually show such containers on a
container diagram. They are an integral part of your software architecture, although they
are hosted elsewhere.

## Notation

Unlike formal diagramming notations, Structurizr purposely uses a very simple and constrained notation consisting of boxes and uni-directional arrows, some aspects of which can be customised via a set of element and relationship styles. Any styles that you use are shown on an automatically generated diagram key.

<https://structurizr.com/help/notation>

## Shapes

Using different shapes can be a great way to add an additional level of information to specific elements, as well as making a diagram look more aesthetically pleasing. Structurizr provides a number of different shapes that you can use to style your diagram elements.

<https://structurizr.com/help/shapes>

## Editing diagrams layout

Here is some useful tips on how to work without autolayout

[![Structurizr - Diagram editor basics](https://img.youtube.com/vi/6y8zwhFuLl8/0.jpg)](https://youtu.be/6y8zwhFuLl8)

## Recommendations

### Diagrams

* Every diagram should have a title describing the diagram type and scope (e.g. "System Context diagram for My Software System").
* Every diagram should have a key/legend explaining the notation being used (e.g. shapes, colours, border styles, line types, arrow heads, etc).
* Acronyms and abbreviations (business/domain or technology) should be understandable by all audiences, or explained in the diagram key/legend.

### Elements

* The type of every element should be explicitly specified (e.g. Person, Software System, Container or Component).
* Every element should have a short description, to provide an "at a glance" view of key responsibilities.
* Every container and component should have a technology explicitly specified.

### Themes

There is a number of prebuilt themes for use with the Structurizr cloud service and on-premises installation.

Check it out here <https://github.com/structurizr/themes>

### Relationships

* Every line should represent a **unidirectional** relationship.
* Every line should be labelled, the label being consistent with the direction and intent of the relationship (e.g. dependency or data flow). Try to be as specific as possible with the label, ideally avoiding single words like, "Uses".
* Relationships between containers (typically these represent inter-process communication) should have a technology/protocol explicitly labelled.

### Infrastructure components and cross-cutting concerns

*from "Software Architecture for Developers" <https://leanpub.com/visualising-software-architecture>*

Infrastructure components are important parts of most software systems, yet you may or may not want to include them on your Component diagram. For example, if you have a logging component, it's likely to be used by the majority of other components within the container. Drawing this component and all of the interactions can result in a very cluttered diagram. You have a number of options to deal with this:

1. Don't include the logging component if it doesn't add much value in helping you tell the story.
2. Write a note on the diagram that says something like, "All components shown here write logs via a Logging Component".
3. Include the logging component on the diagram, but don't show how it's connected to anything else. Instead, annotate elements that use the logging component (with a symbol/icon), or use a colour coding, which you can then describe in a diagram key/legend (e.g. "the asterisk denotes a relationship with the Logging Component").

### Tooling

There is a plugin for Visual Studio Code editor for Structurizr DSL syntax highlighting

<https://marketplace.visualstudio.com/items?itemName=ciarant.vscode-structurizr>
