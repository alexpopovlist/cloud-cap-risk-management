sap.ui.define([], function() {
	"use strict";
	// todo понять как записать @alias и @lends

	return Object.freeze({
		/**
		 * Определение значения констант.
		 */
		MAIN_FEATURE: true,
		MINOR_FEATURE: false

	});
}, true);
